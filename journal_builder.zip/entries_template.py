"""Template for a new day page.

1. Copy this file and name it after the date: entries_17.py for 17 November.
2. Rename DAY_NEW / ENTRIES_NEW to the next numbers (DAY12 / ENTRIES12).
3. Fill in the day and one dictionary per card.
4. In build.py, import it and add (DAY12, ENTRIES12) to the end of DAYS.
5. Add the new card IDs to any pattern in patterns.py whose lesson they repeat.
6. Run: python build.py
"""

DAY_NEW = {
    "date": "Tuesday, 17 November 2026",
    "focus": "One or two sentences: what you worked on today.",
    "outcome": "What got done, and how many entries of each type.",
    "review": "What repeated from earlier days, and what's still open.",
}

ENTRIES_NEW = [
    {
        "id": "20261117-01",                 # date + running number: unique, sortable
        "tool": "pandas",                    # pandas, Python, SQL, Excel, Metabase...
        "type": "Error",                     # Error, Wrong result or How-to
        "title": "The error message, or what went wrong, in one line",
        "tags": "a few, search, words",
        "problem": "What you ran and what happened.",
        "cause": "Why it happened. Can be empty for a How-to.",
        "code": r'''# the fix: the shortest code that shows it
df["x"] = df["x"].str.strip()''',
        "why": [
            "First reason the fix works.",
            "Second reason, or what to watch for.",
        ],
        "lesson": "One sentence to remember.",
    },
]
