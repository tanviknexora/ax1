DAY2 = {
    "date": "Friday, 30 October 2026",
    "focus": "Ledger checks in pandas, Excel formula fixes, and combining 60M+ rows of transaction files "
             "from two folders (CSV and XLSX) for the migration.",
    "outcome": "21 entries: 8 errors, 6 wrong results and 7 how-tos. Built transactions_loader.py so the "
               "transaction files load without crashing the kernel.",
    "review": "Repeated from day 1: a built-in used as a name (all), duplicate column names (four amount "
              "columns), and latest-row-per-key sorted by the wrong column. Focus tomorrow: PG40 Day 1, "
              "exercises 1 to 10.",
}

ENTRIES2 = [
    {
        "id": "20261030-01", "tool": "pandas", "type": "How-to",
        "title": "Select ledger rows for yesterday",
        "tags": "dates, half-open range, sort_values",
        "problem": "Needed only yesterday's ledger rows. The code also ran `led.sort_values(...)` on its own line.",
        "cause": "A date filter needs a start and an end. `sort_values` returns a sorted copy, so without "
                 "`led = ...` the sort is thrown away.",
        "code_lang": "python",
        "code": r'''led = led.sort_values('CreatedAt', ascending=False)      # assign it back

today = pd.Timestamp.today().normalize()      # today 00:00:00
yesterday = today - pd.Timedelta(days=1)

led_yesterday = led[(led['CreatedAt'] >= yesterday) & (led['CreatedAt'] < today)]''',
        "why": [
            "`>=` start and `<` end (a half-open range) covers every second, including 23:59:59.5.",
            "Each condition in brackets, joined with `&`; plain `and` doesn't work on columns.",
            "If `led['CreatedAt'].max()` is older than yesterday, 0 rows is the correct answer.",
            "UTC times are 4 hours behind Dubai: convert with `tz_localize('UTC').tz_convert('Asia/Dubai')` first.",
        ],
        "lesson": "Use >= start and < end for date ranges, and always assign sort_values back.",
    },
    {
        "id": "20261030-02", "tool": "Polars", "type": "Wrong result",
        "title": "The combined ledger seemed to stop at the 27th",
        "tags": "ledger_loader, diagnostics, Excel-saved CSV",
        "problem": "`get_final_ledger()` looked like it had no rows after the 27th, although files for 28 and 29 Oct existed.",
        "cause": "The loader parses `2026-10-29T23:59:53.103Z` correctly. The likely cause was viewing an unsorted "
                 "`head()`, or a file missing from the append folder or saved through Excel.",
        "code_lang": "python",
        "code": r'''print(led['CreatedAt'].max())          # step 1: is the data really missing?

summary = lambda lf: lf.select(
    pl.col("CreatedAt").min().alias("first"),
    pl.col("CreatedAt").max().alias("last"),
    pl.col("CreatedAt").null_count().alias("unparsed_dates"),
    pl.len().alias("rows"),
).collect()
print(summary(scan_base_ledger()))
print(summary(scan_append_files()))''',
        "why": [
            "Check the data before changing the code: `max()` answers \"is it there?\" in one line.",
            "`unparsed_dates` above 0 means some date text didn't match the format, usually after Excel saved it.",
            "`trade_id` shown as `2.61029E+17` means the file was opened in Excel; if saved, the IDs are rounded for good.",
        ],
        "lesson": "Measure first (min, max, nulls, rows per source), then decide what's broken.",
    },
    {
        "id": "20261030-03", "tool": "Excel", "type": "Wrong result",
        "title": "SUMIFS returned 0 for negative balance protection",
        "tags": "SUMIFS, $ references, COUNTIF",
        "problem": "`=SUMIFS(...!I:I, ...!E:E, Sheet2!D3, ...!C:C, Sheet2!A4)` gave 0 down the column.",
        "cause": "`D3` had no `$`, so it moved to `D4`, `D5`... when copied down. The ledger type may also be "
                 "spelled differently, or there may be no such entries that day.",
        "code_lang": "excel",
        "code": r'''=SUMIFS('direct_ledger_report_filtered ('!$I:$I,
        'direct_ledger_report_filtered ('!$E:$E, D$3,
        'direct_ledger_report_filtered ('!$C:$C, $A4)

=COUNTIF('direct_ledger_report_filtered ('!E:E, D3)            exact matches
=COUNTIF('direct_ledger_report_filtered ('!E:E, "*NEGATIVE*")   any spelling''',
        "why": [
            "`D$3` fixes the row (a header); `$A4` fixes the column (a label); `$I:$I` fixes both.",
            "`SUMIFS` ignores capitals but not underscores or trailing spaces. `*` in a criterion = any characters.",
            "Easier: put `ledger_type` in the pivot table's Columns area to get every type at once.",
        ],
        "lesson": "Anchor headers with D$3 and labels with $A4 before copying a formula.",
    },
    {
        "id": "20261030-04", "tool": "Excel", "type": "How-to",
        "title": "Extract the number from BR575346: ****",
        "tags": "REGEXEXTRACT, MID, FIND",
        "problem": "Needed `575346` out of IDs like `BR575346: ****`, where the letter prefix varies in length.",
        "cause": "The digits start at a different position for one-letter (`S75577`) and two-letter prefixes.",
        "code_lang": "excel",
        "code": r'''=REGEXEXTRACT(A2, "[0-9]+")                                  Microsoft 365

=MID(A2, MIN(FIND({0,1,2,3,4,5,6,7,8,9}, A2&"0123456789")),     older Excel
     FIND(":", A2) - MIN(FIND({0,1,2,3,4,5,6,7,8,9}, A2&"0123456789")))''',
        "why": [
            "`[0-9]+` = one or more digits in a row; `--` in front turns the text into a number.",
            "`MIN(FIND({0..9}, ...))` = position of the first digit; adding `\"0123456789\"` stops `FIND` erroring.",
            "pandas: `str.extract(r'(\\d+)', expand=False)`. PostgreSQL: `substring(col FROM '[0-9]+')`.",
        ],
        "lesson": "A regex finds a pattern wherever it sits; position-based formulas break when prefixes vary.",
    },
    {
        "id": "20261030-05", "tool": "Excel", "type": "Error",
        "title": "The formula shows as text instead of calculating",
        "tags": "cell format, Show Formulas",
        "problem": "`=REGEXEXTRACT(A2, \"[0-9]+\")` stayed visible as text in the cell.",
        "cause": "The cell was formatted as Text, so Excel stored the formula as plain text.",
        "code_lang": "excel",
        "code": r'''1. Select the cells -> Home -> Number format -> General
2. Re-enter: F2, then Enter (changing the format alone doesn't recalculate)
3. Many cells: Ctrl+H, replace = with =, Replace All''',
        "why": [
            "Other causes: Show Formulas is on (Formulas -> Show Formulas), or a space or apostrophe before the `=`.",
            "If it then shows `#NAME?`, the Excel version has no `REGEXEXTRACT`; use the `MID` version.",
        ],
        "lesson": "A formula that won't calculate is usually a Text-formatted cell.",
    },
    {
        "id": "20261030-06", "tool": "Excel", "type": "Wrong result",
        "title": "UNIQUE(FILTER(..., OR(...))) doesn't filter",
        "tags": "FILTER, OR logic, arrays",
        "problem": "`=UNIQUE(FILTER(dgrdReport!G:G, OR(D:D=\"Buy\", D:D=\"Sell\")))` gave an error or wrong rows.",
        "cause": "`OR()` returns one TRUE/FALSE for the whole column; `FILTER` needs one per row.",
        "code_lang": "excel",
        "code": r'''=UNIQUE(FILTER(dgrdReport!G:G,
               (dgrdReport!D:D="Buy") + (dgrdReport!D:D="Sell"),
               "No matches"))

=UNIQUE(FILTER(dgrdReport!G:G, ISNUMBER(MATCH(dgrdReport!D:D, {"Buy","Sell"}, 0)), "No matches"))''',
        "why": [
            "`+` turns TRUE/FALSE into 1/0 row by row; `FILTER` keeps non-zero rows. `*` means AND.",
            "`\"No matches\"` replaces the `#CALC!` error when nothing matches.",
            "Whole columns like `G:G` are slow; fixed ranges like `G2:G50000` are faster.",
        ],
        "lesson": "Inside FILTER: + for OR, * for AND. Never OR() or AND().",
    },
    {
        "id": "20261030-07", "tool": "pandas", "type": "Error",
        "title": "KeyError: 'ClientID' in groupby",
        "tags": "variable names, columns",
        "problem": "`df.groupby('ClientID', as_index=False)['CreatedAt'].max()` raised `KeyError: 'ClientID'`.",
        "cause": "`df` had just been replaced by `pd.read_excel(...)`, so it held the traded-IDs sheet, not the ledger.",
        "code_lang": "python",
        "code": r'''print(df.columns.tolist())                      # what does df actually hold?

last_dates = led.groupby('ClientID', as_index=False)['CreatedAt'].max()

df.columns = df.columns.str.strip()             # if names have hidden spaces
df = df.reset_index()                           # if ClientID became the index''',
        "why": [
            "A `KeyError` on a column means that exact name isn't in `df.columns`: wrong table, spaces, capitals, or index.",
            "`pd.read_excel(path, sheet_name='Sheet1')` reads one tab; `pd.ExcelFile(path).sheet_names` lists them.",
        ],
        "lesson": "Give every table its own name (led, traded_ids); reusing df hides which table you have.",
    },
    {
        "id": "20261030-08", "tool": "pandas", "type": "How-to",
        "title": "Fill Zynixx Balance and Last Trade with .map()",
        "tags": "map, lookup, set_index",
        "problem": "The traded-IDs sheet had empty `Zynixx Balance` and `Zynixx Last T` columns to fill from two small tables.",
        "cause": "`merge` would add new key and value columns. `.map()` fills an existing column and keeps the row order.",
        "code_lang": "python",
        "code": r'''bal_map  = balance.drop_duplicates('ClientID').set_index('ClientID')['Balance']
date_map = last_dates.drop_duplicates('ClientID').set_index('ClientID')['CreatedAt']

key = df['Zynixx Id'].astype(str).str.strip()
df['Zynixx Balance'] = key.map(bal_map)
df['Zynixx Last T']  = key.map(date_map)''',
        "why": [
            "`set_index(key)[col]` turns a table into a lookup: labels are IDs, values are the answers.",
            "IDs not found (like `No New Id`) become NaN; `df` keeps its 212 rows.",
            "Duplicate IDs in the lookup make `.map()` fail; `drop_duplicates` prevents it.",
        ],
        "lesson": "To fill a column from another table by key, use .map() on a one-row-per-key lookup.",
    },
    {
        "id": "20261030-09", "tool": "pandas", "type": "Wrong result",
        "title": "Latest balance taken from a random row",
        "tags": "drop_duplicates, latest row per key",
        "problem": "`led_req.sort_values('ClientID').drop_duplicates(subset='ClientID', keep='first')` gave balances that weren't the latest.",
        "cause": "Sorting by `ClientID` groups each client's rows but leaves them in no date order, so `keep='first'` picks any row.",
        "code_lang": "python",
        "code": r'''balance = (led_req.sort_values('CreatedAt', ascending=False)
                  .drop_duplicates(subset='ClientID', keep='first')
                  .reset_index(drop=True)[['ClientID', 'Balance']])''',
        "why": [
            "\"Latest row per key\" = sort by the DATE, newest first, then keep the first row per key.",
            "Same idea as `DISTINCT ON (key) ... ORDER BY key, date DESC` in PostgreSQL.",
        ],
        "lesson": "keep='first' is only as good as the sort before it: sort by the column that defines 'first'.",
    },
    {
        "id": "20261030-10", "tool": "pandas", "type": "Error",
        "title": "KeyError: Index([Ellipsis], dtype='object')",
        "tags": "placeholder code",
        "problem": "Running a comparison block failed inside `drop_duplicates`.",
        "cause": "The block included `drop_duplicates(...)` with a literal `...`, written as a placeholder. Python "
                 "treats `...` as a real value (`Ellipsis`) and looked for a column with that name.",
        "code_lang": "python",
        "code": r'''# Run only the real line, never the illustrative one:
balance = (led_req.sort_values('CreatedAt', ascending=False)
                  .drop_duplicates(subset='ClientID', keep='first'))''',
        "why": [
            "`...` is valid Python, so it doesn't fail until the function uses it.",
            "When a snippet shows a \"before\" and \"after\", copy only the \"after\".",
        ],
        "lesson": "Read a code block before running it; skip lines marked as examples of what not to do.",
    },
    {
        "id": "20261030-11", "tool": "pandas", "type": "How-to",
        "title": "Add a result sheet to the original workbook",
        "tags": "ExcelWriter, openpyxl",
        "problem": "Needed the finished `df` saved as a sheet called `result` in the original Excel file.",
        "cause": "`df.to_excel(path)` alone overwrites the whole workbook.",
        "code_lang": "python",
        "code": r'''with pd.ExcelWriter(path, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
    df.to_excel(writer, sheet_name='result', index=False)''',
        "why": [
            "`mode='a'` adds to the file and keeps the other sheets.",
            "`if_sheet_exists='replace'` overwrites `result` on reruns instead of creating `result1`.",
            "Close the file in Excel first (`PermissionError`), and note `openpyxl` can drop pivot tables and slicers.",
        ],
        "lesson": "Append a sheet with ExcelWriter(mode='a'); write a new file when the workbook has pivots.",
    },
    {
        "id": "20261030-12", "tool": "pandas", "type": "Error",
        "title": "Combining every file in a folder",
        "tags": "os.listdir, concat, built-in names",
        "problem": "The loop started with `all = []`, called `pd.read_csv()` with no path, and created an empty table on every pass.",
        "cause": "`all` is a built-in function; `read_csv` needs the full path; `.xlsx` needs `read_excel`.",
        "code_lang": "python",
        "code": r'''frames = []
for file in os.listdir(folder):
    full_path = os.path.join(folder, file)
    if file.startswith('~$'):
        continue
    if file.lower().endswith('.csv'):
        part = pd.read_csv(full_path, dtype=text_cols)
    elif file.lower().endswith('.xlsx'):
        part = pd.read_excel(full_path)
    else:
        continue
    part['source_file'] = file
    frames.append(part)

combined = pd.concat(frames, ignore_index=True)''',
        "why": [
            "Collect pieces in a list and `concat` once; it is much faster than growing a table file by file.",
            "`os.listdir` returns names only, so `os.path.join` builds the path.",
            "`~$` files are Excel lock files and can't be read.",
        ],
        "lesson": "Same lesson as min and max yesterday: never use a built-in name (all, list, sum) for a variable.",
    },
    {
        "id": "20261030-13", "tool": "pandas", "type": "Error",
        "title": "DtypeWarning: Columns (21: expiryDate) have mixed types",
        "tags": "dtype, read_csv, mixed types",
        "problem": "`read_csv` warned about `expiryDate`, `comment` and `scriptParent` in several files.",
        "cause": "Big files are read in chunks and each chunk's type is guessed separately. Blank chunks look like "
                 "numbers and others hold text, so the column ends up mixed.",
        "code_lang": "python",
        "code": r'''text_cols = {'expiryDate': str, 'comment': str, 'scriptParent': str}
part = pd.read_csv(full_path, dtype=text_cols)

combined['expiryDate'] = pd.to_datetime(combined['expiryDate'], errors='coerce')
combined['expiryDate'].map(type).value_counts()      # check what a column holds''',
        "why": [
            "A mixed column breaks sorting (`'<' not supported between 'str' and 'float'`) and merges.",
            "`low_memory=False` only hides the warning; the values are still mixed.",
        ],
        "lesson": "Read mostly-empty or mixed columns as text, then convert them once on purpose.",
    },
    {
        "id": "20261030-14", "tool": "pandas", "type": "Error",
        "title": "MemoryError: Unable to allocate 487 MiB ... shape (1, 63807297)",
        "tags": "memory, usecols, concat",
        "problem": "`pd.concat(frames)` failed after reading every transaction file.",
        "cause": "63,807,297 rows × 8 bytes = 487 MiB per number column. With ~30 columns the table needs 15+ GB, "
                 "and `concat` holds the pieces and the copy at once.",
        "code_lang": "python",
        "code": r'''part = pd.read_csv(full_path, usecols=keep_cols, dtype=text_cols)   # only needed columns
part = part[part['clientId'].isin(ids)]                              # only needed rows
frames.append(part)
...
combined = pd.concat(frames, ignore_index=True)
del frames                                                           # free the pieces''',
        "why": [
            "Estimate first: rows × columns × 8 bytes for numbers; text costs more.",
            "Cutting columns while reading saves the most; filtering each file saves the rest.",
            "For this size, Polars (lazy, parallel) is the better tool.",
        ],
        "lesson": "Size the data before loading it; read only the columns and rows you need.",
    },
    {
        "id": "20261030-15", "tool": "Polars", "type": "Error",
        "title": "'LazyFrame' object has no attribute 'to_pandas'",
        "tags": "LazyFrame, collect",
        "problem": "`lf = lf.to_pandas()` failed.",
        "cause": "A LazyFrame is a plan of what to read, not data. Only a collected DataFrame has `.to_pandas()`.",
        "code_lang": "python",
        "code": r'''lf.collect_schema().names()     # column names, no data read
lf.head(5).collect()            # first rows only
lf.select(pl.len()).collect()   # row count

result_pd = lf.select(cols).filter(cond).collect().to_pandas()''',
        "why": [
            "`.collect()` runs the plan; `.to_pandas()` then converts the result.",
            "Don't reuse `lf` for a pandas table; keep `lf` for the plan and new names for data.",
        ],
        "lesson": "Lazy = plan. collect() = load. Cut the plan down before collecting.",
    },
    {
        "id": "20261030-16", "tool": "Polars", "type": "Error",
        "title": "Kernel crashed on lf.collect()",
        "tags": "memory, streaming, sink",
        "problem": "`result = lf.collect()` then `result.to_pandas()` crashed the Jupyter kernel; every variable was lost.",
        "cause": "It loaded all 63.8M+ rows and every column, then tried to make a second full copy for pandas.",
        "code_lang": "python",
        "code": r'''needed = (lf.select(['clientId', 'symbol', 'time'])
            .filter(pl.col('clientId').is_in(list(ids)))
            .collect(engine='streaming'))                 # older Polars: streaming=True
print(needed.shape, round(needed.estimated_size('gb'), 2), 'GB')

lf.sink_csv(r"C:\...\transactions_combined.csv")       # everything, to disk, in batches''',
        "why": [
            "`engine='streaming'` processes in batches; `group_by(...).agg(...)` before collect returns only totals.",
            "`sink_csv` / `sink_parquet` write every row without holding it in memory, which suits `\\copy` into PostgreSQL.",
            "Check `estimated_size('gb')` before `.to_pandas()`; converting needs that much again.",
        ],
        "lesson": "Never collect a whole big plan. Select, filter, or sink to disk.",
    },
    {
        "id": "20261030-17", "tool": "Polars", "type": "How-to",
        "title": "Append the ark folder (CSV and XLSX) to the transactions",
        "tags": "read_excel, diagonal_relaxed, source_file",
        "problem": "The ark append folder had both `.csv` and `.xlsx` files to add to the transaction plan.",
        "cause": "Polars scans CSVs lazily but must read Excel files fully; both then have to join one plan.",
        "code_lang": "python",
        "code": r'''def read_xlsx_file(f):
    return (pl.read_excel(f, infer_schema_length=10_000)     # pip install fastexcel
              .lazy()
              .with_columns(pl.lit(f.name).alias('source_file')))

parts = [scan_csv_file(f) for f in trans_csv + ark_csv] + [read_xlsx_file(f) for f in ark_xlsx]
lf = pl.concat(parts, how='diagonal_relaxed')''',
        "why": [
            "`.lazy()` turns a loaded Excel table into a LazyFrame; each `.xlsx` is at most ~1M rows.",
            "`diagonal_relaxed` matches columns by name and widens differing types (a date vs text becomes text).",
            "`pl.lit(f.name)` tags each row with its file, so you can count rows per source.",
        ],
        "lesson": "Tag every row with its source file whenever you combine files.",
    },
    {
        "id": "20261030-18", "tool": "Polars", "type": "How-to",
        "title": "transactions_loader.py: a module that can't crash the kernel",
        "tags": "module, select before collect",
        "problem": "`get_final_ledger(as_pandas=True)` never crashed, but loading the transactions did.",
        "cause": "The ledger loader keeps 6 columns before collecting, so Polars reads only those. The transactions "
                 "code collected 30+ columns.",
        "code_lang": "python",
        "code": r'''from transactions_loader import list_columns, check_columns, count_rows, get_transactions

check_columns()                                  # files whose columns differ
count_rows(by_file=True)                         # rows per file, nothing loaded
df = get_transactions(columns=['ticketId', 'time', 'accountId', 'amount'],
                      where=pl.col('accountId').is_in(list(ids)),
                      as_pandas=True)''',
        "why": [
            "`columns` is required, so the full table can't be loaded by accident.",
            "Results over `MAX_PANDAS_GB` (4 GB) raise a clear error instead of crashing.",
            "`export_transactions(path)` streams everything to `.parquet` or `.csv` for the migration.",
        ],
        "lesson": "Build the safe habit into the tool: make the big, dangerous option impossible by default.",
    },
    {
        "id": "20261030-19", "tool": "pandas", "type": "Wrong result",
        "title": "Aligning ark columns gave four amount columns",
        "tags": "rename, normalised names, clash check",
        "problem": "After renaming ark columns to the main names, the result had `amount` four times: `1.00, 37372.0, 1.00, 37372.0`.",
        "cause": "Two ark columns normalised to `amount`, and selecting `[list(rename.values())]` asked for `amount` "
                 "twice, so each copy appeared twice. The code had no clash check.",
        "code_lang": "python",
        "code": r'''def norm(name):
    return re.sub(r'[^a-z0-9]', '', str(name).lower())      # 'Ticket Id' -> 'ticketid'

targets = pd.Series(rename)
clashes = targets[targets.duplicated(keep=False)]
if not clashes.empty:
    raise ValueError("Same target name:\n" + clashes.to_string())

ark_clean = df[list(rename)].rename(columns=rename)          # select originals, then rename''',
        "why": [
            "Lowercase alone fails: `Ticket Id` -> `ticket id`, not `ticketId`. Removing spaces and symbols matches them.",
            "Names that differ in words (`Account` -> `accountId`, `Open Com` -> `openCommission`) are mapped by hand.",
            "Each ark file has different headers (31 vs 14 columns), so align each file on its own.",
        ],
        "lesson": "After any rename, check that no two columns share a name.",
    },
    {
        "id": "20261030-20", "tool": "pandas", "type": "How-to",
        "title": "Match the main file's columns and types exactly (minus id)",
        "tags": "reindex, Int64, dtypes",
        "problem": "The cleaned ark table had 28 of the 30 target columns, in a different order, with `ticketId` as `41672978.0`.",
        "cause": "Missing columns, different order, and blanks forcing whole numbers into decimals.",
        "code_lang": "python",
        "code": r'''target_cols = [c for c in major.columns if c != 'id']
major_final = major.drop(columns='id')
ark_final = ark_clean.reindex(columns=target_cols)       # adds fileReferenceId, location as blank
assert list(ark_final.columns) == list(major_final.columns)

for df_ in (major_final, ark_final):
    for c in ['ticketId', 'openPosition']:
        df_[c] = pd.to_numeric(df_[c], errors='coerce').astype('Int64')''',
        "why": [
            "`reindex(columns=...)` sets the order and adds missing columns as blanks in one step.",
            "`Int64` (capital I) allows blanks and keeps whole numbers.",
            "Compare types side by side: `pd.DataFrame({'major': major_final.dtypes, 'ark': ark_final.dtypes})`.",
        ],
        "lesson": "Same names is not enough: make the types match before appending.",
    },
    {
        "id": "20261030-21", "tool": "pandas", "type": "Wrong result",
        "title": "Times show as 59:48.4 (date and hour lost)",
        "tags": "Excel, CSV, data loss",
        "problem": "`ark_final['time']` held values like `59:48.4` and `openDate` like `28:14.3`.",
        "cause": "The CSV was opened in Excel and saved. Excel displays times with fractions as minutes:seconds and "
                 "saves the display, so the date and hour are gone from the file.",
        "code_lang": "python",
        "code": r'''short = ark_clean['time'].astype(str).str.fullmatch(r'\d{1,2}:\d{2}(\.\d+)?')
ark_clean.loc[short, 'source_file'].value_counts()            # which files are damaged
print(ark_clean.duplicated(subset='ticketId').sum())          # same rows in csv AND xlsx?

t = ark_final['time'].astype(str).str.strip()
ark_final['time'] = pd.to_datetime(t.where(~t.str.fullmatch(r'\d{1,2}:\d{2}(\.\d+)?')),
                                   format='ISO8601', errors='coerce')     # blank, don't guess''',
        "why": [
            "The same rows appeared with full times in another ark file, so a clean copy likely exists.",
            "If the same data is in a `.csv` and an `.xlsx`, every row is loaded twice; removing the damaged file fixes both.",
            "Never save a CSV from Excel; look at it with `pd.read_csv(path, nrows=20)` instead.",
        ],
        "lesson": "Keep original downloads untouched. Excel rewrites what it saves.",
    },
]

PATTERNS = [
    ("Repeated rows mean a one-to-many join or duplicate keys",
     "20261029-11, 20261029-12, 20261030-21",
     "Collapse the many side to one row per key first. Check COUNT(*) = COUNT(DISTINCT key), "
     "validate='many_to_one', or duplicated(subset=key)."),
    ("Check what is really stored before filtering",
     "20261029-05, 20261029-08, 20261029-09, 20261030-03, 20261030-07",
     "Look at real values and column names: df.columns, SELECT ... LIMIT 1, COUNTIF with wildcards."),
    ("Duplicate names break selection",
     "20261029-02, 20261030-19",
     "A single name returning a DataFrame, or a column appearing twice, means duplicate names. Check after every rename."),
    ("Never reuse built-in or existing names",
     "20261029-01, 20261030-07, 20261030-12",
     "min, max, all, list, sum are functions. Give each table its own name instead of reusing df."),
    ("Assign results back, and sort by the right column",
     "20261030-01, 20261030-09",
     "sort_values returns a copy: write led = led.sort_values(...). For 'latest per key', sort by the date."),
    ("Calculate in one step, filter in the next",
     "20261029-06",
     "Window functions run after WHERE. Put them in a CTE and filter in the following SELECT."),
    ("Verify every summary against raw rows",
     "20261029-06, 20261029-07, 20261029-13, 20261030-02",
     "Count rows, min/max dates and nulls per source before trusting a result."),
    ("Load only what you need",
     "20261030-14, 20261030-15, 20261030-16, 20261030-18",
     "Estimate rows x columns x 8 bytes. Select columns and filter rows before collecting; sink big outputs to disk."),
    ("Text that looks like a date or number isn't one",
     "20261029-04, 20261029-12, 20261030-13, 20261030-20",
     "Convert with pd.to_datetime / pd.to_numeric / Int64 before sorting, comparing or merging."),
    ("Excel changes data when it saves",
     "20261030-02, 20261030-05, 20261030-21",
     "Never save a CSV from Excel. Long IDs become 2.61029E+17 and times become 59:48.4 for good."),
]
