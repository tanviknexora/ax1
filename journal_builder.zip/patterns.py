"""Lessons that came up more than once: (name, card IDs, what to do).
Add a card ID to a pattern when a new card repeats its lesson."""

PATTERNS = [('Latest row per key: sort by the date, fully',
  '20261030-01, 20261030-09, 20261104-04, 20261109-04, 20261109-05, 20261114-09, 20261114-11',
  "pandas: sort_values(date, ascending=False) right before drop_duplicates(keep='first'). SQL: ORDER BY date "
  'DESC NULLS LAST plus a unique tie-breaker in ROW_NUMBER / DISTINCT ON.'),
 ('Check the inputs before the code',
  '20261030-02, 20261031-08, 20261104-08, 20261110-02, 20261112-04, 20261114-03, 20261116-03',
  'Print which files and rows are used (value_counts after each filter) before changing any logic.'),
 ('Repeated rows mean a one-to-many join or duplicate keys',
  '20261029-11, 20261029-12, 20261030-21, 20261102-01, 20261102-04, 20261102-06, 20261109-03, 20261109-06, '
  '20261110-09, 20261111-05',
  'Collapse the many side to one row per key first. Check COUNT(*) = COUNT(DISTINCT key), '
  "validate='many_to_one', or duplicated(subset=key)."),
 ('Agree the output before building',
  '20261102-09, 20261104-05, 20261109-05, 20261109-06, 20261110-10, 20261111-03, 20261111-08',
  'Name the columns to add, what to keep, and the exact rule (first / any / only; owner or caller; which '
  'status wins a tie).'),
 ('Check what is really stored before filtering',
  '20261029-05, 20261029-08, 20261029-09, 20261030-03, 20261030-07, 20261102-07, 20261109-05, 20261109-07, '
  '20261111-05, 20261111-10',
  'Look at real values and column names: df.columns, SELECT DISTINCT, value_counts, COUNTIF with wildcards.'),
 ('One label per row when groups must add up',
  '20261110-01, 20261110-05, 20261111-08, 20261116-06, 20261116-07',
  'np.select([...], [...], default=...) gives each row exactly one label, decided in a stated order; the '
  'groups then always sum to the total.'),
 ('Try the edge cases of every business rule',
  '20261110-06, 20261110-07, 20261111-03, 20261112-09',
  'Before trusting a rule, run a zero row (no activity), a just-below row and a just-above row through it.'),
 ('Name each setting and window once',
  '20261110-05, 20261110-08, 20261111-12, 20261116-09',
  'Program numbers and date windows as named settings at the top (REPORT_MONTH, TRADE_MONTHS, '
  'MIN_TRADE_VALUE); never reuse one start/end for two meanings.'),
 ('Every number counts by one stated date',
  '20261110-10, 20261111-08, 20261111-10, 20261112-01, 20261112-07',
  'Lead date, event date, rolling 30 days: name the date each column counts by, keep views apart, and print '
  "the window in every run and in the report's notes."),
 ('Decide what a blank means',
  '20261109-01, 20261109-04, 20261112-07, 20261114-07, 20261116-02',
  'For every filter or sort on a column that can be NULL: include or exclude (OR col IS NULL), and place '
  'them deliberately (NULLS FIRST / NULLS LAST).'),
 ('Same type, same clock before date maths',
  '20261109-02, 20261109-07, 20261110-10, 20261112-01, 20261114-06',
  "Convert both sides to dates in one zone, (ts AT TIME ZONE 'Asia/Kolkata')::date, before subtracting; say "
  'whether a window is rolling hours or calendar days.'),
 ('Start from the thing every row must represent',
  '20261102-05, 20261116-08',
  'Every ID must appear? Start from the IDs and LEFT JOIN the rest; label why a value is zero.'),
 ('Duplicate or double-used names break things',
  '20261029-02, 20261030-19, 20261031-06, 20261109-02, 20261110-09, 20261111-10',
  'Two columns with one name, or one column as both pivot key and value. Check names after every rename.'),
 ('Names, brackets and arguments',
  '20261029-01, 20261030-12, 20261031-11, 20261104-03, 20261104-09, 20261109-02, 20261109-03, 20261109-08, '
  '20261111-15, 20261112-02, 20261114-02, 20261114-04, 20261114-05',
  "Built-in names, a token's value used as its name, a bracket closing late or missing, a missing argument, "
  'an unquoted literal.'),
 ('Metabase: one statement, variables where values go',
  '20261109-03, 20261109-08, 20261109-09',
  'IN ({{var}}) with brackets, [[AND ...]] for optional filters, no trailing semicolon, test queries in '
  'their own question.'),
 ('Verify against raw rows or an old version',
  '20261029-06, 20261029-07, 20261029-13, 20261030-02, 20261031-04, 20261104-11, 20261109-11, 20261110-04, '
  '20261111-06, 20261112-05, 20261114-07',
  'Compare counts with raw data; run old and new code on the same input; assert_frame_equal; a query that '
  'counts differences.'),
 ('Build checks that fail loudly',
  '20261031-07, 20261031-09, 20261031-12, 20261102-05, 20261102-08, 20261112-05, 20261116-02, 20261116-07',
  'assert impossible values, raise on unreadable dates, cross-check two outputs, label every zero.'),
 ('Prefer whole-column code to row loops',
  '20261031-05, 20261104-01, 20261104-02, 20261110-04, 20261114-10',
  'Column operators, np.where/select, groupby built-ins first; apply(lambda) only when nothing else fits.'),
 ('Load only what you need',
  '20261030-14, 20261030-15, 20261030-16, 20261030-18',
  'Estimate rows x columns x 8 bytes. Select columns and filter rows before collecting; sink big outputs to '
  'disk.'),
 ("Text that looks like a date or number isn't one",
  '20261029-04, 20261029-12, 20261030-13, 20261030-20, 20261031-03, 20261031-09, 20261111-02, 20261111-11, '
  '20261114-03',
  'Read IDs as text; give date formats explicitly; convert with to_datetime / to_timedelta / Int64.'),
 ('Excel changes data when it saves',
  '20261030-02, 20261030-05, 20261030-21',
  'Never save a CSV from Excel. Long IDs become 2.61029E+17 and times become 59:48.4 for good.'),
 ('Trust only output from a fresh run',
  '20261030-07, 20261030-16, 20261031-12, 20261110-09, 20261110-11, 20261111-09, 20261111-13, 20261112-03, '
  '20261112-06, 20261116-04',
  'Restart and Run All before trusting a number; close output files in Excel before writing them.'),
 ('Put setup in the first cell',
  '20261112-03, 20261112-04, 20261112-06, 20261116-04',
  'Imports, sys.path and helpers live in cell 1. After a restart or a replaced file, run from the top, and '
  'check that folders and files exist before importing from them.'),
 ('Measure before optimising',
  '20261114-08, 20261114-10, 20261114-11',
  'Three speed claims changed once measured: map vs merge, replace vs map, and the fastest '
  'first-row-per-group method. Time each stage on realistic data, then change what costs most.')]
