DAY10 = {
    "date": "Saturday, 14 November 2026 (covers 13 to 14 Nov)",
    "focus": "Parents and children in SQL, Excel FILTER and COUNTIFS fixes, a days-since function done "
             "properly, the call-list script rebuilt and measured for speed, and the hash-map, pandas-pattern "
             "and professional-Python notes.",
    "outcome": "13 entries: 3 errors, 5 wrong results and 5 how-tos. The call-list report runs 1.8x faster "
               "while doing more, and its counts are explained client by client against the old script.",
    "review": "Repeated: blanks that silently dropped rows (never-called clients, error cells) and claims that "
              "changed once measured (map vs merge, first row per group). Open: confirm INCLUDE_NEVER_CALLED "
              "and DATA_TZ for the call list with the team.",
}

ENTRIES10 = [
    {
        "id": "20261114-01", "tool": "SQL", "type": "Wrong result",
        "title": "The self-join returned the grandparent, not the parent",
        "tags": "self-join, referrer, WHERE IN",
        "problem": "Needed the parents and children of a list of clients. The query joined "
                   "customer_trading_profiles to itself and selected ctp1.referrer_client_id.",
        "cause": "Each row already holds its parent in referrer_client_id; joining up one level and reading the "
                 "joined row's referrer gives the parent's parent. WHERE zynixx_client_id was also ambiguous.",
        "code": r'''SELECT ctp.zynixx_client_id, ctp.referrer_client_id
FROM customer_trading_profiles ctp
WHERE ctp.zynixx_client_id  IN ('S217514', 'K206045')    -- their own rows -> their parents
   OR ctp.referrer_client_id IN ('S217514', 'K206045')   -- rows they referred -> their children''',
        "why": [
            "One link column, read in two directions: by the child gives the parent, by the parent gives children.",
            "A CASE column (or UNION ALL of two queries) labels which kind each row is.",
            "In Metabase, {{client_ids}} in each IN avoids repeating the list.",
        ],
        "lesson": "Before joining a table to itself, check whether the answer is already in the row.",
    },
    {
        "id": "20261114-02", "tool": "Excel", "type": "Wrong result",
        "title": "COUNTIFS gave 0 when dragged right",
        "tags": "absolute references, $",
        "problem": "=COUNTIFS(Sheet1!$D:$D,Sheet2!$D3,Sheet1!B:B,\"Above 50K\",Sheet1!F:F,\"Not Called "
                   "Yesterday\") returned 0 in every column after dragging right.",
        "cause": "B:B and F:F weren't locked, so dragging right moved them to C:C and G:G, the wrong columns.",
        "code": r'''=COUNTIFS(Sheet1!$D:$D, $D3, Sheet1!$B:$B, E$2, Sheet1!$F:$F, E$1)

$D:$D   column locked          $D3   column locked, row moves
E$2     row locked, column moves (criteria from the headers)''',
        "why": [
            "$ before the letter locks the column; $ before the number locks the row.",
            "Criteria read from header cells let each column count something different.",
            "If still 0, test each condition alone with COUNTIF to find the text that doesn't match.",
        ],
        "lesson": "Before dragging, decide for every reference what must stay still.",
    },
    {
        "id": "20261114-03", "tool": "Excel", "type": "Error",
        "title": "#VALUE! from FILTER",
        "tags": "FILTER, IFERROR, numbers as text",
        "problem": "=FILTER(Raw!A:AO,(Raw!G:G=\"Inactive\")*(Raw!AF:AF>3)) returned #VALUE!.",
        "cause": "Cells in the tested column hold errors (or text), and one error in the condition makes FILTER "
                 "return that error.",
        "code": r'''=FILTER(Raw!A2:AO100000,
        (TRIM(Raw!G2:G100000) = "Inactive") * (IFERROR(--Raw!AF2:AF100000, 0) > 3),
        "No rows")''',
        "why": [
            "IFERROR(..., 0) turns an error cell into a 0, so its row is simply left out.",
            "-- turns numbers stored as text into numbers; Excel ranks any text above every number.",
            "Bounded ranges skip a million empty rows; \"No rows\" replaces #CALC! when nothing matches.",
        ],
        "lesson": "Count error cells first: =SUMPRODUCT(--ISERROR(range)).",
    },
    {
        "id": "20261114-04", "tool": "Excel", "type": "Wrong result",
        "title": "AND() inside FILTER, and + used where * was meant",
        "tags": "array logic, AND, OR",
        "problem": "=FILTER(..., (G=\"Active\")+(AND(AA>1, AA<4)+(AG>2))) gave wrong rows.",
        "cause": "AND() squeezes a whole column into one TRUE or FALSE, and + means OR, so far more rows "
                 "qualified than intended.",
        "code": r'''=FILTER(Raw!A2:AP35505,
        (Raw!G2:G35505="Active") * (Raw!AA2:AA35505>1) * (Raw!AA2:AA35505<4) * (Raw!AG2:AG35505>2),
        "No rows")''',
        "why": [
            "Inside array formulas: * is AND, + is OR, one bracket per condition.",
            "* is worked out before +, so a between test (x>1)*(x<4) stays together.",
            ">1 and <4 keep only 2 and 3 for whole numbers; use >= and <= to include the ends.",
        ],
        "lesson": "In array formulas, write each condition as its own column test.",
    },
    {
        "id": "20261114-05", "tool": "Excel", "type": "How-to",
        "title": "FILTER on one of several statuses",
        "tags": "OR in brackets, MATCH",
        "problem": "Needed status Sleep OR Stale, with AG above 3 for both.",
        "cause": "Without brackets around the OR, * binds first: 'Sleep (any AG) or Stale with AG > 3'.",
        "code": r'''=FILTER(Raw!A:AP, ((Raw!G:G="Sleep") + (Raw!G:G="Stale")) * (Raw!AG:AG>3), "No rows")
=FILTER(Raw!A:AP, ISNUMBER(MATCH(Raw!G:G, {"Sleep","Stale"}, 0)) * (Raw!AG:AG>3), "No rows")''',
        "why": [
            "Brackets make the OR one condition, which then applies with the AG test.",
            "MATCH against a list in braces scales: add a status inside the braces.",
        ],
        "lesson": "Bracket every OR group before combining it with AND.",
    },
    {
        "id": "20261114-06", "tool": "pandas", "type": "Error",
        "title": "TypeError: Cannot subtract tz-naive and tz-aware datetime-like objects",
        "tags": "time zones, tz_localize, tz_convert",
        "problem": "difference(x, y) subtracted the parsed column from pd.Timestamp.now(tz='UTC').",
        "cause": "'today' had a time zone, the parsed dates didn't. It also counted days on the UTC calendar "
                 "and overwrote the caller's column.",
        "code": r'''def days_since(dates, as_of=None, data_tz="Asia/Kolkata", report_tz="Asia/Kolkata"):
    d = pd.to_datetime(dates, format="ISO8601")
    d = d.dt.tz_localize(data_tz) if d.dt.tz is None else d
    d = d.dt.tz_convert(report_tz)
    now = pd.Timestamp.now(tz=report_tz) if as_of is None else pd.Timestamp(as_of)
    now = now.tz_localize(report_tz) if now.tzinfo is None else now.tz_convert(report_tz)
    return (now.normalize() - d.dt.normalize()).dt.days.astype("Int64")''',
        "why": [
            "tz_localize labels a naive time; tz_convert moves an aware time to another zone.",
            "20:00 UTC on 10 Nov is 1 day ago in IST but 2 in UTC: the calendar must be chosen.",
            "Returning a Series leaves the caller's data alone; Int64 keeps blanks blank.",
        ],
        "lesson": "Bring both sides to the same zone before subtracting, and say which calendar counts.",
    },
    {
        "id": "20261114-07", "tool": "pandas", "type": "Wrong result",
        "title": "The call-list script dropped never-called clients and 'Active ' statuses",
        "tags": "NaN comparisons, strip, duplicates",
        "problem": "Run on a sample export, the P1-P4 counts were too low in some places and too high in others.",
        "cause": "Blank > 4 is False, so never-called clients left P2-P4; 'Active ' (trailing space) missed the "
                 "mapping; duplicated clients counted twice; errors='coerce' blanked dates silently.",
        "code": r'''df[col] = df[col].astype("string").str.strip()                  # 'Active ' -> 'Active'
df = df.drop_duplicates("client_id")
gap_ok = gap.isna() | call.gt(gap).fillna(False) | (call.isna() & INCLUDE_NEVER_CALLED)
checks["unreadable_last_txn"] = int((raw.notna() & days.isna()).sum())''',
        "why": [
            "Every difference from the old script was traced client by client: 11 'Active ' clients, 2 duplicates.",
            "Never-called clients are now included on purpose, by a named setting, not dropped by accident.",
            "The run prints its checks, so problems in the export are visible.",
        ],
        "lesson": "When a rewrite changes the numbers, explain every difference before trusting either.",
    },
    {
        "id": "20261114-08", "tool": "Python", "type": "How-to",
        "title": "Speeding up the call list: measure first, then change",
        "tags": "pyarrow, groupby, Parquet, timings",
        "problem": "The report had to run fast enough for a cloud job.",
        "cause": "Guessing at speed-ups wastes effort; timing each stage on 500,000 rows showed where the time "
                 "actually went.",
        "code": r'''pd.read_csv(path, usecols=cols, engine="pyarrow")         # 1,022 ms -> 156 ms
table.groupby([owner, "priority"]).size().unstack()        # 2.6x faster than pd.crosstab
call_list.to_parquet(path)                                  # 2.8 s, against 50 s for Excel
# end to end: 2,082 ms -> 1,135 ms, while doing more''',
        "why": [
            "Reading and saving were the big costs; the rules themselves were cheap.",
            "Writing 421,582 rows to Excel took 50 s, so large lists now go to CSV or Parquet.",
            "A faster date parser was rejected: it could blank valid dates in unexpected formats.",
        ],
        "lesson": "Measure each stage before optimising, and keep only the changes that pay off safely.",
    },
    {
        "id": "20261114-09", "tool": "Python", "type": "Wrong result",
        "title": "A heap and pandas picked different 'top 5' clients",
        "tags": "ties, heapq, sort order",
        "problem": "heapq.nlargest and DataFrame.nlargest returned different top-5 lists for the same data.",
        "cause": "13 never-called clients tied for most urgent, and each method broke ties its own way.",
        "code": r'''top5 = heapq.nsmallest(5, zip(-gap, p1["client_id"]))      # biggest gap, then lowest ID
top5_pd = p1.sort_values(["gap", "client_id"], ascending=[False, True]).head(5)''',
        "why": [
            "With a stated tie-break, both methods returned the same five clients.",
            "Without one, the order of tied rows can change from run to run.",
        ],
        "lesson": "A ranking needs a stated tie-break before it means anything.",
    },
    {
        "id": "20261114-10", "tool": "pandas", "type": "How-to",
        "title": "Hash maps measured on a 1-million-row ledger",
        "tags": "set vs list, map, replace, category",
        "problem": "Which lookups are actually faster, rather than assumed to be.",
        "cause": "Measured: the big wins were set vs list and categories; pandas vs a good dict loop was "
                 "only 1.5-3x.",
        "code": r'''x in some_set         # vs a list of 10,000 IDs: about 1,800x faster
s.map(d).fillna(s)    # recode: about 8x faster than s.replace(d), same result
s.astype("category")  # 55x less memory, groupby about 5x faster''',
        "why": [
            "The first draft overstated pandas' advantage; the notes now follow the measurements.",
            "map vs merge was close on one dataset and not on another: choose by what each does.",
        ],
        "lesson": "Never test membership against a list inside a loop.",
    },
    {
        "id": "20261114-11", "tool": "pandas", "type": "How-to",
        "title": "First row per group: idxmin was faster than sort + drop_duplicates",
        "tags": "idxmin, drop_duplicates, measured",
        "problem": "Which way to take each client's first deposit is fastest.",
        "cause": "idxmin finds each group's winner without sorting everything (24 ms vs 63 ms on 1M rows).",
        "code": r'''first = deps.loc[deps.groupby("ClientID")["CreatedAt"].idxmin()]       # one deciding column
first = deps.sort_values(["converted_at", "lead_date"]).drop_duplicates("ClientID")   # several''',
        "why": [
            "idxmin / idxmax when one column decides the winner.",
            "sort + drop_duplicates when several columns or a tie-break decide it.",
        ],
        "lesson": "Pick the tool by how many columns decide the winner.",
    },
    {
        "id": "20261114-12", "tool": "pandas", "type": "Error",
        "title": "ChainedAssignmentError: chained assignment never changes the data (pandas 3)",
        "tags": "copy-on-write, .loc",
        "problem": "df[df['x'] > 1]['y'] = 99 left df unchanged and warned ChainedAssignmentError.",
        "cause": "In pandas 3 a filtered table is always a separate copy (copy-on-write); in pandas 2 the same "
                 "line warns SettingWithCopyWarning.",
        "code": r'''df.loc[df["x"] > 1, "y"] = 99        # change the original
part = df[df["x"] > 1].copy()        # or work on a separate table on purpose''',
        "why": [
            ".loc[mask, col] = value is one operation on the table you mean.",
            "Changing a filtered result is now safe and never touches the original.",
        ],
        "lesson": "Change data with .loc on the table you own.",
    },
    {
        "id": "20261114-13", "tool": "Python", "type": "How-to",
        "title": "Ruff and pytest: checks that apply to everyone's code",
        "tags": "ruff, pytest, pyproject.toml",
        "problem": "Wanted code that doesn't look like a beginner wrote it.",
        "cause": "Ruff found 9 problems in a beginner-style script (unused imports, a mutable default, a bare "
                 "except). The rewritten version first failed too: lines over 88 characters.",
        "code": r'''ruff format my_script.py     # fixes layout; long comments still need hand edits
ruff check my_script.py      # finds problems, each with a code to look up
pytest -q                    # runs every test_ function''',
        "why": [
            "Tools catch mechanical problems; names, structure and hidden side effects still need judgement.",
            "pyproject.toml keeps the same rules for every file.",
        ],
        "lesson": "Run the formatter, the checker and the tests before calling code done.",
    },
]
