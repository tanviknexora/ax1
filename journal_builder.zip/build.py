import re
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, PageBreak,
                                Table, TableStyle, Preformatted, CondPageBreak, KeepTogether, NextPageTemplate)

from entries import DAY, ENTRIES
from entries_30 import DAY2, ENTRIES2
from entries_31 import DAY3, ENTRIES3
from entries_02 import DAY4, ENTRIES4
from entries_04 import DAY5, ENTRIES5
from entries_09 import DAY6, ENTRIES6
from entries_10 import DAY7, ENTRIES7
from entries_11 import DAY8, ENTRIES8
from entries_12 import DAY9, ENTRIES9
from entries_14 import DAY10, ENTRIES10
from entries_16 import DAY11, ENTRIES11
from patterns import PATTERNS

DAYS = [(DAY, ENTRIES), (DAY2, ENTRIES2), (DAY3, ENTRIES3), (DAY4, ENTRIES4), (DAY5, ENTRIES5),
        (DAY6, ENTRIES6), (DAY7, ENTRIES7), (DAY8, ENTRIES8), (DAY9, ENTRIES9),
        (DAY10, ENTRIES10), (DAY11, ENTRIES11)]
ALL = [e for _, es in DAYS for e in es]

# Check every card before building, so a mistake names the card instead of crashing later.
FIELDS = ("id", "tool", "type", "title", "tags", "problem", "cause", "code", "why", "lesson")
TYPES = ("Error", "Wrong result", "How-to")
for e in ALL:
    card = e.get("id", "a card with no id")
    missing = [f for f in FIELDS if f not in e]
    if missing:
        raise SystemExit(f"Card {card} is missing: {', '.join(missing)}")
    if e["type"] not in TYPES:
        raise SystemExit(f"Card {card}: type is {e['type']!r}; use one of {', '.join(TYPES)}")
    if not isinstance(e["why"], list):
        raise SystemExit(f"Card {card}: 'why' must be a list: [\"first reason\", \"second\"]")
_ids = [e["id"] for e in ALL]
_twice = sorted({i for i in _ids if _ids.count(i) > 1})
if _twice:
    raise SystemExit(f"Card IDs used twice: {', '.join(_twice)}")
_unknown = sorted({i.strip() for _, seen, _ in PATTERNS for i in seen.split(",")} - set(_ids))
if _unknown:
    raise SystemExit(f"patterns.py names card IDs that don't exist: {', '.join(_unknown)}")

# Fonts: DejaVu on Linux (or in a fonts folder next to this file); Arial and Consolas on Windows.
from pathlib import Path
HERE = Path(__file__).resolve().parent
OUT_PDF = HERE / 'Troubleshooting_Journal_Vol1.pdf'
DEJAVU = {'Sans': 'DejaVuSans.ttf', 'Sans-Bold': 'DejaVuSans-Bold.ttf',
          'Sans-Oblique': 'DejaVuSans-Oblique.ttf', 'Mono': 'DejaVuSansMono.ttf',
          'Mono-Bold': 'DejaVuSansMono-Bold.ttf'}
WINDOWS = {'Sans': 'arial.ttf', 'Sans-Bold': 'arialbd.ttf', 'Sans-Oblique': 'ariali.ttf',
           'Mono': 'consola.ttf', 'Mono-Bold': 'consolab.ttf'}
for folder, names in [(HERE / 'fonts', DEJAVU), (Path('/usr/share/fonts/truetype/dejavu'), DEJAVU),
                      (Path('C:/Windows/Fonts'), WINDOWS)]:
    if all((folder / f).exists() for f in names.values()):
        for name, f in names.items():
            pdfmetrics.registerFont(TTFont(name, str(folder / f)))
        break
else:
    raise FileNotFoundError('No fonts found: put the DejaVu .ttf files in a "fonts" folder here')
from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily('Sans', normal='Sans', bold='Sans-Bold', italic='Sans-Oblique', boldItalic='Sans-Bold')

INK = colors.HexColor('#1f2328')
MUTED = colors.HexColor('#5b6470')
ACCENT = colors.HexColor('#2f5fb3')
RULE = colors.HexColor('#d0d7de')
SOFT = colors.HexColor('#f3f5f8')
CODEBG = colors.HexColor('#f6f8fa')
LESSON_BG = colors.HexColor('#eaf1fb')
TYPE_COL = {'Error': colors.HexColor('#b42318'), 'Wrong result': colors.HexColor('#a15c07'),
            'How-to': colors.HexColor('#1f7a4d')}

W, H = A4
LM = RM = 18 * mm
TM, BM = 18 * mm, 20 * mm
CW = W - LM - RM

body = ParagraphStyle('body', fontName='Sans', fontSize=9.4, leading=13.2, textColor=INK, alignment=TA_LEFT)
small = ParagraphStyle('small', parent=body, fontSize=8.4, leading=11.4)
muted = ParagraphStyle('muted', parent=body, textColor=MUTED, fontSize=8.6, leading=12)
label = ParagraphStyle('label', parent=body, fontName='Sans-Bold', fontSize=8.2, leading=11,
                       textColor=MUTED, spaceBefore=5, spaceAfter=1.5)
h1 = ParagraphStyle('h1', parent=body, fontName='Sans-Bold', fontSize=19, leading=24, spaceAfter=6)
h2 = ParagraphStyle('h2', parent=body, fontName='Sans-Bold', fontSize=13, leading=17, spaceBefore=10, spaceAfter=5)
h3 = ParagraphStyle('h3', parent=body, fontName='Sans-Bold', fontSize=10.5, leading=14, spaceBefore=8, spaceAfter=3)
bullet = ParagraphStyle('bullet', parent=body, leftIndent=11, bulletIndent=2, spaceAfter=1.5, bulletFontName='Sans')
code_style = ParagraphStyle('code', fontName='Mono', fontSize=7.5, leading=9.6, textColor=INK)
cell = ParagraphStyle('cell', parent=body, fontSize=8.4, leading=11.2)
cellb = ParagraphStyle('cellb', parent=cell, fontName='Sans-Bold')
head = ParagraphStyle('head', parent=cell, fontName='Sans-Bold', textColor=colors.white)


def md(text):
    """Escape XML, then turn `code` into monospace and **x** into bold."""
    t = text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    t = re.sub(r'`([^`]+)`', r'<font name="Mono" size="8.2">\1</font>', t)
    t = re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', t)
    return t


def P(text, style=body):
    return Paragraph(md(text), style)


def code_block(src):
    pre = Preformatted(src, code_style, maxLineLength=103, newLineChars='    ')
    t = Table([[pre]], colWidths=[CW])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), CODEBG),
        ('BOX', (0, 0), (-1, -1), 0.6, RULE),
        ('LEFTPADDING', (0, 0), (-1, -1), 7), ('RIGHTPADDING', (0, 0), (-1, -1), 7),
        ('TOPPADDING', (0, 0), (-1, -1), 6), ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    return t


def boxed(flowables, bg=SOFT, border=RULE):
    t = Table([[flowables]], colWidths=[CW])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), bg),
        ('BOX', (0, 0), (-1, -1), 0.6, border),
        ('LEFTPADDING', (0, 0), (-1, -1), 9), ('RIGHTPADDING', (0, 0), (-1, -1), 9),
        ('TOPPADDING', (0, 0), (-1, -1), 7), ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
    ]))
    return t


def grid(rows, widths, header=True, zebra=True):
    t = Table(rows, colWidths=widths, repeatRows=1 if header else 0)
    st = [
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LINEBELOW', (0, 0), (-1, -1), 0.4, RULE),
        ('LEFTPADDING', (0, 0), (-1, -1), 5), ('RIGHTPADDING', (0, 0), (-1, -1), 5),
        ('TOPPADDING', (0, 0), (-1, -1), 4), ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]
    if header:
        st += [('BACKGROUND', (0, 0), (-1, 0), ACCENT)]
    if zebra:
        for r in range(1 if header else 0, len(rows)):
            if r % 2 == 0:
                st.append(('BACKGROUND', (0, r), (-1, r), SOFT))
    t.setStyle(TableStyle(st))
    return t


def type_tag(typ):
    c = TYPE_COL[typ].hexval()[2:]
    return f'<font color="#{c}"><b>{typ}</b></font>'


# ---------- page decorations ----------
def on_cover(canv, doc):
    canv.saveState()
    canv.setFillColor(ACCENT)
    canv.rect(0, H - 92 * mm, W, 92 * mm, stroke=0, fill=1)
    canv.restoreState()


def on_page(canv, doc):
    canv.saveState()
    canv.setStrokeColor(RULE)
    canv.setLineWidth(0.5)
    canv.line(LM, BM - 7 * mm, W - RM, BM - 7 * mm)
    canv.setFont('Sans', 7.6)
    canv.setFillColor(MUTED)
    canv.drawString(LM, BM - 11 * mm, 'Troubleshooting Journal  ·  Volume 1  ·  Oct to Nov 2026')
    canv.drawRightString(W - RM, BM - 11 * mm, f'Page {doc.page}')
    canv.restoreState()


doc = BaseDocTemplate(str(OUT_PDF), pagesize=A4,
                      leftMargin=LM, rightMargin=RM, topMargin=TM, bottomMargin=BM,
                      title='Troubleshooting Journal - Volume 1 (October 2026)',
                      author='Nexora data and analytics', subject='Daily troubleshooting log')
frame = Frame(LM, BM, CW, H - TM - BM, id='f', leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
doc.addPageTemplates([PageTemplate(id='cover', frames=[frame], onPage=on_cover),
                      PageTemplate(id='main', frames=[frame], onPage=on_page)])

S = []

# ---------- cover ----------
cover_title = ParagraphStyle('ct', parent=h1, fontSize=30, leading=36, textColor=colors.white)
cover_sub = ParagraphStyle('cs', parent=body, fontSize=12, leading=17, textColor=colors.white)
S += [Spacer(1, 22 * mm), Paragraph('Troubleshooting Journal', cover_title), Spacer(1, 4 * mm),
      Paragraph('Data and analytics work at Nexora: pandas, PostgreSQL, Metabase and Excel', cover_sub),
      Spacer(1, 2 * mm), Paragraph('Volume 1  ·  October to November 2026', cover_sub), Spacer(1, 48 * mm)]
n_err = sum(e['type'] == 'Error' for e in ALL)
n_wr = sum(e['type'] == 'Wrong result' for e in ALL)
n_how = sum(e['type'] == 'How-to' for e in ALL)
stats = [[Paragraph('<b>Days logged</b>', cell), Paragraph('<b>Entries</b>', cell),
          Paragraph('<b>Errors</b>', cell), Paragraph('<b>Wrong results</b>', cell), Paragraph('<b>How-tos</b>', cell)],
         [Paragraph(str(len(DAYS)), h2), Paragraph(str(len(ALL)), h2), Paragraph(str(n_err), h2),
          Paragraph(str(n_wr), h2), Paragraph(str(n_how), h2)]]
st = Table(stats, colWidths=[CW / 5] * 5)
st.setStyle(TableStyle([('LINEABOVE', (0, 0), (-1, 0), 0.8, ACCENT), ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                        ('LEFTPADDING', (0, 0), (-1, -1), 0)]))
S += [st, Spacer(1, 10 * mm)]
contents = [
    ('How this journal works', 'Structure, the log card fields and the daily routine'),
    ('Index', 'Every entry on one page: search by tool, type or tag'),
    ('Patterns', 'Lessons that came up more than once'),
    ('Day pages', '  ·  '.join(f"{d['date'].split(', ')[1]}: {len(es)} entries" for d, es in DAYS)),
    ('Templates', 'A blank day page and log card to copy for each new day'),
]
crow = [[Paragraph(f'<b>{a}</b>', cell), Paragraph(b, cell)] for a, b in contents]
ct = Table([[Paragraph('<b>Contents</b>', cellb), '']] + crow, colWidths=[48 * mm, CW - 48 * mm])
ct.setStyle(TableStyle([('LINEBELOW', (0, 0), (-1, -1), 0.4, RULE), ('LEFTPADDING', (0, 0), (-1, -1), 0),
                        ('TOPPADDING', (0, 0), (-1, -1), 4), ('BOTTOMPADDING', (0, 0), (-1, -1), 4)]))
S += [ct, NextPageTemplate('main'), PageBreak()]

# ---------- how it works ----------
S.append(Paragraph('How this journal works', h1))
S.append(P('Every problem you solve becomes one log card, filed under the day it happened. The Index lets you '
           'find any card by tool, type or tag, and the Patterns page collects the lessons that keep coming back.'))
S.append(Paragraph('The four parts', h2))
parts = [['Part', 'What it holds', 'Update it'],
         ['Index', 'One line per card: ID, tool, type, title, tags', 'After every new card'],
         ['Patterns', 'Lessons seen on two or more cards, with what to do', 'Weekly review'],
         ['Day pages', 'Date, focus, outcome, then the day\'s log cards', 'During and at the end of each day'],
         ['Templates', 'A blank day page and log card', 'Copy one for each new day']]
S.append(grid([[Paragraph(c, head) for c in parts[0]]] +
              [[Paragraph(f'<b>{r[0]}</b>', cell), P(r[1], cell), P(r[2], cell)] for r in parts[1:]],
              [30 * mm, 90 * mm, CW - 120 * mm]))
S.append(Paragraph('The log card', h2))
fields = [['Field', 'What to write'],
          ['ID', 'Date plus a running number: `20261029-05` is the 5th card on 29 Oct 2026. Sorts by date automatically.'],
          ['Tool', 'pandas, SQL, Excel, Python, Metabase, Bash.'],
          ['Type', '**Error**: a message appeared.  **Wrong result**: no error, but the output was wrong.  '
                   '**How-to**: a new task you worked out.'],
          ['Tags', '2 to 4 search words: the function or concept, e.g. `ROW_NUMBER`, merge, dates.'],
          ['Problem', 'Exactly what you saw. Paste the error text word for word, so you can search for it later.'],
          ['Cause', 'Why it happened, in one or two sentences.'],
          ['Fix', 'The code that worked, trimmed to the lines that matter.'],
          ['Why it works', 'The two to four details you would forget in a month.'],
          ['Lesson', 'One line you could apply to a different problem.']]
S.append(grid([[Paragraph(c, head) for c in fields[0]]] +
              [[Paragraph(f'<b>{r[0]}</b>', cell), P(r[1], cell)] for r in fields[1:]],
              [30 * mm, CW - 30 * mm]))
S.append(Paragraph('The routine', h2))
routine = [
    '**As soon as a problem is solved**, write its card. Five minutes now saves an hour of re-asking later.',
    '**At the end of the day**, fill the day\'s Focus and Outcome lines and add the cards to the Index.',
    '**Once a week**, scan the Index. Any lesson that appears on two cards goes on the Patterns page.',
    '**Once a month**, start a new volume. Carry the Index and Patterns forward.',
    '**Before asking for help**, search the Index for the error text or a tag. The answer may already be here.',
]
for i, r in enumerate(routine, 1):
    S.append(Paragraph(md(r), bullet, bulletText=f'{i}.'))
S.append(Spacer(1, 3 * mm))
S.append(boxed([P('**Keeping it searchable.** Paste error messages exactly, including quotes and capitals. '
                  'Searching this PDF (Ctrl+F) for `does not exist` or `has no attribute` finds every related card.',
                  small)], bg=LESSON_BG, border=ACCENT))
S.append(PageBreak())

# ---------- index ----------
S.append(Paragraph('Index', h1))
S.append(Paragraph('One line per log card, oldest first. Types: ' + type_tag('Error') +
                   ' = a message appeared, ' + type_tag('Wrong result') +
                   ' = wrong output with no error, ' + type_tag('How-to') + ' = a new task.', muted))
S.append(Spacer(1, 3 * mm))
irows = [[Paragraph(c, head) for c in ['ID', 'Tool', 'Type', 'Title', 'Tags']]]
for e in ALL:
    irows.append([Paragraph(f'<font name="Mono" size="8">{e["id"]}</font>', cell), P(e['tool'], cell),
                  Paragraph(type_tag(e['type']), cell), P(e['title'], cell), P(e['tags'], cell)])
S.append(grid(irows, [25 * mm, 16 * mm, 22 * mm, 74 * mm, CW - 137 * mm]))
S.append(PageBreak())

# ---------- patterns ----------
S.append(Paragraph('Patterns', h1))
S.append(P('Lessons that showed up on more than one card. Read this page first when something looks wrong '
           'but no error appears.', muted))
S.append(Spacer(1, 3 * mm))
prow = [[Paragraph(c, head) for c in ['Pattern', 'Seen in', 'What to do']]]
for name, seen, todo in PATTERNS:
    prow.append([Paragraph(f'<b>{md(name)}</b>', cell),
                 Paragraph(f'<font name="Mono" size="7.8">{seen.replace(", ", "<br/>")}</font>', cell),
                 P(todo, cell)])
S.append(grid(prow, [52 * mm, 28 * mm, CW - 80 * mm]))
S.append(Spacer(1, 6 * mm))
S.append(Paragraph('SQL run order (the reason behind several patterns)', h3))
order = 'FROM / JOIN  →  WHERE  →  GROUP BY  →  HAVING  →  window functions  →  SELECT  →  DISTINCT  →  ORDER BY  →  LIMIT'
S.append(boxed([Paragraph(order, ParagraphStyle('o', parent=small, fontName='Mono', fontSize=8))]))
S.append(PageBreak())

# ---------- day pages ----------
for DAYX, ENTX in DAYS:
    S.append(Paragraph(DAYX['date'], h1))
    day_rows = [[Paragraph('<b>Focus</b>', cell), P(DAYX['focus'], cell)],
                [Paragraph('<b>Outcome</b>', cell), P(DAYX['outcome'], cell)]]
    if DAYX.get('review'):
        day_rows.append([Paragraph('<b>Review</b>', cell), P(DAYX['review'], cell)])
    day_rows.append([Paragraph('<b>Cards</b>', cell),
                     Paragraph(f'<font name="Mono" size="8">{ENTX[0]["id"]}</font> to '
                               f'<font name="Mono" size="8">{ENTX[-1]["id"]}</font>', cell)])
    dt = Table(day_rows, colWidths=[24 * mm, CW - 24 * mm])
    dt.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), SOFT), ('BOX', (0, 0), (-1, -1), 0.6, RULE),
                            ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('LINEBELOW', (0, 0), (-1, -2), 0.4, RULE),
                            ('TOPPADDING', (0, 0), (-1, -1), 5), ('BOTTOMPADDING', (0, 0), (-1, -1), 5)]))
    S += [dt, Spacer(1, 6 * mm)]

    for e in ENTX:
        S.append(CondPageBreak(70 * mm))
        hdr = Table([
            [Paragraph(f'<font name="Mono-Bold" size="9" color="#2f5fb3">{e["id"]}</font>', cell),
             Paragraph(f'<b>{md(e["title"])}</b>', ParagraphStyle('ht', parent=body, fontSize=10.5, leading=14))],
            ['', Paragraph(f'{md(e["tool"])}  ·  {type_tag(e["type"])}  ·  <font color="#5b6470">{md(e["tags"])}</font>', small)],
        ], colWidths=[28 * mm, CW - 28 * mm])
        hdr.setStyle(TableStyle([('LINEABOVE', (0, 0), (-1, 0), 1.6, TYPE_COL[e['type']]),
                                 ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('LEFTPADDING', (0, 0), (-1, -1), 0),
                                 ('TOPPADDING', (0, 0), (-1, 0), 6), ('TOPPADDING', (0, 1), (-1, 1), 1),
                                 ('BOTTOMPADDING', (0, 0), (-1, -1), 2)]))
        block = [hdr,
                 Paragraph('PROBLEM', label), P(e['problem']),
                 Paragraph('CAUSE', label), P(e['cause'])]
        S.append(KeepTogether(block))
        S.append(KeepTogether([Paragraph('FIX', label), code_block(e['code'])]))
        why = [Paragraph('WHY IT WORKS', label)] + [Paragraph(md(w), bullet, bulletText='•') for w in e['why']]
        why += [Spacer(1, 4), boxed([Paragraph(f'<b>Lesson:</b> {md(e["lesson"])}', small)], bg=LESSON_BG, border=ACCENT)]
        S.append(KeepTogether(why))
        S.append(Spacer(1, 9 * mm))

    S.append(PageBreak())

# ---------- templates ----------
S.append(Paragraph('Template: day page', h1))
S.append(P('Copy this page for each new day. Fill Focus in the morning and Outcome before you log off.', muted))
S.append(Spacer(1, 4 * mm))
blank = lambda h: Spacer(1, h)
tpl = Table([[Paragraph('<b>Date</b>', cell), ''],
             [Paragraph('<b>Focus</b>', cell), ''],
             [Paragraph('<b>Outcome</b>', cell), ''],
             [Paragraph('<b>Review</b>', cell), Paragraph('Repeated mistakes, gaps, one focus for tomorrow', muted)],
             [Paragraph('<b>Cards</b>', cell), Paragraph('__________  to  __________', muted)]],
            colWidths=[24 * mm, CW - 24 * mm], rowHeights=[10 * mm, 18 * mm, 18 * mm, 18 * mm, 10 * mm])
tpl.setStyle(TableStyle([('BOX', (0, 0), (-1, -1), 0.6, RULE), ('LINEBELOW', (0, 0), (-1, -2), 0.4, RULE),
                         ('BACKGROUND', (0, 0), (0, -1), SOFT), ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                         ('TOPPADDING', (0, 0), (-1, -1), 5)]))
S += [tpl, Spacer(1, 6 * mm), Paragraph('Index lines to add tonight', h3)]
idx_blank = [[Paragraph(c, head) for c in ['ID', 'Tool', 'Type', 'Title', 'Tags']]] + [[''] * 5 for _ in range(8)]
it = Table(idx_blank, colWidths=[25 * mm, 16 * mm, 22 * mm, 74 * mm, CW - 137 * mm],
           rowHeights=[None] + [8 * mm] * 8)
it.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), ACCENT), ('GRID', (0, 1), (-1, -1), 0.4, RULE)]))
S += [it, Spacer(1, 6 * mm), Paragraph('End-of-day check', h3)]
for c in ['Every solved problem has a card', 'Error messages pasted word for word',
          'Cards added to the Index', 'Any lesson seen before? Add it to Patterns']:
    S.append(Paragraph(md(c), bullet, bulletText='☐'))
S.append(PageBreak())

S.append(Paragraph('Template: log card', h1))
S.append(P('One card per problem. Two cards fit on a page when the fix is short.', muted))
S.append(Spacer(1, 4 * mm))


def card_tpl():
    rows = [[Paragraph('<b>ID</b>', cell), '', Paragraph('<b>Tool</b>', cell), '', Paragraph('<b>Type</b>', cell),
             Paragraph('Error  /  Wrong result  /  How-to', muted)],
            [Paragraph('<b>Title</b>', cell), '', '', '', '', ''],
            [Paragraph('<b>Tags</b>', cell), '', '', '', '', ''],
            [Paragraph('<b>Problem</b>', cell), '', '', '', '', ''],
            [Paragraph('<b>Cause</b>', cell), '', '', '', '', ''],
            [Paragraph('<b>Fix</b>', cell), '', '', '', '', ''],
            [Paragraph('<b>Why it works</b>', cell), '', '', '', '', ''],
            [Paragraph('<b>Lesson</b>', cell), '', '', '', '', '']]
    t = Table(rows, colWidths=[26 * mm, 30 * mm, 14 * mm, 26 * mm, 14 * mm, CW - 110 * mm],
              rowHeights=[8 * mm, 8 * mm, 8 * mm, 16 * mm, 12 * mm, 26 * mm, 14 * mm, 9 * mm])
    t.setStyle(TableStyle([
        ('BOX', (0, 0), (-1, -1), 0.8, ACCENT), ('INNERGRID', (0, 0), (-1, -1), 0.4, RULE),
        ('SPAN', (1, 1), (-1, 1)), ('SPAN', (1, 2), (-1, 2)), ('SPAN', (1, 3), (-1, 3)),
        ('SPAN', (1, 4), (-1, 4)), ('SPAN', (1, 5), (-1, 5)), ('SPAN', (1, 6), (-1, 6)), ('SPAN', (1, 7), (-1, 7)),
        ('BACKGROUND', (0, 0), (0, -1), SOFT), ('BACKGROUND', (2, 0), (2, 0), SOFT), ('BACKGROUND', (4, 0), (4, 0), SOFT),
        ('BACKGROUND', (1, 5), (-1, 5), CODEBG), ('BACKGROUND', (1, 7), (-1, 7), LESSON_BG),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('TOPPADDING', (0, 0), (-1, -1), 4)]))
    return t


S += [card_tpl(), Spacer(1, 8 * mm), card_tpl()]

doc.build(S)
print('built')
