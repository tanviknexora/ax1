# Troubleshooting Journal builder

Builds `Troubleshooting_Journal_Vol1.pdf` from plain Python files: one file per day, plus the
list of recurring patterns.

## What's here

| File | Contents |
| --- | --- |
| `build.py` | The layout: cover, contents, how-it-works page, index, patterns, day pages, blank templates |
| `entries.py`, `entries_30.py` ... `entries_16.py` | One file per day: a `DAY` dict and a list of cards |
| `patterns.py` | Lessons that came up more than once, with the card IDs behind each |
| `entries_template.py` | A blank day to copy for a new page |

## Run it

    pip install reportlab
    python build.py

The PDF is written next to `build.py`. On Windows it uses Arial and Consolas; for exactly the
same look as the original, put the free DejaVu fonts (DejaVuSans.ttf, -Bold, -Oblique,
DejaVuSansMono.ttf, -Bold) in a `fonts` folder here.

## Add a day

1. Copy `entries_template.py` to `entries_17.py` and fill it in.
2. In `build.py`, add `from entries_17 import DAY12, ENTRIES12` and `(DAY12, ENTRIES12)` to `DAYS`.
3. Add new card IDs to the matching patterns in `patterns.py`.
4. Run `python build.py`.

The cover's counts, the contents and the index update themselves.
