DAY4 = {
    "date": "Monday, 2 November 2026",
    "focus": "Lead sources for depositors, October traders by manager and agent, a per-client report of Sales calls "
             "after conversion, and IDs sharing an IP in Metabase. Also built the 115-exercise mastery workbook.",
    "outcome": "10 entries: 8 how-tos and 2 wrong results. Every join that could repeat rows was guarded "
               "before it could cause a problem.",
    "review": "Most extra rounds came from unclear output columns (the 30-day request took four rounds). "
              "Focus tomorrow: mastery workbook exercises 1 to 15, then progress().",
}

ENTRIES4 = [
    {
        "id": "20261102-01", "tool": "SQL", "type": "How-to",
        "title": "Lead source for depositing customers",
        "tags": "DISTINCT ON, self-join, COALESCE",
        "problem": "Needed Lead Source 1 and 2 for every customer with `total_deposit_count > 0`.",
        "cause": "A customer can have several leads, so joining `leads` directly repeats depositors. The source has a "
                 "parent source in the same `sources` table.",
        "code_lang": "sql",
        "code": r'''WITH lead_source AS (
    SELECT DISTINCT ON (l.customer_id) l.customer_id, l.id AS lead_id,
           COALESCE(s2.name, 'Unknown') AS lead_source_1, s1.name AS lead_source_2
    FROM leads l
    LEFT JOIN sources s1 ON l.source_two_id = s1.id
    LEFT JOIN sources s2 ON s1.parent_id = s2.id
    WHERE l.customer_id IS NOT NULL AND l.deleted_at IS NULL
    ORDER BY l.customer_id, l.date_of_lead, l.created_at, l.id
)
SELECT ctp.*, ls.lead_source_1, ls.lead_source_2
FROM customer_trading_profiles ctp
LEFT JOIN lead_source ls ON ls.customer_id = ctp.customer_id
WHERE ctp.total_deposit_count > 0;''',
        "why": [
            "`sources s1` and `sources s2` are the same table under two aliases: the source and its parent.",
            "`DISTINCT ON` + `ORDER BY date_of_lead` keeps the first lead; `DESC` would credit the latest.",
            "`l.deleted_at` carries its alias, so it can't become ambiguous when more tables join.",
        ],
        "lesson": "Cut a many-rows table to one row per key in a CTE before joining it.",
    },
    {
        "id": "20261102-02", "tool": "pandas", "type": "How-to",
        "title": "Flag which customers traded in October",
        "tags": "isin, np.where, Period",
        "problem": "Needed a Traded / Not Traded column on the filtered customer list for October.",
        "cause": "The October BILL rows hold the traders' IDs; each customer just needs checking against that set.",
        "code_lang": "python",
        "code": r'''led_req = led[led["ClientID"].isin(cust_req)].copy()
led_req = led_req[(led_req["LedgerType"] == "BILL") &
                  (led_req["CreatedAt"].dt.to_period("M") == pd.Period("2026-10", freq="M"))]

traded_ids = set(led_req["ClientID"].astype(str).str.strip())
customer_filtered = customer_filtered.copy()
customer_filtered["Oct Trading"] = np.where(
    customer_filtered["Client ID"].astype(str).str.strip().isin(traded_ids), "Traded", "Not Traded")''',
        "why": [
            "`isin` gives True/False per customer; `np.where` turns it into labels.",
            "Strip and cast both sides, so spaces or number-vs-text IDs can't hide a match.",
            "`.str.lower()` before `isin(['demo', 'suspended'])` also catches `Demo`.",
        ],
        "lesson": "A flag column is isin + np.where; clean both sides of the match first.",
    },
    {
        "id": "20261102-03", "tool": "pandas", "type": "How-to",
        "title": "Total and traded clients per Manager and agent",
        "tags": "groupby, nunique, where, subtotals",
        "problem": "Needed, per Manager and Assigned To, the number of clients and how many traded in October.",
        "cause": "A conditional distinct count needs only the traders' IDs in one column.",
        "code_lang": "python",
        "code": r'''cf = customer_filtered.copy()
cf["Assigned To"] = cf["Assigned To"].fillna("Unassigned")
cf["Traded_ID"] = cf["Client ID"].where(cf["Oct Trading"].eq("Traded"))

pivot = (cf.groupby(["Manager", "Assigned To"])
           .agg(Total_Clients=("Client ID", "nunique"), Traded_in_Oct=("Traded_ID", "nunique"))
           .reset_index())
pivot["Traded %"] = (pivot["Traded_in_Oct"] / pivot["Total_Clients"] * 100).round(1)''',
        "why": [
            "`.where(cond)` blanks non-traders; `nunique` ignores blanks, so it counts only traders.",
            "`fillna('Unassigned')` stops groupby dropping clients with no agent.",
            "Subtotals: group by Manager alone, label `Manager total`, concat, sort with a helper `_order` column.",
        ],
        "lesson": "Conditional distinct count = .where() then nunique, no lambda needed.",
    },
    {
        "id": "20261102-04", "tool": "SQL", "type": "Wrong result",
        "title": "Calls after conversion would repeat per lead",
        "tags": "fan-out, MIN, FILTER, STRING_AGG",
        "problem": "The first calls query joined `call_logs`, `customers`, `customer_trading_profiles` and `leads` together.",
        "cause": "A customer with two leads gets every call twice. Grouping only by `zynixx_client_id` would also merge "
                 "customers with no trading profile.",
        "code_lang": "sql",
        "code": r'''WITH conv AS (
    SELECT customer_id, MIN(converted_at) AS converted_at
    FROM leads WHERE converted_at IS NOT NULL GROUP BY customer_id
)
SELECT customer_id, zynixx_client_id,
       COUNT(*)                                                     AS calls_after_conversion,
       COUNT(*) FILTER (WHERE since_conversion <= INTERVAL '1 day') AS within_1_day,
       COUNT(answered_at)                                           AS answered_after_conversion,
       STRING_AGG(TO_CHAR(started_at AT TIME ZONE 'Asia/Kolkata', 'DD Mon YY HH24:MI'), ', ' ORDER BY started_at) AS call_times
FROM calls_after
GROUP BY customer_id, zynixx_client_id;''',
        "why": [
            "`MIN(converted_at)` per customer leaves one conversion date, so calls can't multiply.",
            "`COUNT(*)` counts rows; `COUNT(answered_at)` counts only non-blank values, so answered calls.",
            "Compare stored times (`started_at > converted_at`); convert time zones only for display.",
        ],
        "lesson": "Before joining a table, ask: how many rows per key does it have?",
    },
    {
        "id": "20261102-05", "tool": "SQL", "type": "How-to",
        "title": "Start from the pasted ID list so no ID disappears",
        "tags": "UNNEST, ARRAY, LEFT JOIN, check_status",
        "problem": "With `WHERE zynixx_client_id IN (...)`, IDs with no calls, or that didn't exist, vanished from the result.",
        "cause": "The query started from calls; an ID without calls never made it into a row.",
        "code_lang": "sql",
        "code": r'''WITH id_list AS (
    SELECT DISTINCT UNNEST(ARRAY['S221954', 'P227319', 'A226436']) AS zynixx_client_id
)
SELECT i.zynixx_client_id,
       CASE WHEN i.customer_id IS NULL   THEN 'ID not found'
            WHEN NOT i.in_scope          THEN 'Other portal/project'
            WHEN cv.converted_at IS NULL THEN 'No conversion date'
            ELSE 'OK' END AS check_status,
       COALESCE(a.calls_after_conversion, 0) AS calls_after_conversion
FROM ids i
LEFT JOIN conv cv ON cv.customer_id = i.customer_id
LEFT JOIN agg a   ON a.zynixx_client_id = i.zynixx_client_id;''',
        "why": [
            "`UNNEST(ARRAY[...])` turns the list into rows, in the same format as an IN list.",
            "LEFT JOINs from the list keep every ID; `check_status` explains each zero.",
            "Check: rows returned = distinct IDs pasted.",
        ],
        "lesson": "When the question is 'for these IDs', start the query from the IDs.",
    },
    {
        "id": "20261102-06", "tool": "SQL", "type": "How-to",
        "title": "Join a Metabase saved question safely",
        "tags": "{{#3268}}, DISTINCT ON, team list",
        "problem": "Needed agent, TL, manager and team for each call from saved question #3268.",
        "cause": "If an agent appears twice in the team list, joining it directly counts each of their calls twice.",
        "code_lang": "sql",
        "code": r'''team AS (
    SELECT DISTINCT ON (user_id) user_id, agents, tl, manager, team
    FROM {{#3268-team-main}}
    ORDER BY user_id
)
-- check first:
SELECT user_id, COUNT(*) FROM {{#3268-team-main}} GROUP BY user_id HAVING COUNT(*) > 1;''',
        "why": [
            "`{{#3268-...}}` uses a saved question like a table inside a native query.",
            "`STRING_AGG(DISTINCT agent, ', ' ORDER BY agent)` lists agents once each.",
            "`(ARRAY_AGG(agent ORDER BY started_at DESC))[1]` is the agent on the latest call.",
        ],
        "lesson": "Every lookup table gets a one-row-per-key guard, even a team list.",
    },
    {
        "id": "20261102-07", "tool": "SQL", "type": "How-to",
        "title": "Keep only the Sales team's calls",
        "tags": "JOIN vs LEFT JOIN, filter on joined table",
        "problem": "The report had to count only calls made by Sales agents.",
        "cause": "The team is a column of the joined team list, so the filter belongs on that table.",
        "code_lang": "sql",
        "code": r'''SELECT team, COUNT(*) AS agents FROM {{#3268-team-main}} GROUP BY team ORDER BY team;  -- exact values

JOIN team t ON t.user_id = cl.agent_user_id
WHERE ... AND t.team = 'Sales'          -- or ILIKE 'sales%' after checking the values''',
        "why": [
            "An inner JOIN plus `t.team = 'Sales'` drops calls by anyone else, including agents not in the list.",
            "Check the distinct values first, so `ILIKE 'sales%'` doesn't catch `Sales Support`.",
        ],
        "lesson": "Look at the real values of a column before filtering on it.",
    },
    {
        "id": "20261102-08", "tool": "SQL", "type": "How-to",
        "title": "30-day counts beside the day buckets",
        "tags": "FILTER, INTERVAL, cross-check",
        "problem": "Needed calls and answered calls within 30 days of conversion, keeping the existing buckets.",
        "cause": "Two more conditional counts in the same aggregation.",
        "code_lang": "sql",
        "code": r'''COUNT(*)           FILTER (WHERE since_conversion <= INTERVAL '30 days') AS calls_within_30_days,
COUNT(answered_at) FILTER (WHERE since_conversion <= INTERVAL '30 days') AS answered_within_30_days,''',
        "why": [
            "`FILTER` works on any aggregate, including `COUNT(column)`.",
            "Check: `calls_within_30_days = within_1_day + days_2_to_7 + days_8_to_30` on every row.",
        ],
        "lesson": "When two columns must agree, write the check down and run it.",
    },
    {
        "id": "20261102-09", "tool": "Process", "type": "Wrong result",
        "title": "A 30-day request rebuilt three times",
        "tags": "requirements, output columns",
        "problem": "\"Calls within 30 days\" became day_0 to day_30 columns, then a stripped query, then a query missing "
                   "the buckets, before the right version.",
        "cause": "It wasn't agreed whether the 30-day columns should replace or be added to the existing ones.",
        "code_lang": "text",
        "code": r'''Start from: <the query that's already right>
Add columns: <name> = <definition>, <name> = <definition>
Keep: everything else as it is
One row per: <client / agent / day>''',
        "why": [
            "Naming the exact columns, and what to keep, settles a change in one round.",
            "\"Replace\" or \"add\" is the question to settle before rewriting a working query.",
        ],
        "lesson": "Say what to keep, not only what to add.",
    },
    {
        "id": "20261102-10", "tool": "Metabase", "type": "How-to",
        "title": "Admin IDs that share an IP",
        "tags": "Summarize, distinct count, STRING_AGG, private IPs",
        "problem": "The editor showed how many Admin IDs used each IP, but not which IDs.",
        "cause": "Metabase's Summarize has no aggregation that lists values in one cell.",
        "code_lang": "sql",
        "code": r'''SELECT ip, COUNT(DISTINCT admin_id) AS admin_count,
       STRING_AGG(DISTINCT admin_id::text, ', ' ORDER BY admin_id::text) AS admin_ids
FROM tdx_activity
WHERE ip IS NOT NULL AND ip <> ''
GROUP BY ip
HAVING COUNT(DISTINCT admin_id) > 1
ORDER BY admin_count DESC;''',
        "why": [
            "View the SQL, then Convert this question to SQL, turns the editor question into editable SQL.",
            "A blank-IP row (10 admins) is missing data, not a shared address.",
            "`10.x` IPs are private (office, VPN, proxy); IP + user agent is a stronger same-device signal.",
        ],
        "lesson": "Know where the editor stops; switch to SQL for lists and complex logic.",
    },
]

PATTERNS = [
    ("Check the inputs before the code",
     "20261030-02, 20261031-08",
     "Print which files are read, from which folder, with row counts and date ranges, before changing any logic."),
    ("Repeated rows mean a one-to-many join or duplicate keys",
     "20261029-11, 20261029-12, 20261030-21, 20261102-01, 20261102-04, 20261102-06",
     "Collapse the many side to one row per key first. Check COUNT(*) = COUNT(DISTINCT key), "
     "validate='many_to_one', or duplicated(subset=key)."),
    ("Check what is really stored before filtering",
     "20261029-05, 20261029-08, 20261029-09, 20261030-03, 20261030-07, 20261102-07",
     "Look at real values and column names: df.columns, SELECT DISTINCT, SELECT ... LIMIT 1, COUNTIF with wildcards."),
    ("Agree the output before building",
     "20261102-09",
     "Name the columns to add, what to keep, and one row per what. Settle 'add' or 'replace' before rewriting."),
    ("Start from the thing every row must represent",
     "20261102-05",
     "Every ID must appear? Start from the IDs and LEFT JOIN the rest; label why a value is zero."),
    ("Duplicate or double-used names break things",
     "20261029-02, 20261030-19, 20261031-06",
     "Two columns with one name, or one column as both pivot key and value. Check names after every rename."),
    ("Never reuse built-in or existing names; names are not values",
     "20261029-01, 20261030-07, 20261030-12, 20261031-11",
     "min, max, all are functions; give each table its own name; os.environ takes a variable's name, not its value."),
    ("Assign results back, and sort by the right column",
     "20261030-01, 20261030-09",
     "sort_values returns a copy: write led = led.sort_values(...). For 'latest per key', sort by the date."),
    ("Verify against raw rows or an old version",
     "20261029-06, 20261029-07, 20261029-13, 20261030-02, 20261031-04",
     "Compare counts with raw data, and run old and new code on the same input before switching."),
    ("Build checks that fail loudly",
     "20261031-07, 20261031-09, 20261031-12, 20261102-05, 20261102-08",
     "assert impossible values, raise on unreadable dates, cross-check two outputs, label every zero."),
    ("Load only what you need",
     "20261030-14, 20261030-15, 20261030-16, 20261030-18",
     "Estimate rows x columns x 8 bytes. Select columns and filter rows before collecting; sink big outputs to disk."),
    ("Text that looks like a date or number isn't one",
     "20261029-04, 20261029-12, 20261030-13, 20261030-20, 20261031-03, 20261031-09",
     "Read IDs as text; give date formats explicitly; convert with to_datetime / to_timedelta / Int64."),
    ("Excel changes data when it saves",
     "20261030-02, 20261030-05, 20261030-21",
     "Never save a CSV from Excel. Long IDs become 2.61029E+17 and times become 59:48.4 for good."),
    ("Trust only output from a fresh run",
     "20261030-07, 20261030-16, 20261031-12",
     "Restart and Run All before trusting a number; close output files in Excel before writing them."),
]
