DAY7 = {
    "date": "Tuesday, 10 November 2026",
    "focus": "Broker referral program report: children per referrer by status, October activity, program targets "
             "(required active clients, new clients, trade value with 2% growth), monthly trade value columns and "
             "the status and conversion lookups.",
    "outcome": "11 entries: 1 error, 4 wrong results and 6 how-tos. The program report runs end to end with targets, "
               "eligibility and a reason per broker; monthly trade values reconcile with the ledger.",
    "review": "Repeated: business rules whose edge cases weren't tried (no active clients; just below the minimum) and "
              "one-to-many merges. Open: should '6 children' count demo children, and which 30-day window does the "
              "program mean? Focus tomorrow: confirm both, then export the program sheet.",
}

ENTRIES7 = [
    {
        "id": "20261110-01", "tool": "pandas", "type": "How-to",
        "title": "Every child in exactly one group: np.select with a priority",
        "tags": "np.select, named agg, is_demo as text",
        "problem": "Per referrer: Overall, Converted (first trade date), Not converted (no trade, not demo) and Demo, "
                   "where the three groups must add up to Overall.",
        "cause": "A demo account can also have a trade date, so 'traded' and 'demo' overlap. Groups only add up if "
                 "each child gets one label, decided in a fixed order.",
        "code": r'''kids = bf.drop_duplicates('zynixx_client_id').copy()
is_demo = kids['is_demo'].astype(str).str.strip().str.lower().isin(['true', 'yes', '1'])
traded = kids['first_trade_date'].notna()
kids['status'] = np.select([is_demo, traded], ['Demo', 'Converted'], default='Not converted')

summary = (kids.groupby('referrer_client_id')
               .agg(Parent=('referrer_name', 'first'), Overall=('zynixx_client_id', 'size'),
                    Converted=('status', lambda s: s.eq('Converted').sum()),
                    **{'Not converted': ('status', lambda s: s.eq('Not converted').sum())},
                    Demo=('status', lambda s: s.eq('Demo').sum())))''',
        "why": [
            "np.select takes the first true condition, so Demo is decided before Converted.",
            "Reading is_demo as text handles True/False and 'True'/'False' (Metabase exports).",
            "**{...} passes output names that contain spaces.",
        ],
        "lesson": "When categories must add up to a total, give each row one label, in a stated order.",
    },
    {
        "id": "20261110-02", "tool": "pandas", "type": "Wrong result",
        "title": "isin(is_demo) compared client IDs with True and False",
        "tags": "isin, boolean mask",
        "problem": "`non_demo = bf.loc[~bf['zynixx_client_id'].isin(is_demo), 'zynixx_client_id']` kept every "
                   "client, demo accounts included.",
        "cause": "is_demo is a True/False mask, not a list of IDs. No ID equals True or False, so isin() was "
                 "False everywhere and ~ made it True everywhere.",
        "code": r'''# a mask selects rows directly
real_ids = set(kids.loc[~kids['is_demo'], 'zynixx_client_id'])

# check: real + demo must equal all children
print(len(real_ids), kids['is_demo'].sum(), len(kids))''',
        "why": [
            "isin() wants values to look for; a mask is used with .loc[mask] or df[mask].",
            "The bug raised no error: only a count would have shown it.",
        ],
        "lesson": "After every filter, print how many rows it kept.",
    },
    {
        "id": "20261110-03", "tool": "pandas", "type": "Error",
        "title": "SettingWithCopyWarning when adding a Month column to a filtered table",
        "tags": "SettingWithCopyWarning, Period, date filter",
        "problem": "`led_bf_req['Month'] = pd.to_datetime(...).dt.to_period('M')` on a filtered table gave a "
                   "SettingWithCopyWarning, followed by `led_bf_req[led_bf_req['Month'] == '2026-10']`.",
        "cause": "The table was a slice of another table; pandas can't tell whether the new column should reach the "
                 "original. A Month column was only needed to filter, which a date range does directly.",
        "code": r'''month_bills = bills[(bills['CreatedAt'] >= m_start) & (bills['CreatedAt'] < m_end)]   # no new column

# when a filtered table really needs a new column, copy it first
part = bills[bills['ClientID'].isin(ids)].copy()
part['Month'] = part['CreatedAt'].dt.to_period('M')''',
        "why": [
            "A half-open date range filters without changing the table.",
            ".copy() makes the slice its own table, so assigning a column is unambiguous.",
        ],
        "lesson": "Filter with conditions; add columns only to tables you own (.copy()).",
    },
    {
        "id": "20261110-04", "tool": "pandas", "type": "How-to",
        "title": "Broker program report: yes/no flags per child, summed per broker",
        "tags": "flags, isin, groupby sum",
        "problem": "Per broker: Children, Demo Children, Added This Month, Active This Month, Active within 30 days, "
                   "6-child eligibility and Trade Value.",
        "cause": "Each measure is a question about one child (added? active?). Answer it per child as True/False, "
                 "then sum per broker.",
        "code": r'''kids['added_this_month'] = (kids['created_at'] >= m_start) & (kids['created_at'] < m_end)
kids['active_this_month'] = kids['zynixx_client_id'].isin(month_bills['ClientID'])
kids['active_30_days'] = kids['zynixx_client_id'].isin(recent_bills['ClientID'])
kids['trade_value'] = kids['zynixx_client_id'].map(month_bills.groupby('ClientID')['Debit'].sum()).fillna(0)

report = (kids.groupby('referrer_client_id')
              .agg(Children=('zynixx_client_id', 'size'),
                   **{'Demo Children': ('is_demo', 'sum'), 'Active This Month': ('active_this_month', 'sum'),
                      'Trade Value': ('trade_value', 'sum')}))''',
        "why": [
            "Summing a True/False column counts the Trues.",
            "isin() answers 'did this child appear in those BILL rows?' without a merge.",
            "Checks: real children found in the ledger, and report total = ledger total.",
        ],
        "lesson": "Turn each measure into a per-row yes/no first; the summary is then just sums.",
    },
    {
        "id": "20261110-05", "tool": "pandas", "type": "How-to",
        "title": "Program targets: required active, new clients still to add, minimum trade value",
        "tags": "clip, np.select, settings",
        "problem": "Required active = 2 x active this month; at least 6 new children (show how many are still "
                   "needed); minimum trade value = required active x 10,000; eligibility with a reason.",
        "cause": "Targets are formulas on the report's columns; 'still needed' must never go below zero.",
        "code": r'''ACTIVE_MULTIPLIER, NEW_CLIENTS_TARGET, TRADE_PER_ACTIVE = 2, 6, 10_000
prog['Required Active Clients'] = (prog['Active This Month'] * ACTIVE_MULTIPLIER).clip(lower=REQUIRED_ACTIVE_FLOOR)
prog['Add New Clients'] = (NEW_CLIENTS_TARGET - prog['Added This Month']).clip(lower=0)
prog['Minimum Trade Value'] = (prog['Required Active Clients'] * TRADE_PER_ACTIVE).clip(lower=MIN_TRADE_VALUE)
prog['Reason'] = np.select([new_ok & trade_ok, ~new_ok & ~trade_ok, ~new_ok],
                           ['', 'Needs new clients and trade value', 'Needs new clients'],
                           default='Needs trade value')''',
        "why": [
            ".clip(lower=0) stops 'still needed' going negative for brokers who added more than 6.",
            "Rules as named settings at the top: changing the program means changing one number.",
            "np.select gives each broker exactly one reason, checked in order.",
        ],
        "lesson": "Put program rules in named settings, not inside formulas.",
    },
    {
        "id": "20261110-06", "tool": "pandas", "type": "Wrong result",
        "title": "A broker with no active clients was eligible without trading",
        "tags": "edge case, floor",
        "problem": "A broker with 0 active clients, 0 trade value and 7 new clients came out ELIGIBLE.",
        "cause": "2 x 0 active = 0 required, so the minimum trade value was 0, and 0 >= 0 passes.",
        "code": r'''REQUIRED_ACTIVE_FLOOR = 6        # every broker needs at least 6 active clients
MIN_TRADE_VALUE = 60_000         # and at least 60,000 trade value
prog['Required Active Clients'] = (prog['Active This Month'] * 2).clip(lower=REQUIRED_ACTIVE_FLOOR)
prog['Minimum Trade Value'] = (prog['Required Active Clients'] * 10_000).clip(lower=MIN_TRADE_VALUE)''',
        "why": [
            "Any target built by multiplying is zero when the input is zero.",
            "A floor gives every broker a real minimum, whatever their history.",
            "Found by testing a made-up broker with zero activity, not by the real rows.",
        ],
        "lesson": "Test every business rule with a zero row and a just-below row.",
    },
    {
        "id": "20261110-07", "tool": "pandas", "type": "Wrong result",
        "title": "max() set the wrong target for a broker just below the minimum",
        "tags": "np.where, either/or rule",
        "problem": "Rule: below the minimum -> target is the minimum; minimum met -> target is trade value + 2%. "
                   "With max(minimum, trade x 1.02), a broker at 59,500 against 60,000 got 60,690.",
        "cause": "max() is 'whichever is higher', not 'if met then growth else minimum'. They differ just below the "
                 "minimum, where 2% growth already passes it.",
        "code": r'''trade_ok = prog['Trade Value'] >= prog['Minimum Trade Value']
prog['Target Trade Value'] = np.where(trade_ok,
                                      (prog['Trade Value'] * 1.02).round(2),   # already met: +2%
                                      prog['Minimum Trade Value'])              # not met: the minimum
prog['Target Basis'] = np.where(trade_ok, "+2% growth", "Minimum")''',
        "why": [
            "np.where(condition, if_true, if_false) is a literal if/else per row.",
            "trade_ok is used for both the target and eligibility, so they can't disagree.",
            "Target Basis shows which rule applied, so the table explains itself.",
        ],
        "lesson": "Write the rule exactly as stated (if/else) before reaching for a shortcut like max().",
    },
    {
        "id": "20261110-08", "tool": "pandas", "type": "How-to",
        "title": "Trade value as one column per month",
        "tags": "to_period, pivot_table, reindex",
        "problem": "Needed September and October trade value as separate columns, with Added and Active still "
                   "counting October only.",
        "cause": "Two windows: the report month and the trade months. One start/end can't serve both.",
        "code": r'''REPORT_MONTH = pd.Period('2026-10', freq='M')
TRADE_MONTHS = pd.period_range('2026-09', '2026-10', freq='M')

tv = (trade_bills.assign(Month=trade_bills['CreatedAt'].dt.to_period('M'))
                 .merge(kids[['zynixx_client_id', 'referrer_client_id']], left_on='ClientID',
                        right_on='zynixx_client_id')
                 .pivot_table(index='referrer_client_id', columns='Month', values='Debit',
                              aggfunc='sum', fill_value=0)
                 .reindex(columns=TRADE_MONTHS, fill_value=0))          # every month gets a column
tv.columns = [f"Trade Value {m.strftime('%b %Y')}" for m in tv.columns]''',
        "why": [
            "to_period('M') labels each row with its month; pivot_table turns months into columns.",
            "reindex keeps a column for a month with no trades, so the layout never changes.",
            "Period arithmetic: REPORT_MONTH + 1 and - 1 give the next and previous months.",
        ],
        "lesson": "Name each time window separately in the settings; never reuse one start/end for two meanings.",
    },
    {
        "id": "20261110-09", "tool": "pandas", "type": "Wrong result",
        "title": "Lookup merges could duplicate brokers; is_broker listed twice",
        "tags": "merge, validate, duplicate columns",
        "problem": "report_s merged report with bf_status and af by broker ID; the column list named is_broker "
                   "twice, and `report_s.columns` ran before report_s existed.",
        "cause": "A lookup file with an ID twice turns one broker into two rows; selecting a name twice creates two "
                 "columns with the same name.",
        "code": r'''status = (bf_status.assign(zynixx_client_id=bf_status['zynixx_client_id'].astype(str).str.strip())
                   .drop_duplicates('zynixx_client_id')[['zynixx_client_id', 'is_broker']])
report_s = report.merge(status, left_on='Broker', right_on='zynixx_client_id',
                        how='left', validate='many_to_one')
print("Brokers:", len(report), "->", len(report_s), "(must be equal)")''',
        "why": [
            "drop_duplicates on the lookup makes it one row per ID.",
            "validate='many_to_one' raises an error if that ever stops being true.",
            "Cells run out of order hide NameErrors: Restart and Run All before trusting a result.",
        ],
        "lesson": "Guard every lookup to one row per key, and compare row counts before and after.",
    },
    {
        "id": "20261110-10", "tool": "pandas", "type": "How-to",
        "title": "What 'Active within 30 days' measures",
        "tags": "rolling window, as_of",
        "problem": "Asked how the 30-day number was calculated, since it differs from Active This Month.",
        "cause": "It counts back 30 x 24 hours from the latest ledger entry (as_of), so it covers late October plus "
                 "early November, and moves every time the ledger is refreshed.",
        "code": r'''as_of = led['CreatedAt'].max()                                   # window end: latest ledger entry
recent_bills = bills[bills['CreatedAt'] > as_of - pd.Timedelta(days=30)]
print("30-day window:", as_of - pd.Timedelta(days=30), "to", as_of)

# alternatives:  as_of = m_end  (30 days up to the end of the report month, fixed once the month ends)
#                as_of = pd.Timestamp.now()  (30 days up to today)''',
        "why": [
            "A child active only on 1-10 Oct counts in October but not in this window, and vice versa for November.",
            "Printing the window makes the definition visible in every run.",
        ],
        "lesson": "A rolling window needs its end date printed, or the number can't be reproduced.",
    },
    {
        "id": "20261110-11", "tool": "pandas", "type": "How-to",
        "title": "Active previous month, and where each new line goes",
        "tags": "Period arithmetic, dependency order",
        "problem": "Added 'Active Previous Month' (September) beside 'Active This Month' (October), and needed to "
                   "know where to insert each line.",
        "cause": "Each line can only use what's defined above it: dates, then BILL slice, then per-child flag, then "
                 "the count, then anything that combines counts.",
        "code": r'''p_start, p_end = (REPORT_MONTH - 1).start_time, REPORT_MONTH.start_time     # next to m_start, m_end
prev_bills = bills[(bills['CreatedAt'] >= p_start) & (bills['CreatedAt'] < p_end)]
kids['active_prev_month'] = kids['zynixx_client_id'].isin(prev_bills['ClientID'])
# in .agg:  'Active Previous Month': ('active_prev_month', 'sum'),
report['Active Change'] = report['Active This Month'] - report['Active Previous Month']   # after report''',
        "why": [
            "REPORT_MONTH - 1 follows the setting: change the report month and 'previous' follows.",
            "p_end = the report month's start, so no trade is counted in both months.",
            "Out-of-order lines raise NameError or KeyError naming the missing piece.",
        ],
        "lesson": "Put each new line next to its sibling at the same stage of the pipeline.",
    },
]


# ---- Patterns: carried from 9 November, extended with today's cards ----------------------------
from entries_09 import PATTERNS as _PREVIOUS

_ADD = {
    "Check the inputs before the code": ["20261110-02"],
    "Repeated rows mean a one-to-many join or duplicate keys": ["20261110-09"],
    "Agree the output before building": ["20261110-10"],
    "Duplicate or double-used names break things": ["20261110-09"],
    "Verify against raw rows or an old version": ["20261110-04"],
    "Trust only output from a fresh run": ["20261110-09", "20261110-11"],
    "Same type, same clock before date maths": ["20261110-10"],
    "Prefer whole-column code to row loops": ["20261110-04"],
}
PATTERNS = []
for name, seen, what in _PREVIOUS:
    extra = _ADD.get(name, [])
    PATTERNS.append((name, seen + "".join(", " + i for i in extra), what))

PATTERNS[5:5] = [
    ("One label per row when groups must add up",
     "20261110-01, 20261110-05",
     "np.select([...], [...], default=...) gives each row exactly one label, decided in a stated order; "
     "the groups then always sum to the total."),
    ("Try the edge cases of every business rule",
     "20261110-06, 20261110-07",
     "Before trusting a rule, run a zero row (no activity), a just-below row and a just-above row through it."),
    ("Name each setting and window once",
     "20261110-05, 20261110-08",
     "Program numbers and date windows as named settings at the top (REPORT_MONTH, TRADE_MONTHS, MIN_TRADE_VALUE); "
     "never reuse one start/end for two meanings."),
]
