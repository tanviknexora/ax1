DAY5 = {
    "date": "Wednesday, 4 November 2026 (covers 3 to 4 Nov)",
    "focus": "Client reports from the ledger (net withdrawals, campaign flag, trading days), a two-sheet broker "
             "commission workbook in the MIS design, importing your own modules, and writing functions.",
    "outcome": "11 entries: 2 errors, 3 wrong results and 6 how-tos. The P&L chain became a function at three "
               "levels, each checked against the original result.",
    "review": "Repeated: sorting by the key instead of the date before keep='first' (third time). Focus tomorrow: "
              "write trading_days(led, start, end) at Level 2 and check it with assert_frame_equal.",
}

ENTRIES5 = [
    {
        "id": "20261104-01", "tool": "pandas", "type": "How-to",
        "title": "When a lambda is fine, and when it's 900x slower",
        "tags": "apply, vectorise, benchmark",
        "problem": "Needed a rule for when to use lambdas in pandas.",
        "cause": "A lambda inside `.apply` runs once per row in plain Python; one given a whole column or table doesn't.",
        "code_lang": "python",
        "code": r'''df.apply(lambda r: r.a + r.b, axis=1)     # 4,718 ms on 500,000 rows
df.a + df.b                               #     5 ms

calls.assign(talk_s=lambda d: d['Talk Time'].dt.total_seconds())   # fine: d is the whole table
max(files, key=lambda f: f.stat().st_mtime)                        # fine: key= function''',
        "why": [
            "Order to try: column operators, np.where/np.select/pd.cut, groupby built-ins, map/str, then apply.",
            "Surprise on pandas 3: .str.split('|').str[1] was the slowest text method; .str.replace(regex) the fastest.",
            "Joining text per group (', '.join) has no built-in, so a lambda is right there.",
        ],
        "lesson": "Give a lambda whole columns, never one row at a time.",
    },
    {
        "id": "20261104-02", "tool": "pandas", "type": "How-to",
        "title": "Deposits and withdrawals net of cancellations",
        "tags": "where, groupby, ledger types",
        "problem": "Needed Deposit and Withdraw per client, with WITHDRAW CANCELLED credits subtracted.",
        "cause": "The pivot_table used two lambdas that looked rows up again with .loc[x.index].",
        "code_lang": "python",
        "code": r'''lt = req_led['LedgerType'].str.strip().str.upper()
cr, dr = req_led['Credit'].fillna(0), req_led['Debit'].fillna(0)
one_pivot = (req_led
    .assign(Deposit=cr.where(lt.eq('DEPOSIT'), 0),
            Withdraw=dr.where(lt.eq('WITHDRAW'), 0) - cr.where(lt.eq('WITHDRAW CANCELLED'), 0))
    .groupby('ClientID', as_index=False)[['Deposit', 'Withdraw']].sum())''',
        "why": [
            "Each row contributes +debit, -credit or 0, so the sum is withdrawals minus cancellations.",
            "fillna(0) first: one blank Credit would make the row blank and sum would skip it.",
        ],
        "lesson": "Build the amount columns, then one plain sum.",
    },
    {
        "id": "20261104-03", "tool": "pandas", "type": "Error",
        "title": "np.where got one argument: a bracket closed too late",
        "tags": "np.where, &, brackets",
        "problem": "`np.where((df['Balance'] == 0) & (df['Last Trade'] != 'No Trade', 'Yes', 'No'))` failed.",
        "cause": "The second condition's `)` closed after 'No', so Python built a tuple and np.where got one argument.",
        "code_lang": "python",
        "code": r'''df['Traded Zero'] = np.where(
    (df['Balance'] == 0) & (df['Last Trade'] != 'No Trade'),
    'Yes', 'No')''',
        "why": [
            "Each condition in its own brackets; & | ~ between them; then the true and false values.",
            "`and` / `or` raise 'truth value of a Series is ambiguous'.",
            "0.004 isn't == 0: use .round(2).eq(0) when tiny balances should count.",
        ],
        "lesson": "Close every condition's bracket before the first comma.",
    },
    {
        "id": "20261104-04", "tool": "pandas", "type": "Wrong result",
        "title": "Latest balance taken from a random row (again)",
        "tags": "sort_values, drop_duplicates, repeated",
        "problem": "`balance = req_led.sort_values('ClientID').drop_duplicates('ClientID', keep='first')`.",
        "cause": "Sorting by the key leaves rows within each client in an undefined order, so 'first' isn't the latest.",
        "code_lang": "python",
        "code": r'''balance = (req_led.sort_values('CreatedAt', ascending=False)
                  .drop_duplicates(subset='ClientID', keep='first')
                  [['ClientID', 'CreatedAt', 'Balance']])''',
        "why": [
            "Third time in the journal (29 Oct, 30 Oct, 3 Nov).",
            "Balance feeds Traded Zero, so one wrong sort spreads into two columns.",
        ],
        "lesson": "Before keep='first', the line above must sort by a date.",
    },
    {
        "id": "20261104-05", "tool": "pandas", "type": "Wrong result",
        "title": "Campaign flag: 'deposited on' vs 'first deposit was'",
        "tags": "first row per group, requirements",
        "problem": "The flag was built for any 1,000 deposit on 25 Aug; the rule was the client's FIRST deposit.",
        "cause": "Every deposit was tested instead of only each client's earliest one.",
        "code_lang": "python",
        "code": r'''first_dep = dep.sort_values('CreatedAt').drop_duplicates('ClientID', keep='first')
camp_ids = set(first_dep.loc[(first_dep['CreatedAt'].dt.normalize() == pd.Timestamp('2026-08-25'))
                             & (first_dep['Credit'] == 1000), 'ClientID'])
df['Campaign'] = np.where(df['ClientID'].isin(camp_ids), 'Campaign', 'Not Campaign')''',
        "why": [
            "'First X': sort oldest first, keep the first row per client, then test it.",
            "'Only X': also require one deposit in total.",
            "First within the loaded ledger: check led['CreatedAt'].min().",
        ],
        "lesson": "Pin down first / any / only before writing the filter.",
    },
    {
        "id": "20261104-06", "tool": "pandas", "type": "How-to",
        "title": "Trading days and their spread per client",
        "tags": "nunique, join per group, to_period",
        "problem": "Needed trading days per client, plus the dates and a per-month count as text.",
        "cause": "Several bills per day must count once; month labels must stay in calendar order.",
        "code_lang": "python",
        "code": r'''bills = (req_led[lt.eq('BILL')].assign(Trade_Date=lambda d: d['CreatedAt'].dt.normalize())
           .drop_duplicates(['ClientID', 'Trade_Date']).sort_values(['ClientID', 'Trade_Date']))
dates = bills.groupby('ClientID')['Trade_Date'].agg(lambda s: ', '.join(s.dt.strftime('%d %b')))
per_month = (bills.assign(M=lambda d: d['Trade_Date'].dt.to_period('M'))
                  .groupby(['ClientID', 'M']).size().reset_index(name='n')
                  .assign(t=lambda d: d['M'].dt.strftime('%b %Y') + ': ' + d['n'].astype(str))
                  .groupby('ClientID')['t'].agg(', '.join))''',
        "why": [
            "drop_duplicates on client + date keeps one row per trading day.",
            "Sorting by the Period, not the text, keeps months in calendar order.",
            "Check: days per month add up to Trading Days; 0 days where Last Trade is 'No Trade'.",
        ],
        "lesson": "Join text per group with ', '.join after sorting.",
    },
    {
        "id": "20261104-07", "tool": "pandas", "type": "How-to",
        "title": "Excel export in the MIS design",
        "tags": "openpyxl, ExcelWriter, number_format",
        "problem": "The commission table had to look like the MIS file: coloured bands, gold headers, formats.",
        "cause": "pandas writes plain cells; styling needs openpyxl on the sheet pandas just wrote.",
        "code_lang": "python",
        "code": r'''with pd.ExcelWriter(path, engine='openpyxl') as writer:
    df.to_excel(writer, sheet_name='Brokers', index=False, startrow=1)   # row 1 left for bands
    ws = writer.sheets['Brokers']
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=4)
    ws.cell(1, 1).value = 'Admin Panel Broker File'
    for row in ws.iter_rows(min_row=3):
        for cell in row[4:]:
            cell.number_format = '#,##0.00;[Red]-#,##0.00;"-"'
    ws.freeze_panes, ws.auto_filter.ref = 'B3', f"A2:K{ws.max_row}"''',
        "why": [
            "startrow=1 leaves Excel row 1 free; writer.sheets[name] is the openpyxl sheet.",
            "Number format parts: positive; negative (red); zero (dash).",
            "One style_sheet() function styles both the Brokers and the Clients sheets.",
        ],
        "lesson": "Write with pandas, style with openpyxl, in the same with-block.",
    },
    {
        "id": "20261104-08", "tool": "pandas", "type": "Wrong result",
        "title": "NBP always 0: rows filtered away one step early",
        "tags": "filter order, isin",
        "problem": "The broker sheet showed 0 NBP for every client.",
        "cause": "led_oct_bill kept only BILL rows, so the later filter for BILL + NBP had no NBP rows left.",
        "code_lang": "python",
        "code": r'''lt = ['BILL', 'NEGATIVE BALANCE PROTECTION']
led_child = led_oct[led_oct['ClientID'].isin(child)]          # not led_oct_bill
led_child_fil = led_child[led_child['LedgerType'].isin(lt)]''',
        "why": [
            "Check after each filter: df['LedgerType'].value_counts() shows which types survived.",
            "Same broker rule: .where(is_loss, 'TEXT') keeps numbers numeric; np.where would turn them into text.",
        ],
        "lesson": "A filter can't keep rows an earlier filter already removed.",
    },
    {
        "id": "20261104-09", "tool": "Python", "type": "Error",
        "title": "TypeError: insert expected 2 arguments, got 1",
        "tags": "sys.path, imports, PYTHONPATH",
        "problem": "`sys.path.insert(r'C:\\...\\migration')` failed while importing ledger_loader from another folder.",
        "cause": "list.insert needs a position and an item; there's no default position.",
        "code_lang": "python",
        "code": r'''import sys
sys.path.insert(0, r"C:\Users\Administrator\Videos\Office\migration")   # 0 = searched first
from ledger_loader import get_final_ledger
# permanent: setx PYTHONPATH "C:\Users\Administrator\Videos\Office\migration", then restart VS Code''',
        "why": [
            "Import checks sys.modules first, then searches sys.path from position 0; the first match wins.",
            "append(folder) takes one argument but searches the folder last.",
            "module.__file__ shows which file was imported; %autoreload 2 picks up edits.",
        ],
        "lesson": "insert(0, folder) puts your folder first in the search.",
    },
    {
        "id": "20261104-10", "tool": "Python", "type": "How-to",
        "title": "Writing functions in three levels",
        "tags": "def, parameters, defaults, None, raise",
        "problem": "Needed to turn the P&L chain into a reusable function, starting as a beginner.",
        "cause": "Copying cells between notebooks repeats work and spreads mistakes.",
        "code_lang": "python",
        "code": r'''def client_pnl_v1(led):                                         # level 1: wrap working code
    return led.assign(...).groupby(...).sum().assign(...)

def client_pnl_v2(led, start, end, commission_rate=0.05):          # level 2: parameters + default
    rows = led[(led['CreatedAt'] >= start) & (led['CreatedAt'] < end)]
    ...

def client_pnl_v3(led, start=None, end=None, clients=None, commission_rate=0.05):   # level 3
    if missing: raise ValueError(...)
    if clients is not None: rows = rows[rows['ClientID'].isin(clients)]''',
        "why": [
            "def runs nothing; calling the function does. return sends one result out.",
            "Names inside a function stay inside; only `x = f(...)` outside creates a notebook variable.",
            "None as a default means 'not given'; raise ValueError stops early with a clear message.",
        ],
        "lesson": "Wrap working code first, then turn fixed values into parameters one at a time.",
    },
    {
        "id": "20261104-11", "tool": "pandas", "type": "How-to",
        "title": "Prove a rewrite didn't change the numbers",
        "tags": "assert_frame_equal, testing",
        "problem": "Needed to confirm each function version matches the existing pnl table.",
        "cause": "Looking at a few rows can't prove two tables are identical.",
        "code_lang": "python",
        "code": r'''pd.testing.assert_frame_equal(pnl.reset_index(drop=True),
                              client_pnl_v1(led_child_fil).reset_index(drop=True),
                              check_dtype=False)''',
        "why": [
            "Silent when equal; raises an error showing the first difference when not.",
            "Level 3 is expected to differ: it reads the full ledger, so NBP rows come back in.",
        ],
        "lesson": "Every rewrite gets an equality check against the version you trust.",
    },
]

PATTERNS = [
    ("Sort by the date before keep='first'",
     "20261030-01, 20261030-09, 20261104-04",
     "'Latest row per key' needs sort_values(date, ascending=False) right before drop_duplicates(keep='first')."),
    ("Check the inputs before the code",
     "20261030-02, 20261031-08, 20261104-08",
     "Print which files and rows are used (value_counts after each filter) before changing any logic."),
    ("Repeated rows mean a one-to-many join or duplicate keys",
     "20261029-11, 20261029-12, 20261030-21, 20261102-01, 20261102-04, 20261102-06",
     "Collapse the many side to one row per key first. Check COUNT(*) = COUNT(DISTINCT key), "
     "validate='many_to_one', or duplicated(subset=key)."),
    ("Agree the output before building",
     "20261102-09, 20261104-05",
     "Name the columns to add, what to keep, and the exact rule (first / any / only)."),
    ("Check what is really stored before filtering",
     "20261029-05, 20261029-08, 20261029-09, 20261030-03, 20261030-07, 20261102-07",
     "Look at real values and column names: df.columns, SELECT DISTINCT, value_counts, COUNTIF with wildcards."),
    ("Start from the thing every row must represent",
     "20261102-05",
     "Every ID must appear? Start from the IDs and LEFT JOIN the rest; label why a value is zero."),
    ("Duplicate or double-used names break things",
     "20261029-02, 20261030-19, 20261031-06",
     "Two columns with one name, or one column as both pivot key and value. Check names after every rename."),
    ("Names, brackets and arguments",
     "20261029-01, 20261030-12, 20261031-11, 20261104-03, 20261104-09",
     "Built-in names, a token's value used as its name, a bracket closing late, a missing argument."),
    ("Verify against raw rows or an old version",
     "20261029-06, 20261029-07, 20261029-13, 20261030-02, 20261031-04, 20261104-11",
     "Compare counts with raw data; run old and new code on the same input; assert_frame_equal."),
    ("Build checks that fail loudly",
     "20261031-07, 20261031-09, 20261031-12, 20261102-05, 20261102-08",
     "assert impossible values, raise on unreadable dates, cross-check two outputs, label every zero."),
    ("Prefer whole-column code to row loops",
     "20261031-05, 20261104-01, 20261104-02",
     "Column operators, np.where/select, groupby built-ins first; apply(lambda) only when nothing else fits."),
    ("Load only what you need",
     "20261030-14, 20261030-15, 20261030-16, 20261030-18",
     "Estimate rows x columns x 8 bytes. Select columns and filter rows before collecting; sink big outputs to disk."),
    ("Text that looks like a date or number isn't one",
     "20261029-04, 20261029-12, 20261030-13, 20261030-20, 20261031-03, 20261031-09",
     "Read IDs as text; give date formats explicitly; convert with to_datetime / to_timedelta / Int64."),
    ("Excel changes data when it saves",
     "20261030-02, 20261030-05, 20261030-21",
     "Never save a CSV from Excel. Long IDs become 2.61029E+17 and times become 59:48.4 for good."),
    ("Trust only output from a fresh run",
     "20261030-07, 20261030-16, 20261031-12",
     "Restart and Run All before trusting a number; close output files in Excel before writing them."),
]
