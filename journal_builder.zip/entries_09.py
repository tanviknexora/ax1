DAY6 = {
    "date": "Monday, 9 November 2026",
    "focus": "Metabase call lists for Pull Back and P1: day gaps in Indian time, the latest status per customer, "
             "team alignment by the lead's current owner, Metabase variables, and totals with ROLLUP.",
    "outcome": "15 entries: 4 errors, 3 wrong results and 8 how-tos. Both call-list queries run; the rule for picking "
               "the current status when two rows tie is still open (20261109-05). Evening: a sign-up page with admin "
               "approval and the Ledger explorer page (cards 12 to 15).",
    "review": "Repeated: NULL handling (blank last call; NULLs first in DESC) and a one-to-many join (status "
              "history without rn = 1). Focus tomorrow: run the Y19823 diagnostic, agree the tie rule for "
              "Lost Lead vs Dormant, then finalise the Pull Back query.",
}

ENTRIES6 = [
    {
        "id": "20261109-01", "tool": "SQL", "type": "How-to",
        "title": "Call list: traded in the last 3 days, not called for 2",
        "tags": "INTERVAL, NULL, OR brackets",
        "problem": "Needed the P1 list: last transaction within 3 days and last call more than 2 days ago.",
        "cause": "Two traps: a blank `last_call_at` fails every comparison, so never-called clients vanish; "
                 "and an OR without brackets escapes the portal and project filters.",
        "code": r'''WHERE ctp.last_txn_date >= CURRENT_TIMESTAMP - INTERVAL '3 days'
  AND (c.last_call_at < CURRENT_TIMESTAMP - INTERVAL '2 days'
       OR c.last_call_at IS NULL)                         -- never called counts too
  AND c.portal_id = {{snippet: portal_id}}
  AND c.project_id = {{snippet: project_id}}
ORDER BY c.last_call_at ASC NULLS FIRST                   -- longest without a call first''',
        "why": [
            "NULL compared with anything is unknown, and WHERE keeps only true rows.",
            "AND is evaluated before OR: without the brackets, never-called clients from every portal get in.",
            "WHERE compares instants, so no AT TIME ZONE is needed; INTERVAL '2 days' means 48 hours back.",
        ],
        "lesson": "Every filter on a column that can be blank needs a decision about blanks.",
    },
    {
        "id": "20261109-02", "tool": "SQL", "type": "Error",
        "title": "interval 3 days fails; CURRENT_DATE AT TIME ZONE skews the gaps",
        "tags": "INTERVAL, AT TIME ZONE, ::date, CTE",
        "problem": "`... > interval 3 days` gave a syntax error. The day gaps used "
                   "`CURRENT_DATE at time zone 'asia/kolkata' - ctp.last_txn_date at time zone 'asia/kolkata'`, "
                   "and the call column reused the alias Last_Transaction_From_Today.",
        "cause": "An interval literal needs quotes. CURRENT_DATE is midnight of the server's date, and AT TIME ZONE "
                 "returns different types for a date and a timestamp, so the subtraction converts one with the "
                 "server's zone and is off by hours.",
        "code": r'''WITH base AS (
    SELECT ...,
           (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata')::date
             - (ctp.last_txn_date AT TIME ZONE 'Asia/Kolkata')::date AS days_since_last_transaction,
           (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata')::date
             - (c.last_call_at AT TIME ZONE 'Asia/Kolkata')::date    AS days_since_last_call
    FROM ...
)
SELECT * FROM base
WHERE days_since_last_transaction > 3
  AND (days_since_last_call > 4 OR days_since_last_call IS NULL)''',
        "why": [
            "Correct literal: `INTERVAL '3 days'`.",
            "`(ts AT TIME ZONE 'Asia/Kolkata')::date` is the calendar date in India; date minus date is whole days.",
            "A column alias can't be used in the same SELECT's WHERE, so compute in a CTE and filter outside it.",
            "The shown day counts and the filter now use the same numbers.",
        ],
        "lesson": "Make both sides the same type, on the same clock, before subtracting dates.",
    },
    {
        "id": "20261109-03", "tool": "SQL", "type": "Error",
        "title": "ROW_NUMBER written wrong, and every status row joined",
        "tags": "ROW_NUMBER, OVER, one-to-many",
        "problem": "`row_number() over partition by(customer_id order by new_last_txn_date desc)` in a joined "
                   "subquery failed, joined on `cu.id`, and a `select * from customer_status_history` followed "
                   "the query.",
        "cause": "The brackets belong after OVER. Even with that fixed, nothing kept only row 1, so each client "
                 "would repeat once per history row; and `cu.id` is the current-user model's own ID, not the customer.",
        "code": r'''WITH ranked_status AS (
    SELECT customer_id, new_status, occurred_at,
           ROW_NUMBER() OVER (PARTITION BY customer_id
                              ORDER BY occurred_at DESC NULLS LAST, id DESC) AS rn
    FROM customer_status_history
),
latest_status AS (
    SELECT customer_id, new_status FROM ranked_status WHERE rn = 1
)
...
LEFT JOIN latest_status ls ON ls.customer_id = c.id''',
        "why": [
            "Shape: `ROW_NUMBER() OVER (PARTITION BY ... ORDER BY ...) AS rn`.",
            "A window function can't be filtered in the SELECT that computes it: number first, filter rn = 1 outside.",
            "Join on the same customer key the other joins use (c.id).",
            "A second statement in a Metabase question is an error: test queries go in their own question.",
        ],
        "lesson": "A 'latest row' join without rn = 1 is a one-to-many join.",
    },
    {
        "id": "20261109-04", "tool": "SQL", "type": "Wrong result",
        "title": "Latest status picked a row with no date: DESC puts NULLs first",
        "tags": "ORDER BY, NULLS LAST, tie-breaker",
        "problem": "The current status didn't match the CRM for some clients when sorting the history by date DESC.",
        "cause": "In PostgreSQL, DESC puts NULL values first. History rows with no date ranked as the newest.",
        "code": r'''ORDER BY customer_id,
         occurred_at DESC NULLS LAST,     -- blank dates go to the bottom
         id DESC                          -- tie-breaker: the last row inserted

-- show which row was picked, so the result can be checked by eye
ls.status_changed_at AT TIME ZONE 'Asia/Kolkata' AS status_changed_at''',
        "why": [
            "Defaults: ASC puts NULLs last, DESC puts NULLs first. NULLS LAST / NULLS FIRST overrides.",
            "A tie-breaker makes the pick repeatable; without one, ties are returned in any order.",
            "Showing the sort column next to the result turns 'looks wrong' into something you can check.",
        ],
        "lesson": "Every DESC on a column that can be blank needs NULLS LAST, or a deliberate NULLS FIRST.",
    },
    {
        "id": "20261109-05", "tool": "SQL", "type": "Wrong result",
        "title": "Lost Lead shown as Dormant: several rows tie on the sort column (open)",
        "tags": "ties, LIMIT 1, business rule",
        "problem": "Y19823 shows Dormant. `ORDER BY new_last_txn_date DESC LIMIT 1` on its history shows Lost Lead "
                   "(previous Dormant, both txn dates 23 Sep 2025 4:12 PM).",
        "cause": "The status changed without a new transaction, so several rows share the same new_last_txn_date. "
                 "LIMIT 1 returns whichever tied row it reads first; the query broke the tie by occurred_at and "
                 "picked Dormant. Status: open until the diagnostic is run.",
        "code": r'''-- 1. See every tied row and the rank the query gives it
SELECT h.customer_id, h.id, h.previous_status, h.new_status, h.new_last_txn_date, h.occurred_at,
       ROW_NUMBER() OVER (PARTITION BY h.customer_id
                          ORDER BY h.new_last_txn_date DESC, h.occurred_at DESC NULLS LAST, h.id DESC) AS rn
FROM customer_trading_profiles ctp
JOIN customer_status_history h ON h.customer_id = ctp.customer_id
WHERE ctp.zynixx_client_id = 'Y19823'
ORDER BY rn

-- 2. If the rule is "Lost Lead stays until the client trades again":
ORDER BY new_last_txn_date DESC, (new_status = 'Lost Lead') DESC, occurred_at DESC NULLS LAST, id DESC''',
        "why": [
            "previous_last_txn_date = new_last_txn_date means no new transaction: a tie is guaranteed.",
            "A check that agrees by luck (LIMIT 1 on a tied column) proves nothing.",
            "Which status wins a tie is a business rule, not a SQL question: agree it, then encode it.",
        ],
        "lesson": "Before trusting ORDER BY x LIMIT 1, check that x is unique within the group.",
    },
    {
        "id": "20261109-06", "tool": "SQL", "type": "How-to",
        "title": "Team alignment from the lead's current owner, not the last caller",
        "tags": "LEFT JOIN, models, name join",
        "problem": "P1 took TL, manager and team from `c.last_call_agent_id`; they should follow the lead's owner.",
        "cause": "Two different people: the last caller and the current owner. The owner comes from the "
                 "current-user model, then the team list by name.",
        "code": r'''LEFT JOIN {{#3367-current-user}} cu ON c.id = cu.customer_id          -- who owns the lead now
LEFT JOIN {{#3268-team-main}} tm    ON cu.current_owner = tm.agents   -- that owner's TL, manager, team

-- owners that don't match the team list (spelling, extra spaces)
SELECT DISTINCT cu.current_owner
FROM {{#3367-current-user}} cu
LEFT JOIN {{#3268-team-main}} tm ON cu.current_owner = tm.agents
WHERE tm.agents IS NULL''',
        "why": [
            "LEFT JOINs keep clients whose owner isn't in the team list (blank TL) instead of dropping them.",
            "A WHERE on tm.team (e.g. 'Pull Back') turns the join into an inner join on purpose.",
            "Name joins are fragile: LOWER(TRIM(a)) = LOWER(TRIM(b)) if the check finds near-matches.",
        ],
        "lesson": "Decide which person a row belongs to before joining the team list.",
    },
    {
        "id": "20261109-07", "tool": "SQL", "type": "How-to",
        "title": "Remove clients who transacted today (Indian time)",
        "tags": "::date, AT TIME ZONE, calendar day",
        "problem": "The P1 list had to drop clients whose last transaction is today.",
        "cause": "`last_txn_date` is the latest transaction, so 'before today' means no transaction today. "
                 "'Today' must be the Indian calendar day, not the server's day or the last 24 hours.",
        "code": r'''AND (ctp.last_txn_date AT TIME ZONE 'Asia/Kolkata')::date
      < (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata')::date        -- not today (IST)

-- fully calendar-based alternative: 1 to 3 days ago, never today
AND (ctp.last_txn_date AT TIME ZONE 'Asia/Kolkata')::date
      BETWEEN (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata')::date - 3
          AND (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata')::date - 1''',
        "why": [
            "A transaction at 00:30 IST today is excluded; one at 23:50 IST yesterday stays.",
            "last_txn_type includes deposits, so this removes anyone who transacted, not only traded.",
            "Mixing a rolling 72-hour window with a calendar 'today' is easy to misread: pick one.",
        ],
        "lesson": "Say whether a window is rolling hours or calendar days, and in which time zone.",
    },
    {
        "id": "20261109-08", "tool": "Metabase", "type": "Error",
        "title": 'syntax error at or near "$1": IN without brackets',
        "tags": "variables, IN, [[ ]]",
        "problem": 'ERROR: syntax error at or near "$1" Position: 2824, after adding '
                   "`and tm.tl in {{tl}}` and `and cu.current_owner in {{current_owner}}`.",
        "cause": "Metabase replaces each variable with a placeholder ($1, $2...), so the SQL became `IN $1`. "
                 "IN needs its list in brackets.",
        "code": r'''  [[AND tm.tl IN ({{tl}})]]
  [[AND cu.current_owner IN ({{current_owner}})]]
-- variable type: Text, "Allow multiple values" on, "Always require a value" off''',
        "why": [
            "Write the variable exactly where a literal value would go, brackets included.",
            "[[ ... ]] drops the whole line when the box is empty; keep the AND inside the brackets.",
            "Field Filter variables need real table columns; with model joins, use Text variables.",
        ],
        "lesson": "When Metabase reports $1, look at the line where the first variable sits.",
    },
    {
        "id": "20261109-09", "tool": "Metabase", "type": "Error",
        "title": "Multiple ResultSets were returned by the query",
        "tags": "semicolon, statements",
        "problem": "Multiple ResultSets were returned by the query.",
        "cause": "The query ended with `;` followed by a comment. The driver splits at the semicolon, so the "
                 "comment became a second, empty statement. A leftover test SELECT below the query does the same.",
        "code": r'''ORDER BY c.last_call_at ASC NULLS FIRST          -- longest without a call first
-- no semicolon, nothing after the query''',
        "why": [
            "A Metabase question runs exactly one statement.",
            "Ctrl+End in the editor shows anything hiding below the query.",
        ],
        "lesson": "One statement per Metabase question, and no trailing semicolon.",
    },
    {
        "id": "20261109-10", "tool": "SQL", "type": "How-to",
        "title": "A Total row with ROLLUP, at the bottom or the top",
        "tags": "ROLLUP, GROUPING, totals",
        "problem": "Needed counts per TL and per owner from the P1 model, with a Total row.",
        "cause": "ROLLUP adds the total row; GROUPING() tells it apart from a group whose TL is blank.",
        "code": r'''SELECT CASE WHEN GROUPING(tl) = 1 THEN 'Total'
            ELSE COALESCE(tl, 'No TL') END AS tl,
       COUNT(*) AS clients
FROM {{#6437-p1}}
GROUP BY ROLLUP (tl)
ORDER BY GROUPING(tl), clients DESC          -- Total last;  GROUPING(tl) DESC puts it first

-- per TL and owner, with a subtotal per TL
GROUP BY ROLLUP (tl, current_owner)
ORDER BY GROUPING(tl) DESC, tl, GROUPING(current_owner) DESC, clients DESC''',
        "why": [
            "GROUPING(col) is 1 on the rolled-up row and 0 on normal rows.",
            "COALESCE(tl, 'Total') would also label real clients with no TL as Total.",
            "COUNT(DISTINCT zynixx_client_id) if the model can repeat a client.",
        ],
        "lesson": "Label totals with GROUPING(), never by testing for NULL.",
    },
    {
        "id": "20261109-11", "tool": "SQL", "type": "How-to",
        "title": "DISTINCT ON and ROW_NUMBER give the same latest row",
        "tags": "DISTINCT ON, ROW_NUMBER, IS DISTINCT FROM",
        "problem": "Wanted to know whether to use DISTINCT ON or ROW_NUMBER for the latest status.",
        "cause": "With the same ORDER BY they pick the same row. ROW_NUMBER also does top-N (rn <= 3) and works in "
                 "other databases.",
        "code": r'''WITH a AS (SELECT DISTINCT ON (customer_id) customer_id, new_status
           FROM customer_status_history
           ORDER BY customer_id, occurred_at DESC NULLS LAST, id DESC),
b AS (SELECT customer_id, new_status
      FROM (SELECT customer_id, new_status,
                   ROW_NUMBER() OVER (PARTITION BY customer_id
                                      ORDER BY occurred_at DESC NULLS LAST, id DESC) AS rn
            FROM customer_status_history) h
      WHERE rn = 1)
SELECT COUNT(*) AS customers_that_differ          -- should be 0
FROM a FULL JOIN b USING (customer_id)
WHERE a.new_status IS DISTINCT FROM b.new_status''',
        "why": [
            "Changing the method doesn't change the answer; only the ORDER BY decides which row wins.",
            "IS DISTINCT FROM treats two blanks as equal; <> would miss differences involving NULL.",
            "FULL JOIN also catches a customer present in only one version.",
        ],
        "lesson": "When two ways of writing a rule should agree, prove it with a query that counts differences.",
    },
]

ENTRIES6 += [
    {
        "id": "20261109-12", "tool": "Django", "type": "How-to",
        "title": "A sign-up page: built-in form, extra fields, admin approval",
        "tags": "UserCreationForm, clean_email, is_active",
        "problem": "The reports site had login but no way to create an account.",
        "cause": "Django ships login and logout (django.contrib.auth.urls) but no sign-up view. It does ship the form: "
                 "UserCreationForm (username, password, password again).",
        "code": r'''class SignUpForm(UserCreationForm):
    first_name = forms.CharField(max_length=150)
    last_name = forms.CharField(max_length=150)
    email = forms.EmailField()

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ("username", "first_name", "last_name", "email")

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("An account with this email already exists.")
        return email

# view: user = form.save(commit=False); user.is_active = False; user.save()   (when SIGNUP_NEEDS_APPROVAL)''',
        "why": [
            "Extending UserCreationForm keeps Django's password checks and hashing for free.",
            "clean_<field> runs after the basic checks; email__iexact catches the same email in different case.",
            "is_active = False is Django's own on/off switch: an admin ticks Active in /admin/ to approve.",
        ],
        "lesson": "On an internal-data site, open sign-up means anyone on the network sees the data: add approval.",
    },
    {
        "id": "20261109-13", "tool": "Django", "type": "Wrong result",
        "title": "Every form error showed twice",
        "tags": "templates, non_field_errors, as_p",
        "problem": "A wrong login showed 'Please enter a correct username and password' twice; the report forms did "
                   "the same for their top-of-form errors. All tests passed.",
        "cause": "The templates printed {{ form.non_field_errors }} and then {{ form.as_p }}, and as_p already prints "
                 "the non-field errors at the top.",
        "code": r'''<form method="post">
  {% csrf_token %}
  {{ form.as_p }}          {# already includes the non-field errors: no separate line #}
  <button class="btn" type="submit">Log in</button>
</form>''',
        "why": [
            "as_p, as_div and as_table all render non-field errors first.",
            "Tests that use assertContains pass whether a message appears once or twice.",
            "Found by clicking through in a browser, not by the tests.",
        ],
        "lesson": "After the tests pass, click through the page once: some bugs are only visible.",
    },
    {
        "id": "20261109-14", "tool": "Django", "type": "How-to",
        "title": "An unapproved user only sees 'incorrect username or password'",
        "tags": "is_active, AuthenticationForm",
        "problem": "A new user waiting for approval got the normal 'correct username and password' error at login.",
        "cause": "Django's login backend treats inactive users as unknown on purpose, so the page never reveals "
                 "whether an account exists.",
        "code": r'''<!-- registration/login.html, under the form -->
<p class="muted">No account yet? <a href="{% url 'core:signup' %}">Sign up</a></p>
<p class="muted" style="font-size:12px">New accounts can log in once an admin approves them.</p>

<!-- and the sign-up view says it at the moment of signing up -->
messages.success(request, "Account created. An admin needs to approve it before you can log in.")''',
        "why": [
            "Saying 'this account is inactive' would let anyone test which usernames exist.",
            "So the explanation goes where the user already is: the sign-up message and a note on the login page.",
        ],
        "lesson": "When the system can't say why, tell the user beforehand.",
    },
    {
        "id": "20261109-15", "tool": "Django", "type": "How-to",
        "title": "A DataFrame as a sortable, paged HTML table (Ledger explorer)",
        "tags": "to_dict('records'), Paginator, request.GET",
        "problem": "Needed ledger rows on a page: filter by month, client, type; sort by clicking a heading; 50 rows a "
                   "page; CSV download.",
        "cause": "Templates read dict keys with dots, so column names with spaces or capitals don't work; and every "
                 "link must keep the current filters.",
        "code": r'''table = led.rename(columns={v: k for k, v in COLUMNS.items()})[list(COLUMNS)]   # short names
key = sort.lstrip("-") if sort.lstrip("-") in COLUMNS else "created"               # whitelist
table = table.sort_values(key, ascending=not sort.startswith("-"), kind="stable")
page_obj = Paginator(table.to_dict("records"), 50).get_page(request.GET.get("page"))

def url_with(request, **changes):          # current address with some values changed
    params = request.GET.copy()
    for k, v in changes.items():
        params.pop(k, None) if v is None else params.__setitem__(k, v)
    return "?" + params.urlencode()''',
        "why": [
            "to_dict('records') gives one dict per row: exactly what {% for row in page_obj %} needs.",
            "Filters use method='get', so a filtered page can be bookmarked and shared.",
            "get_page() turns a bad page number into the first or last page instead of an error.",
        ],
        "lesson": "Keep numbers as numbers in Python; format them in the template (|floatformat:'2g').",
    },
]

PATTERNS = [
    ("Latest row per key: sort by the date, fully",
     "20261030-01, 20261030-09, 20261104-04, 20261109-04, 20261109-05",
     "pandas: sort_values(date, ascending=False) right before drop_duplicates(keep='first'). SQL: ORDER BY date "
     "DESC NULLS LAST plus a unique tie-breaker in ROW_NUMBER / DISTINCT ON."),
    ("Check the inputs before the code",
     "20261030-02, 20261031-08, 20261104-08",
     "Print which files and rows are used (value_counts after each filter) before changing any logic."),
    ("Repeated rows mean a one-to-many join or duplicate keys",
     "20261029-11, 20261029-12, 20261030-21, 20261102-01, 20261102-04, 20261102-06, 20261109-03, 20261109-06",
     "Collapse the many side to one row per key first. Check COUNT(*) = COUNT(DISTINCT key), "
     "validate='many_to_one', or duplicated(subset=key)."),
    ("Agree the output before building",
     "20261102-09, 20261104-05, 20261109-05, 20261109-06",
     "Name the columns to add, what to keep, and the exact rule (first / any / only; owner or caller; "
     "which status wins a tie)."),
    ("Check what is really stored before filtering",
     "20261029-05, 20261029-08, 20261029-09, 20261030-03, 20261030-07, 20261102-07, 20261109-05, 20261109-07",
     "Look at real values and column names: df.columns, SELECT DISTINCT, value_counts, COUNTIF with wildcards."),
    ("Decide what a blank means",
     "20261109-01, 20261109-04",
     "For every filter or sort on a column that can be NULL: include or exclude (OR col IS NULL), "
     "and place them deliberately (NULLS FIRST / NULLS LAST)."),
    ("Same type, same clock before date maths",
     "20261109-02, 20261109-07",
     "Convert both sides to dates in one zone, (ts AT TIME ZONE 'Asia/Kolkata')::date, before subtracting; "
     "say whether a window is rolling hours or calendar days."),
    ("Start from the thing every row must represent",
     "20261102-05",
     "Every ID must appear? Start from the IDs and LEFT JOIN the rest; label why a value is zero."),
    ("Duplicate or double-used names break things",
     "20261029-02, 20261030-19, 20261031-06, 20261109-02",
     "Two columns with one name, or one column as both pivot key and value. Check names after every rename."),
    ("Names, brackets and arguments",
     "20261029-01, 20261030-12, 20261031-11, 20261104-03, 20261104-09, 20261109-02, 20261109-03, 20261109-08",
     "Built-in names, a token's value used as its name, a bracket closing late or missing, a missing argument, "
     "an unquoted literal."),
    ("Metabase: one statement, variables where values go",
     "20261109-03, 20261109-08, 20261109-09",
     "IN ({{var}}) with brackets, [[AND ...]] for optional filters, no trailing semicolon, test queries in "
     "their own question."),
    ("Verify against raw rows or an old version",
     "20261029-06, 20261029-07, 20261029-13, 20261030-02, 20261031-04, 20261104-11, 20261109-11",
     "Compare counts with raw data; run old and new code on the same input; assert_frame_equal; a query that "
     "counts differences."),
    ("Build checks that fail loudly",
     "20261031-07, 20261031-09, 20261031-12, 20261102-05, 20261102-08",
     "assert impossible values, raise on unreadable dates, cross-check two outputs, label every zero."),
    ("Prefer whole-column code to row loops",
     "20261031-05, 20261104-01, 20261104-02",
     "Column operators, np.where/select, groupby built-ins first; apply(lambda) only when nothing else fits."),
    ("Load only what you need",
     "20261030-14, 20261030-15, 20261030-16, 20261030-18",
     "Estimate rows x columns x 8 bytes. Select columns and filter rows before collecting; sink big outputs to disk."),
    ("Text that looks like a date or number isn't one",
     "20261029-04, 20261029-12, 20261030-13, 20261030-20, 20261031-03, 20261031-09",
     "Read IDs as text; give date formats explicitly; convert with to_datetime / to_timedelta / Int64."),
    ("Excel changes data when it saves",
     "20261030-02, 20261030-05, 20261030-21",
     "Never save a CSV from Excel. Long IDs become 2.61029E+17 and times become 59:48.4 for good."),
    ("Trust only output from a fresh run",
     "20261030-07, 20261030-16, 20261031-12",
     "Restart and Run All before trusting a number; close output files in Excel before writing them."),
]
