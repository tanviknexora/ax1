DAY = {
    "date": "Thursday, 29 October 2026",
    "focus": "Dialer file clean-up in pandas, the not-connected leads report in PostgreSQL (Metabase), "
             "and tagging Active-but-unreachable clients as automatic traders in Excel.",
    "outcome": "13 entries: 4 errors, 3 wrong results and 6 how-tos. Final report delivered as "
               "Not_Connected_Report_v3.xlsx with 205 clients tagged (High 122, Medium 34, Low 49).",
}

ENTRIES = [
    {
        "id": "20261029-01", "tool": "pandas", "type": "How-to",
        "title": "Name the dialer output file with the Start Time date range",
        "tags": "dates, f-string, files",
        "problem": "The combined dialer file needed a name showing the first and last `Start Time` dates.",
        "cause": "The dates were stored in variables named `min` and `max`, which replaces Python's built-in "
                 "functions. Saving the output into the input folder would also break the "
                 "\"exactly 2 .xlsx files\" check on the next run.",
        "code_lang": "python",
        "code": r'''concat_df['Start Time'] = pd.to_datetime(concat_df['Start Time'], format='%Y-%m-%d %H:%M:%S.%f')
min_date = concat_df['Start Time'].min()
max_date = concat_df['Start Time'].max()

if min_date.date() == max_date.date():
    output_name = f"st_daily_{min_date:%Y-%m-%d}.xlsx"
else:
    output_name = f"st_daily_{min_date:%Y-%m-%d}_to_{max_date:%Y-%m-%d}.xlsx"

output_dir = r'C:\Users\Administrator\Documents\Dialer\st_output'
os.makedirs(output_dir, exist_ok=True)
concat_df.to_excel(os.path.join(output_dir, output_name), index=False)''',
        "why": [
            "Inside an f-string, the text after the colon is a date format: `{min_date:%Y-%m-%d}` gives `2026-10-29`.",
            "`.date()` drops the time, so the `if` compares calendar days only.",
            "`os.makedirs(..., exist_ok=True)` creates the output folder only if it is missing.",
            "Windows file names can't contain colons, so use `%Y%m%d_%H%M` if you need times in the name.",
        ],
        "lesson": "Never name a variable after a built-in (`min`, `max`, `list`, `sum`). Keep outputs out of input folders.",
    },
    {
        "id": "20261029-02", "tool": "pandas", "type": "Error",
        "title": "Splitting Caller Ids: [1] vs .str[1], and \"'DataFrame' object has no attribute 'str'\"",
        "tags": "strings, duplicate columns, .str",
        "problem": "`uno_copy['Caller Ids'].str.split('|')[1]` gave the wrong result. The next attempt failed with "
                   "`AttributeError: 'DataFrame' object has no attribute 'str'`.",
        "cause": "`[1]` picks row label 1 of the whole column, not item 1 of each list. The AttributeError happened "
                 "because two columns were named `Caller Ids`, so selecting the name returned a DataFrame, which has no `.str`.",
        "code_lang": "python",
        "code": r'''# Find duplicated column names
print(uno_copy.columns[uno_copy.columns.duplicated()])

# Keep the first copy of each name (only if the copies are identical)
uno_copy = uno_copy.loc[:, ~uno_copy.columns.duplicated()]

# '917557160434 | 919810007919' -> '919810007919'
uno_copy['Caller Ids'] = uno_copy['Caller Ids'].str.split('|').str[1].str.strip()''',
        "why": [
            "`.str` applies a method to every value. `.str[1]` takes item 1 from each row's list.",
            "`columns.duplicated()` is True for each repeat after the first. `~` flips it, and `.loc[:, mask]` keeps the True columns.",
            "If the duplicate columns hold different data, rename them (`Caller Ids_1`) instead of dropping.",
            "Rows without `|` become NaN. Add `.fillna(uno_copy['Caller Ids'])` to keep the original value there.",
        ],
        "lesson": "If selecting one column name returns a DataFrame, there are duplicate column names.",
    },
    {
        "id": "20261029-03", "tool": "pandas", "type": "How-to",
        "title": "Extract customer and agent_id from Contact Info with regex",
        "tags": "regex, str.extract, nullable ints",
        "problem": "`Contact Info` holds text like `userId : 30628867 | callFirst : agent | customer : 919810007919 | "
                   "agent_id : 8943 | agentType : agent_id`. Only `customer` and `agent_id` were needed.",
        "cause": "Splitting on `|` depends on field order. A regex per field finds the value wherever it sits.",
        "code_lang": "python",
        "code": r'''uno_copy['customer'] = uno_copy['Contact Info'].str.extract(r'customer\s*:\s*(\d+)', expand=False)
uno_copy['agent_id'] = uno_copy['Contact Info'].str.extract(r'\bagent_id\s*:\s*(\d+)', expand=False)

uno_copy['customer'] = uno_copy['customer'].str[-10:]          # drop the 91 prefix
uno_copy['agent_id'] = pd.to_numeric(uno_copy['agent_id'], errors='coerce').astype('Int64')''',
        "why": [
            "`\\s*` = any number of spaces, `\\d+` = one or more digits, `( )` = the part returned.",
            "`\\b` (word boundary) stops `sub_agent_id` from matching. `agentType : agent_id` doesn't match because no digits follow.",
            "`expand=False` returns one column. Rows without a match get NaN, not an error.",
            "`Int64` (capital I) allows blanks; plain `int64` would turn the column into floats like `8943.0`.",
        ],
        "lesson": "One regex per field, so the order of fields doesn't matter.",
    },
    {
        "id": "20261029-04", "tool": "pandas", "type": "How-to",
        "title": "Combine Call Date and a 12-hour Call Time into one datetime",
        "tags": "dates, parsing, 12-hour clock",
        "problem": "`Call Date` (2026-10-28) and `Call Time` (11:58:14 pm) were separate columns.",
        "cause": "The time uses a 12-hour clock with am/pm, so it needs `%I` and `%p`, not `%H`.",
        "code_lang": "python",
        "code": r'''uno_copy['Call Datetime'] = pd.to_datetime(
    pd.to_datetime(uno_copy['Call Date']).dt.strftime('%Y-%m-%d')
    + ' '
    + uno_copy['Call Time'].astype(str).str.strip().str.upper(),
    format='%Y-%m-%d %I:%M:%S %p'
)
# '2026-10-28' + ' ' + '11:58:14 PM' -> 2026-10-28 23:58:14''',
        "why": [
            "The inner `pd.to_datetime` makes it work whether `Call Date` is text or a datetime.",
            "`.dt.strftime` turns each date into text, and `+` joins text columns row by row.",
            "`.str.upper()` turns `pm` into `PM` so it matches `%p`.",
            "To find bad rows, add `errors='coerce'` and look at rows where the result `.isna()`.",
        ],
        "lesson": "`%H` = 24-hour clock. `%I` + `%p` = 12-hour clock with AM/PM.",
    },
    {
        "id": "20261029-05", "tool": "SQL", "type": "Wrong result",
        "title": "Leads whose last 5 calls are all one disposition",
        "tags": "ROW_NUMBER, HAVING, BOOL_AND",
        "problem": "The original query used `DISTINCT ON` to get only the latest disposition. Filtering for `'0'` "
                   "found nothing, and the old filter on Call Later / Interested / Prospect would always return 0 rows.",
        "cause": "`DISTINCT ON` keeps one row per lead, so it can't look at 5 calls. The stored name is `'Zero'`, "
                 "not `'0'`. A lead whose last 5 calls are Zero can't also have Interested as its last call.",
        "code_lang": "sql",
        "code": r'''ranked_calls AS (
    SELECT cl.lead_id, cl.started_at, d.name AS disposition,
           ROW_NUMBER() OVER (PARTITION BY cl.lead_id
                              ORDER BY cl.started_at DESC, cl.id DESC) AS rn
    FROM call_logs cl
    JOIN old_leads ol              ON ol.id = cl.lead_id
    JOIN lead_calls lc             ON lc.call_log_id = cl.id
    JOIN lead_call_dispositions d  ON d.id = lc.disposition_id
    WHERE cl.status NOT IN ('placing', 'call_failed')
),
last_5_zero AS (
    SELECT lead_id, MAX(started_at) AS last_call_at
    FROM ranked_calls
    WHERE rn <= 5
    GROUP BY lead_id
    HAVING COUNT(*) = 5
       AND BOOL_AND(COALESCE(TRIM(disposition) = 'Zero', false))
)''',
        "why": [
            "`ROW_NUMBER` restarts at 1 for each lead (`PARTITION BY`); 1 is the newest call. `cl.id DESC` breaks ties.",
            "`HAVING` filters groups after `GROUP BY`; `WHERE` filters rows before.",
            "`COUNT(*) = 5` requires at least 5 calls. `BOOL_AND` is true only if every row passes.",
            "`BOOL_AND` skips NULLs, so `COALESCE(..., false)` makes a blank disposition break the streak.",
        ],
        "lesson": "Rank, cut, group, test. And check the stored value before filtering on it.",
    },
    {
        "id": "20261029-06", "tool": "SQL", "type": "Wrong result",
        "title": "Raw verification query showed non-Zero dispositions",
        "tags": "window functions, WINDOW, verification",
        "problem": "The raw-data check listed rows with other dispositions, so it looked like the main query was wrong.",
        "cause": "The check listed the last 5 calls of every lead, not only qualifying ones. The flags were "
                 "window results, which can't be filtered in the same SELECT that creates them.",
        "code_lang": "sql",
        "code": r'''last_5 AS (
    SELECT rc.*,
           COUNT(*) OVER w AS calls_in_last_5,
           BOOL_AND(COALESCE(TRIM(rc.disposition) = 'Zero', false)) OVER w AS all_zero
    FROM ranked_calls rc
    WHERE rc.rn <= 5
    WINDOW w AS (PARTITION BY rc.lead_id)
)
SELECT l.lead_id, l.rn AS call_rank,
       l.started_at AT TIME ZONE 'Asia/Kolkata' AS call_time, l.disposition
FROM last_5 l
WHERE l.calls_in_last_5 = 5 AND l.all_zero
ORDER BY l.lead_id, l.rn;''',
        "why": [
            "Adding `OVER (...)` to an aggregate gives each row its group's total without collapsing rows.",
            "`WINDOW w AS (...)` names the window once so every `OVER w` reuses it.",
            "Run order: FROM/JOIN, WHERE, GROUP BY, HAVING, window functions, SELECT, ORDER BY, LIMIT. So filter window results in the next step.",
            "Check: distinct `lead_id` in this output must equal the main query's row count.",
        ],
        "lesson": "Calculate in one CTE, filter in the next. Always compare a summary with its raw rows.",
    },
    {
        "id": "20261029-07", "tool": "SQL", "type": "How-to",
        "title": "Latest disposition is Zero, plus the distribution of the last 5",
        "tags": "FILTER, STRING_AGG, two-level aggregation",
        "problem": "Needed leads whose latest call is Zero, with counts of each disposition in the last 5 and their order.",
        "cause": "Counting per disposition and then per lead needs two levels of `GROUP BY`.",
        "code_lang": "sql",
        "code": r'''latest_zero AS (
    SELECT lead_id FROM last_5 WHERE rn = 1 AND disposition = 'Zero'
),
disp_counts AS (
    SELECT l.lead_id, l.disposition, COUNT(*) AS cnt
    FROM last_5 l JOIN latest_zero lz ON lz.lead_id = l.lead_id
    GROUP BY l.lead_id, l.disposition
),
per_lead AS (
    SELECT lead_id,
           SUM(cnt) AS calls_in_last_5,
           COALESCE(SUM(cnt) FILTER (WHERE disposition = 'Zero'), 0) AS zero_count,
           STRING_AGG(disposition || ' x' || cnt, ', ' ORDER BY cnt DESC, disposition) AS disposition_breakdown
    FROM disp_counts
    GROUP BY lead_id
)
-- sequence: STRING_AGG(disposition, ' -> ' ORDER BY rn)''',
        "why": [
            "`FILTER (WHERE ...)` feeds only matching rows into an aggregate.",
            "`SUM` over zero rows is NULL, so wrap it in `COALESCE(..., 0)`.",
            "`STRING_AGG` skips NULLs, so replace NULL dispositions with `'(blank)'` first.",
            "Check: leads with `zero_count = 5` must equal entry 20261029-05's result.",
        ],
        "lesson": "Count at the finest level first, then roll up.",
    },
    {
        "id": "20261029-08", "tool": "SQL", "type": "How-to",
        "title": "Unreachable list, name normalisation, and last-10 pivot with call times",
        "tags": "regexp_replace, VALUES, pivot",
        "problem": "Last 5 calls must all be one of 8 unreachable dispositions, with the last 10 shown as columns with IST times.",
        "cause": "Names like `Did not Connected /Out of Service` break exact matches. `lead_call_dispositions.created_at` "
                 "is when the option was set up in the CRM, not when a call happened.",
        "code_lang": "sql",
        "code": r'''target_dispositions AS (
    SELECT regexp_replace(lower(name), '[^a-z0-9]', '', 'g') AS disp_key
    FROM (VALUES ('Ringing/Busy'), ('Switched off'), ('Invalid Number'),
                 ('Did not Connected /Out of Service'), ('Disconnected by customer'),
                 ('Zero'), ('Didn''t connect'), ('No Answer')) AS v(name)
),
last_10 AS (
    SELECT lead_id, rn,
           started_at AT TIME ZONE 'Asia/Kolkata' AS call_time_ist,
           COALESCE(TRIM(disposition), '(blank)') AS disposition,
           regexp_replace(lower(COALESCE(disposition, '')), '[^a-z0-9]', '', 'g')
               IN (SELECT disp_key FROM target_dispositions) AS is_target
    FROM ranked_calls
    WHERE rn <= 10
)
-- pivot, one pair per call number:
-- MAX(l.disposition)   FILTER (WHERE l.rn = 1) AS call_1,
-- MAX(l.call_time_ist) FILTER (WHERE l.rn = 1) AS call_1_time''',
        "why": [
            "`[^a-z0-9]` = any character that isn't a lowercase letter or digit; `'g'` replaces all of them.",
            "Both sides are normalised, so spacing, capitals and curly apostrophes don't matter.",
            "`'Didn''t connect'`: two single quotes inside an SQL string = one apostrophe.",
            "Each lead has one row per `rn`, so `MAX(...) FILTER (WHERE rn = N)` simply pulls that row into a column.",
        ],
        "lesson": "Normalise both sides before comparing names. Call times come from `call_logs.started_at`.",
    },
    {
        "id": "20261029-09", "tool": "SQL", "type": "Error",
        "title": "column ol.client_id does not exist",
        "tags": "Metabase, column names",
        "problem": "Adding `ol.client_id` to the final SELECT failed.",
        "cause": "`old_leads` is `SELECT a.*` from saved question 1717, and that question has no column called `client_id`.",
        "code_lang": "sql",
        "code": r'''-- See the real column names first
SELECT * FROM {{#1717-leads-analysis}} LIMIT 1;

-- Names with capitals or spaces need double quotes
SELECT ol."Client ID" ...

-- The right column turned out to be:
SELECT ol.customer_id ...''',
        "why": [
            "Unquoted names are turned into lowercase, so `Client_ID` needs `\"Client_ID\"`.",
            "Questions built in Metabase's GUI with a join may prefix names, e.g. `\"Clients__client_id\"`.",
        ],
        "lesson": "Look at the real column names before guessing one.",
    },
    {
        "id": "20261029-10", "tool": "SQL", "type": "Error",
        "title": "syntax error at or near \"=\" (Position 5128)",
        "tags": "JOIN syntax, aliases",
        "problem": "The query failed after adding trading-profile columns.",
        "cause": "`left join ol.customer_id = ctp.customer_id` has no table name, no alias and no `ON`.",
        "code_lang": "sql",
        "code": r'''-- Wrong
left join ol.customer_id = ctp.customer_id

-- Right: JOIN <table> <alias> ON <condition>
LEFT JOIN customer_trading_profiles ctp ON ctp.customer_id = ol.customer_id

-- Give every AT TIME ZONE expression a name
ctp.last_txn_date AT TIME ZONE 'Asia/Kolkata' AS last_txn_date''',
        "why": [
            "`Position: 5128` is the character count from the start of the query; look near it for the quoted word.",
            "Without an alias, an `AT TIME ZONE` column comes out named `timezone`.",
        ],
        "lesson": "A join always reads JOIN <table> <alias> ON <condition>.",
    },
    {
        "id": "20261029-11", "tool": "SQL", "type": "Wrong result",
        "title": "Leads repeated after joining customer_status_history",
        "tags": "one-to-many join, DISTINCT ON, ARRAY_AGG",
        "problem": "Each lead appeared once per status change after the join.",
        "cause": "The status table has many rows per customer. Joining it directly multiplies the lead rows.",
        "code_lang": "sql",
        "code": r'''csh_dedup AS (
    SELECT DISTINCT ON (customer_id, occurred_at)
           customer_id, occurred_at,
           NULLIF(TRIM(previous_status::text), '')                 AS previous_status,
           COALESCE(NULLIF(TRIM(new_status::text), ''), '(blank)') AS new_status
    FROM customer_status_history
    WHERE customer_id IN (SELECT customer_id FROM old_leads)
    ORDER BY customer_id, occurred_at, created_at DESC, id DESC
),
status_summary AS (
    SELECT customer_id,
           (ARRAY_AGG(new_status ORDER BY occurred_at DESC))[1] AS rt_status,
           MAX(occurred_at)                                     AS rt_status_since,
           COUNT(*)                                             AS status_events,
           STRING_AGG(new_status || ' (' ||
                      TO_CHAR(occurred_at AT TIME ZONE 'Asia/Kolkata', 'DD Mon YYYY HH24:MI') || ')',
                      ' -> ' ORDER BY occurred_at)              AS status_journey
    FROM csh_dedup
    GROUP BY customer_id
)
-- final: LEFT JOIN status_summary ss ON ss.customer_id = ol.customer_id''',
        "why": [
            "`DISTINCT ON (a, b)` keeps the first row per (a, b) in `ORDER BY` order; `created_at DESC` makes the newest row win.",
            "`(ARRAY_AGG(... ORDER BY ... DESC))[1]` = the latest value. PostgreSQL arrays start at 1.",
            "`::text` stops `TRIM` failing if the status column is an enum.",
            "Join on `ol.customer_id`, not `ctp.customer_id`, so leads with no trading profile keep their status.",
        ],
        "lesson": "Collapse many-rows tables to one row per key before joining. Check COUNT(*) = COUNT(DISTINCT lead_id).",
    },
    {
        "id": "20261029-12", "tool": "pandas", "type": "Error",
        "title": "TypeError: Can only merge Series or DataFrame objects, a <class 'str'> was passed",
        "tags": "merge, latest row per key",
        "problem": "`pd.merge('df', 'nc_led', ...)` failed, and the result kept an extra `ClientID` column.",
        "cause": "The quotes made the names text, not DataFrames. The merge also used the full ledger instead of "
                 "the one-row-per-client balance, which would repeat leads.",
        "code_lang": "python",
        "code": r'''nc_led['CreatedAt'] = pd.to_datetime(nc_led['CreatedAt'])

nc_led_balance = (nc_led.sort_values('CreatedAt', ascending=False)
                        .drop_duplicates(subset='ClientID', keep='first')[['ClientID', 'Balance']])

df_bal = pd.merge(df,
                  nc_led_balance.rename(columns={'ClientID': 'zynixx_client_id'}),
                  on='zynixx_client_id', how='left', validate='many_to_one')''',
        "why": [
            "Sort newest first, then `drop_duplicates(keep='first')` = latest row per client (pandas' `DISTINCT ON`).",
            "Renaming the key and using `on=` leaves one key column. Or add `.drop(columns='ClientID')`.",
            "`validate='many_to_one'` raises an error if a client appears twice on the right.",
            "If `Balance` is empty everywhere, the key types differ: align them with `astype('string')`.",
        ],
        "lesson": "Variables have no quotes. Merge one row per key, and let `validate=` check it.",
    },
    {
        "id": "20261029-13", "tool": "Excel", "type": "How-to",
        "title": "Tag Active-but-unreachable clients as automatic traders",
        "tags": "IF, COUNTIF, confidence levels",
        "problem": "The manager asked for clients who are Active but don't answer calls, tagged as automatic traders.",
        "cause": "Being Active means different things depending on when they traded, so a confidence level was added.",
        "code_lang": "excel",
        "code": r'''AL  unanswered_call_days
=IF(COUNT(I2,K2,M2,O2,Q2)<5,"",1+(INT(I2)<>INT(K2))+(INT(K2)<>INT(M2))+(INT(M2)<>INT(O2))+(INT(O2)<>INT(Q2)))

AM  customer_tag
=IF(AG2="Active","Automatic Trader","")

AN  auto_trader_confidence
=IF(AM2="","",IF(OR(AL2=1,AE2<=Q2),"Low",IF(AE2>I2,"High","Medium")))

I = call_1_time (latest)   Q = call_5_time (streak start)   AE = last_txn_date   AG = rt_status''',
        "why": [
            "`INT()` drops the time from a date-time; calls are sorted newest first, so each date change is a new day.",
            "Low: all 5 calls on one day, or last trade before the streak. High: traded after the latest missed call. Medium: in between.",
            "Result: 205 tagged (High 122, Medium 34, Low 49). Missed calls are 71% No Answer; only 1 Invalid Number.",
            "Blank confidence = not Active, by design (315 in Clients, 19,882 in Leads).",
        ],
        "lesson": "Give a tag a confidence level when the evidence is uneven, and say what would confirm it.",
    },
]

PATTERNS = [
    ("Repeated rows mean a one-to-many join",
     "20261029-11, 20261029-12",
     "Collapse the many side to one row per key first. Check COUNT(*) = COUNT(DISTINCT key) in SQL, "
     "or use validate='many_to_one' in pandas."),
    ("Check what is really stored before filtering",
     "20261029-05, 20261029-08, 20261029-09",
     "Look at real values and column names: SELECT ... LIMIT 1, ILIKE '%word%', and wrap text in brackets to spot spaces."),
    ("Duplicate names break selection",
     "20261029-02",
     "A single name returning a DataFrame means duplicate columns. Find them with columns.duplicated()."),
    ("Calculate in one step, filter in the next",
     "20261029-06",
     "Window functions run after WHERE. Put them in a CTE and filter in the following SELECT."),
    ("Verify every summary against raw rows",
     "20261029-06, 20261029-07, 20261029-13",
     "Build a raw-data version of the query and compare counts before trusting a summary."),
    ("Text that looks like a date or number isn't one",
     "20261029-04, 20261029-12",
     "Convert with pd.to_datetime / pd.to_numeric before sorting, comparing or merging."),
]
