DAY9 = {
    "date": "Thursday, 12 November 2026",
    "focus": "The Pull Back call list by trade day (IST calendar), notebook errors after a kernel restart, a "
             "cross-check workbook behind the lead report, and Day 1 of building a language model from scratch.",
    "outcome": "9 entries: 4 errors, 2 wrong results and 3 how-tos. The lead report now carries its own Clients, "
               "Leads and Check sheets; the first counting language model reaches a validation loss of 2.239.",
    "review": "Repeated: setup lost on a restart (sys.path, helpers) and an old file shadowing a new one: keep setup "
              "in the first cell and check files exist. Open: the SLNo. check on repeated ledger rows (20261111-05) "
              "and the Thailand decisions. Next: the Django B0 self-check, then Build-an-LLM Day 2.",
}

ENTRIES9 = [
    {
        "id": "20261112-01", "tool": "SQL", "type": "Wrong result",
        "title": "INTERVAL '3 days' is 72 hours, not three calendar days",
        "tags": "AT TIME ZONE, date difference, CASE",
        "problem": "The Pull Back call list had to show only clients whose last trade was 2 or 3 days ago, tagged "
                   "Second day / Third day, with today's and yesterday's traders left out.",
        "cause": "last_txn_date >= CURRENT_TIMESTAMP - INTERVAL '3 days' counts back 72 hours: at 2 pm it starts at "
                 "2 pm three days earlier, so morning trades on day 3 were dropped.",
        "code": r'''WITH base AS (
    SELECT ctp.zynixx_client_id,
           (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata')::date
             - (ctp.last_txn_date AT TIME ZONE 'Asia/Kolkata')::date AS days_since_last_txn
           -- other columns, joins and filters as before
    FROM customer_trading_profiles ctp
    WHERE ctp.last_txn_date >= CURRENT_TIMESTAMP - INTERVAL '5 days'      -- quick first cut only
)
SELECT *, CASE days_since_last_txn WHEN 2 THEN 'Second day' WHEN 3 THEN 'Third day' END AS trade_day
FROM base
WHERE days_since_last_txn IN (2, 3)''',
        "why": [
            "Subtracting two IST dates gives whole calendar days: today 0, yesterday 1.",
            "One number drives both the filter and the label, so they can't disagree.",
            "The 5-day interval only narrows the rows; the calendar rule decides.",
        ],
        "lesson": "Rolling hours and calendar days answer different questions: say which one the team means.",
    },
    {
        "id": "20261112-02", "tool": "pandas", "type": "Error",
        "title": "TypeError: Boolean array expected for the condition, not object",
        "tags": "where, brackets, KeyError",
        "problem": "up(df['zynixx_client_id']).where(df['zynixx_client_id']).notna() failed, and the next line "
                   "parsed df['lead_Date'] into converted_at.",
        "cause": ".notna() sat outside the bracket, so where() got the ID column (text) instead of a True/False "
                 "condition. The next line had a capital D (KeyError) and the wrong column: it would have copied the "
                 "lead date into converted_at.",
        "code": r'''df['zynixx_client_id'] = up(df['zynixx_client_id']).where(df['zynixx_client_id'].notna())
df['converted_at'] = pd.to_datetime(df['converted_at'], format='ISO8601')

print(df[['zynixx_client_id', 'lead_date', 'converted_at']].head())      # IDs, not True/False''',
        "why": [
            "where(condition) keeps values where the condition is True; the condition must be True/False.",
            "Even if it had run, .notna() outside would have turned every ID into True or False.",
            "Column names are case-sensitive: lead_Date is not lead_date.",
        ],
        "lesson": "Read a chained line bracket by bracket: what goes into each call?",
    },
    {
        "id": "20261112-03", "tool": "Python", "type": "Error",
        "title": "ModuleNotFoundError: No module named 'ledger_loader' after a kernel restart",
        "tags": "sys.path, restart, first cell",
        "problem": "After restarting the kernel, from ledger_loader import get_final_ledger failed.",
        "cause": "A restart wipes everything, including the sys.path entry for the Office folder, so Python stopped "
                 "looking there. The helpers up and KEY were gone too.",
        "code": r'''import sys

OFFICE = r"C:/Users/Administrator/Videos/Office"
if OFFICE not in sys.path:
    sys.path.insert(0, OFFICE)
from ledger_loader import get_final_ledger
up = lambda s: s.astype(str).str.strip().str.upper()

# once, for every notebook:   setx PYTHONPATH "C:\Users\Administrator\Videos\Office"''',
        "why": [
            "Python only searches its standard folders, the notebook's own folder and sys.path.",
            "With setup in cell 1, a restart is fixed by running from the top.",
            "PYTHONPATH, or keeping notebooks in the Office folder, removes the need for the line.",
        ],
        "lesson": "Put imports, paths and helpers in the first cell.",
    },
    {
        "id": "20261112-04", "tool": "Python", "type": "Error",
        "title": "A sys.path entry missing its drive letter",
        "tags": "Windows paths, os.path.isdir",
        "problem": "The first cell had sys.path.insert(0, r\":/Users/Administrator/Videos/Office\"), and the import "
                   "still failed.",
        "cause": "Without the C, Windows can't tell which drive is meant, so Python searched a folder that doesn't "
                 "exist, without any warning.",
        "code": r'''sys.path.insert(0, r"C:/Users/Administrator/Videos/Office")

import os
print(os.path.isdir(r"C:/Users/Administrator/Videos/Office"))     # True: the folder exists''',
        "why": [
            "sys.path accepts any text; it never checks that the folder is real.",
            "One isdir() line turns a silent typo into an obvious False.",
        ],
        "lesson": "Check that a path exists before relying on it.",
    },
    {
        "id": "20261112-05", "tool": "Excel", "type": "How-to",
        "title": "Clients, Leads and Check sheets behind the lead report",
        "tags": "COUNTIFS, SUMIFS, INDEX/MATCH",
        "problem": "Needed to cross-check the monthly summaries against the rows behind them, inside Excel.",
        "cause": "A summary on its own can't show where its numbers came from; the detail rows and a recount can.",
        "code": r'''export_lead_workbook(summaries, path, clients_detail, leads_detail, ledger_up_to=led['CreatedAt'].max())

Check, column D:  =IFERROR(INDEX('Oct 2026'!$L$6:$L$20, MATCH($B5, 'Oct 2026'!$A$6:$A$20, 0)), 0)
Check, column E:  =SUMIFS(Clients!$I$2:$I$300, Clients!$B$2:$B$300, $B5)
Check, column G:  =IF(ABS(D5-E5)<0.01, "OK", "CHECK")''',
        "why": [
            "Clients has one row per client with each month's money; Leads has one row per lead.",
            "Tested: 80 checks OK, and a figure changed on purpose was flagged with its difference of 500.",
            "Filtering Leads or Clients by source shows exactly which rows make up a number.",
        ],
        "lesson": "Ship the rows behind a summary, with a check that proves they agree.",
    },
    {
        "id": "20261112-06", "tool": "Python", "type": "Error",
        "title": "ImportError: cannot import name 'export_lead_workbook'",
        "tags": "old file, Downloads copy, reload",
        "problem": "from export_lead_summary import export_lead_workbook failed after downloading the new module.",
        "cause": "Either the Office folder still held the old file (the download landed in Downloads, possibly renamed "
                 "'export_lead_summary (1).py'), or the notebook had imported the old version before the file was "
                 "replaced.",
        "code": r'''office = r"C:/Users/Administrator/Videos/Office/export_lead_summary.py"
print("new version:", "def export_lead_workbook" in open(office, encoding="utf-8").read())

import importlib
import export_lead_summary
importlib.reload(export_lead_summary)              # or restart the kernel''',
        "why": [
            "Python imports a module once per kernel; replacing the file changes nothing until a restart or reload.",
            "Browsers rename a second download, so the new code can sit beside the old under another name.",
        ],
        "lesson": "After replacing a module, check the file Python actually loads, then restart.",
    },
    {
        "id": "20261112-07", "tool": "pandas", "type": "How-to",
        "title": "Why the clients table keeps leads with no converted_at",
        "tags": "NaT, ledger vs CRM",
        "problem": "Asked why the clients table doesn't drop rows whose converted_at is blank.",
        "cause": "clients is every client with an ID, one source each, and it feeds FTD, deposits and trade volume, "
                 "which come from the ledger. Dropping blank converted_at would remove real depositors.",
        "code": r'''no_conv = clients['converted_at'].isna()
print("Clients with no converted_at:", int(no_conv.sum()))
print("...of which deposited:", int((no_conv & clients['alltime_deposit'].gt(0)).sum()))

converted_clients = clients[clients['converted_at'].notna()]     # a separate table, if needed''',
        "why": [
            "The sort puts converted leads first; blank dates only lose ties, they aren't removed.",
            "A blank date (NaT) is never inside a month, so conversion counts ignore it without a filter.",
        ],
        "lesson": "Before dropping blanks, ask which numbers those rows feed.",
    },
    {
        "id": "20261112-08", "tool": "NumPy", "type": "How-to",
        "title": "A language model by counting: bigram and trigram",
        "tags": "tokens, probabilities, loss",
        "problem": "Day 1 of building an LLM from scratch: learn next-character probabilities from 32,033 names, and "
                   "measure them.",
        "cause": "Every LLM predicts the next token; the simplest version counts which token follows which.",
        "code": r'''N = np.zeros((27, 27), dtype=np.int64)              # row = this character, column = next
for w in train:
    padded = "." + w + "."
    for a, b in zip(padded, padded[1:]):
        N[stoi[a], stoi[b]] += 1
P = (N + 1) / (N + 1).sum(axis=1, keepdims=True)    # each row adds up to 1
# validation loss: untrained 3.296 -> bigram 2.451 -> trigram 2.239''',
        "why": [
            "keepdims keeps the row totals as a column, so each row is divided by its own total.",
            "Loss = the average -log(probability of what really came next); lower is better.",
            "Each extra character of context multiplies the table by 27, which is why neural networks come next.",
        ],
        "lesson": "Measure every model with one number, on data it hasn't seen.",
    },
    {
        "id": "20261112-09", "tool": "NumPy", "type": "Wrong result",
        "title": "+1 smoothing drowned a tiny dataset",
        "tags": "smoothing, data size",
        "problem": "A bigram model trained on 14 UAE place names wrote noise such as ' wn fwttikm ket msbu'.",
        "cause": "14 names give only 122 pairs for a 441-cell table; adding 1 to every cell added 441 imaginary counts "
                 "to 122 real ones.",
        "code": r'''k = 0.01                                            # small data: smooth lightly
PP = (NP + k) / (NP + k).sum(axis=1, keepdims=True)
# k = 1    -> ' wn fwttikm ket msbu', 'jhahqfalhqefsjjb'
# k = 0.01 -> 'ruma', 'jan', 'attaishaima' ''',
        "why": [
            "On the 32,033 names, k = 0.1 and k = 1 give the same validation loss (2.4514); k = 10 is worse.",
            "How much smoothing is right depends on how much data each row has.",
        ],
        "lesson": "A setting that suits big data can swamp small data: test it on both.",
    },
]

# ---- Patterns: carried from 11 November, extended with today's cards ----------------------------
from entries_11 import PATTERNS as _PREVIOUS

_ADD = {
    "Same type, same clock before date maths": ["20261112-01"],
    "Every number counts by one stated date": ["20261112-01", "20261112-07"],
    "Names, brackets and arguments": ["20261111-15", "20261112-02"],
    "Check the inputs before the code": ["20261112-04"],
    "Verify against raw rows or an old version": ["20261112-05"],
    "Build checks that fail loudly": ["20261112-05"],
    "Trust only output from a fresh run": ["20261112-03", "20261112-06"],
    "Decide what a blank means": ["20261112-07"],
    "Try the edge cases of every business rule": ["20261112-09"],
}
PATTERNS = []
for name, seen, what in _PREVIOUS:
    PATTERNS.append((name, seen + "".join(", " + i for i in _ADD.get(name, [])), what))

PATTERNS.append(("Put setup in the first cell",
                 "20261112-03, 20261112-04, 20261112-06",
                 "Imports, sys.path and helpers live in cell 1. After a restart or a replaced file, run from the top, "
                 "and check that folders and files exist before importing from them."))
