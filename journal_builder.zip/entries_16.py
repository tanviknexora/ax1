DAY11 = {
    "date": "Monday, 16 November 2026",
    "focus": "The Pullback SOP report exported in the team's layout, instrument names taken from ledger "
             "narrations, USD instruments split into crypto spot and other USD, client lists per group, and "
             "a practice guide for turning the USD script into a professional file.",
    "outcome": "9 entries: 1 error, 4 wrong results and 4 how-tos. The SOP sheet reproduces the template with "
               "client lists that reconcile to every total; the client-group summary now adds up to the "
               "customer count.",
    "review": "Repeated: groups that overlapped or dropped blanks, so totals didn't match lists. Open: the "
              "Official Trump Coin's symbol for CRYPTO_SPOT; whether P1's 3rd day means exactly 3 days; "
              "re-run the USD summary after basing 'USD client' on trades only.",
}

ENTRIES11 = [
    {
        "id": "20261116-01", "tool": "Python", "type": "How-to",
        "title": "Exporting the Pullback SOP report in the team's layout",
        "tags": "openpyxl, merged cells, fills",
        "problem": "Needed the P1-P4 TL and CRE tables in the existing format: black title bar, coloured "
                   "block headers, yellow column headers, bold totals; plus a client list per priority.",
        "cause": "pandas writes plain tables; the layout needs cells placed and styled with openpyxl.",
        "code": r'''ws.merge_cells(start_row=1, start_column=left, end_row=1, end_column=right)
style(ws.cell(1, left, title), Font(name="Agency FB", size=30, color="FFFFFF"), TITLE_FILL)
end = write_table(ws, tl_tables[p], top=3, left=lefts[p])    # one block per priority
assert tl_total == len(rows) == cre_total                    # every total matches its client list''',
        "why": [
            "Values instead of spill formulas: the #SPILL! errors in the old sheet are gone.",
            "P1 splits into 2nd and 3rd day from days since the last transaction, as in the SQL.",
            "Reference sheets hold exactly the rows each total counts.",
        ],
        "lesson": "Build reports so every total can be traced to a list of rows.",
    },
    {
        "id": "20261116-02", "tool": "pandas", "type": "Wrong result",
        "title": "groupby dropped clients with no TL or CRE",
        "tags": "groupby, NaN keys, fillna",
        "problem": "TL and CRE totals were lower than the number of clients in each priority.",
        "cause": "groupby leaves out rows whose key is blank, so clients without a Manager or Assigned To "
                 "vanished from the counts.",
        "code": r'''rows["Manager"] = rows["Manager"].fillna("No TL")
rows["Assigned To"] = rows["Assigned To"].fillna("No CRE")
# or: df.groupby("Manager", dropna=False)''',
        "why": [
            "A labelled blank keeps the row in the count and shows the gap to the team.",
            "Checking totals against the client lists caught it.",
        ],
        "lesson": "Decide what a blank group key means before grouping.",
    },
    {
        "id": "20261116-03", "tool": "pandas", "type": "Wrong result",
        "title": "'Active ' with a trailing space got no priority",
        "tags": "np.select, strip",
        "problem": "19 Active clients ended up 'Unassigned' in the priority column.",
        "cause": "np.select compared 'Active ' (with a space) to 'Active', which never matches.",
        "code": r'''req["Real-Time Status"] = req["Real-Time Status"].str.strip()   # before the conditions''',
        "why": [
            "The check line listing statuses with no priority showed 'Active ' next to 'Churned'.",
            "Clean labels once, where the data enters, before any rule uses them.",
        ],
        "lesson": "Print the values that matched no rule; they show what to clean.",
    },
    {
        "id": "20261116-04", "tool": "Python", "type": "Error",
        "title": "NameError: name 'req' is not defined",
        "tags": "kernel state, cell order, %run",
        "problem": "The export cell failed at its first use of req.",
        "cause": "It ran in a session where the cells creating req hadn't run (after a restart, an earlier "
                 "error, or as a separate file).",
        "code": r'''print("req" in globals())                  # False: the creating cell hasn't run
%run C:/Users/Administrator/Videos/Office/pullback_sop_full.py   # or: Restart and Run All''',
        "why": [
            "The fix: one file holding loading, rules and export, which runs on its own.",
            "Tested in a fresh Python process, the situation that caused the error.",
        ],
        "lesson": "A cell that depends on other cells is only as safe as the order they ran in.",
    },
    {
        "id": "20261116-05", "tool": "pandas", "type": "How-to",
        "title": "The last word of a narration",
        "tags": "str.rsplit, str[-1]",
        "problem": "Needed the instrument from 'Trade bill for NIFTY26N1725250CE'.",
        "cause": "",
        "code": r'''led["Instrument"] = led["Narration"].str.rsplit(n=1).str[-1]
is_bill = led["LedgerType"].eq("BILL")                     # only trades have instruments''',
        "why": [
            "rsplit(n=1) splits once from the right instead of breaking the whole sentence.",
            "Blank narrations stay blank; non-BILL rows have no instrument to take.",
        ],
        "lesson": "Split only as much as you need.",
    },
    {
        "id": "20261116-06", "tool": "pandas", "type": "How-to",
        "title": "Classifying instruments: crypto spot, other USD, not USD",
        "tags": "set, isin, np.select",
        "problem": "Needed USD instruments split into the platform's crypto spot list and everything else.",
        "cause": "",
        "code": r'''symbol = led["Instrument"].str.strip().str.upper()
is_usd = symbol.str.contains("USD", regex=False, na=False)
led["USD Class"] = np.select([symbol.isin(CRYPTO_SPOT), is_usd],
                             ["Crypto Spot", "Other USD"], default="Not USD")''',
        "why": [
            "np.select uses the first true condition, so crypto is checked before general USD.",
            "Listing 'Other USD' symbols shows new coins to add (the Official Trump Coin's symbol).",
        ],
        "lesson": "Keep the list in a set in the settings, and review what fell outside it.",
    },
    {
        "id": "20261116-07", "tool": "pandas", "type": "Wrong result",
        "title": "Client groups added up to more than the customers (48,557 vs 35,603)",
        "tags": "overlapping groups, set maths",
        "problem": "Crypto Spot (20,167) + Other USD (18,515) + Non-USD (9,875) exceeded the 35,603 customers.",
        "cause": "Clients who traded both crypto and other USD were in both groups, about 12,954 counted twice.",
        "code": r'''groups = {
    "Crypto Spot only": crypto - other,  "Other USD only": other - crypto,
    "Both": crypto & other,              "Non-USD trades only": traded - crypto - other,
    "No trades": in_ledger - traded,
}
assert sum(len(g) for g in groups.values()) == len(in_ledger)''',
        "why": [
            "The client lists were right; only the summary needed groups that don't overlap.",
            "The check stops the run if the groups ever stop adding up.",
        ],
        "lesson": "If a summary must add up to a total, give each client exactly one label.",
    },
    {
        "id": "20261116-08", "tool": "pandas", "type": "Wrong result",
        "title": "'USD client' meant two different things",
        "tags": "definitions, BILL rows",
        "problem": "usd and non_usd_clients came from all ledger rows; the client lists used trades only.",
        "cause": "A deposit narration ending in a word like 'USDT' made a client 'USD' without any USD trade.",
        "code": r'''trades = led[led["LedgerType"].eq("BILL")]           # one table every step uses
usd = trades[trades["Instrument"].str.contains("USD", regex=False, na=False)]''',
        "why": [
            "In the test, a deposit-only client with a 'USDT' narration landed in 'No trades', as it should.",
            "One base table means one definition throughout.",
        ],
        "lesson": "Define each term once, from one table, and build everything from it.",
    },
    {
        "id": "20261116-09", "tool": "Python", "type": "How-to",
        "title": "Turning the USD notebook into a professional .py: a practice plan",
        "tags": "refactoring, settings, tests",
        "problem": "Wanted to practise writing the USD report professionally, not just read a finished version.",
        "cause": "",
        "code": r'''Settings   paths, CRYPTO_SPOT, class names, formats
Helpers    clean_ids, latest_file, classify_instruments
Steps      load_customer_ids -> load_trades -> client_groups -> group_summary
           -> client_table -> write_sheet
Entry      main(), if __name__ == "__main__"   then: ruff format, ruff check, pytest''',
        "why": [
            "Nine steps, each with a check; the answer key goes in a separate folder.",
            "Its stand-in ledger_loader.py must never be copied into the Office folder.",
        ],
        "lesson": "Practise by rebuilding real reports from a blank file, then compare.",
    },
]
PATTERNS = [('Latest row per key: sort by the date, fully',
  '20261030-01, 20261030-09, 20261104-04, 20261109-04, 20261109-05, 20261114-09, 20261114-11',
  "pandas: sort_values(date, ascending=False) right before drop_duplicates(keep='first'). SQL: ORDER BY date "
  'DESC NULLS LAST plus a unique tie-breaker in ROW_NUMBER / DISTINCT ON.'),
 ('Check the inputs before the code',
  '20261030-02, 20261031-08, 20261104-08, 20261110-02, 20261112-04, 20261114-03, 20261116-03',
  'Print which files and rows are used (value_counts after each filter) before changing any logic.'),
 ('Repeated rows mean a one-to-many join or duplicate keys',
  '20261029-11, 20261029-12, 20261030-21, 20261102-01, 20261102-04, 20261102-06, 20261109-03, 20261109-06, '
  '20261110-09, 20261111-05',
  'Collapse the many side to one row per key first. Check COUNT(*) = COUNT(DISTINCT key), '
  "validate='many_to_one', or duplicated(subset=key)."),
 ('Agree the output before building',
  '20261102-09, 20261104-05, 20261109-05, 20261109-06, 20261110-10, 20261111-03, 20261111-08',
  'Name the columns to add, what to keep, and the exact rule (first / any / only; owner or caller; which '
  'status wins a tie).'),
 ('Check what is really stored before filtering',
  '20261029-05, 20261029-08, 20261029-09, 20261030-03, 20261030-07, 20261102-07, 20261109-05, 20261109-07, '
  '20261111-05, 20261111-10',
  'Look at real values and column names: df.columns, SELECT DISTINCT, value_counts, COUNTIF with wildcards.'),
 ('One label per row when groups must add up',
  '20261110-01, 20261110-05, 20261111-08, 20261116-06, 20261116-07',
  'np.select([...], [...], default=...) gives each row exactly one label, decided in a stated order; the '
  'groups then always sum to the total.'),
 ('Try the edge cases of every business rule',
  '20261110-06, 20261110-07, 20261111-03, 20261112-09',
  'Before trusting a rule, run a zero row (no activity), a just-below row and a just-above row through it.'),
 ('Name each setting and window once',
  '20261110-05, 20261110-08, 20261111-12, 20261116-09',
  'Program numbers and date windows as named settings at the top (REPORT_MONTH, TRADE_MONTHS, '
  'MIN_TRADE_VALUE); never reuse one start/end for two meanings.'),
 ('Every number counts by one stated date',
  '20261110-10, 20261111-08, 20261111-10, 20261112-01, 20261112-07',
  'Lead date, event date, rolling 30 days: name the date each column counts by, keep views apart, and print '
  "the window in every run and in the report's notes."),
 ('Decide what a blank means',
  '20261109-01, 20261109-04, 20261112-07, 20261114-07, 20261116-02',
  'For every filter or sort on a column that can be NULL: include or exclude (OR col IS NULL), and place '
  'them deliberately (NULLS FIRST / NULLS LAST).'),
 ('Same type, same clock before date maths',
  '20261109-02, 20261109-07, 20261110-10, 20261112-01, 20261114-06',
  "Convert both sides to dates in one zone, (ts AT TIME ZONE 'Asia/Kolkata')::date, before subtracting; say "
  'whether a window is rolling hours or calendar days.'),
 ('Start from the thing every row must represent',
  '20261102-05, 20261116-08',
  'Every ID must appear? Start from the IDs and LEFT JOIN the rest; label why a value is zero.'),
 ('Duplicate or double-used names break things',
  '20261029-02, 20261030-19, 20261031-06, 20261109-02, 20261110-09, 20261111-10',
  'Two columns with one name, or one column as both pivot key and value. Check names after every rename.'),
 ('Names, brackets and arguments',
  '20261029-01, 20261030-12, 20261031-11, 20261104-03, 20261104-09, 20261109-02, 20261109-03, 20261109-08, '
  '20261111-15, 20261112-02, 20261114-02, 20261114-04, 20261114-05',
  "Built-in names, a token's value used as its name, a bracket closing late or missing, a missing argument, "
  'an unquoted literal.'),
 ('Metabase: one statement, variables where values go',
  '20261109-03, 20261109-08, 20261109-09',
  'IN ({{var}}) with brackets, [[AND ...]] for optional filters, no trailing semicolon, test queries in '
  'their own question.'),
 ('Verify against raw rows or an old version',
  '20261029-06, 20261029-07, 20261029-13, 20261030-02, 20261031-04, 20261104-11, 20261109-11, 20261110-04, '
  '20261111-06, 20261112-05, 20261114-07',
  'Compare counts with raw data; run old and new code on the same input; assert_frame_equal; a query that '
  'counts differences.'),
 ('Build checks that fail loudly',
  '20261031-07, 20261031-09, 20261031-12, 20261102-05, 20261102-08, 20261112-05, 20261116-02, 20261116-07',
  'assert impossible values, raise on unreadable dates, cross-check two outputs, label every zero.'),
 ('Prefer whole-column code to row loops',
  '20261031-05, 20261104-01, 20261104-02, 20261110-04, 20261114-10',
  'Column operators, np.where/select, groupby built-ins first; apply(lambda) only when nothing else fits.'),
 ('Load only what you need',
  '20261030-14, 20261030-15, 20261030-16, 20261030-18',
  'Estimate rows x columns x 8 bytes. Select columns and filter rows before collecting; sink big outputs to '
  'disk.'),
 ("Text that looks like a date or number isn't one",
  '20261029-04, 20261029-12, 20261030-13, 20261030-20, 20261031-03, 20261031-09, 20261111-02, 20261111-11, '
  '20261114-03',
  'Read IDs as text; give date formats explicitly; convert with to_datetime / to_timedelta / Int64.'),
 ('Excel changes data when it saves',
  '20261030-02, 20261030-05, 20261030-21',
  'Never save a CSV from Excel. Long IDs become 2.61029E+17 and times become 59:48.4 for good.'),
 ('Trust only output from a fresh run',
  '20261030-07, 20261030-16, 20261031-12, 20261110-09, 20261110-11, 20261111-09, 20261111-13, 20261112-03, '
  '20261112-06, 20261116-04',
  'Restart and Run All before trusting a number; close output files in Excel before writing them.'),
 ('Put setup in the first cell',
  '20261112-03, 20261112-04, 20261112-06, 20261116-04',
  'Imports, sys.path and helpers live in cell 1. After a restart or a replaced file, run from the top, and '
  'check that folders and files exist before importing from them.'),
 ('Measure before optimising',
  '20261114-08, 20261114-10, 20261114-11',
  'Three speed claims changed once measured: map vs merge, replace vs map, and the fastest '
  'first-row-per-group method. Time each stage on realistic data, then change what costs most.')]
