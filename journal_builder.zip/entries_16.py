DAY11 = {
    "date": "Monday, 16 November 2026",
    "focus": "The Pullback SOP report exported in the team's layout, instrument names taken from ledger "
             "narrations, USD instruments split into crypto spot and other USD, client lists per group, and "
             "a practice guide for turning the USD script into a professional file.",
    "outcome": "9 entries: 1 error, 4 wrong results and 4 how-tos. The SOP sheet reproduces the template with "
               "client lists that reconcile to every total; the client-group summary now adds up to the "
               "customer count.",
    "review": "Repeated: groups that overlapped or dropped blanks, so totals didn't match lists. Open: the "
              "Official Trump Coin's symbol for CRYPTO_SPOT; whether P1's 3rd day means exactly 3 days; "
              "re-run the USD summary after basing 'USD client' on trades only.",
}

ENTRIES11 = [
    {
        "id": "20261116-01", "tool": "Python", "type": "How-to",
        "title": "Exporting the Pullback SOP report in the team's layout",
        "tags": "openpyxl, merged cells, fills",
        "problem": "Needed the P1-P4 TL and CRE tables in the existing format: black title bar, coloured "
                   "block headers, yellow column headers, bold totals; plus a client list per priority.",
        "cause": "pandas writes plain tables; the layout needs cells placed and styled with openpyxl.",
        "code": r'''ws.merge_cells(start_row=1, start_column=left, end_row=1, end_column=right)
style(ws.cell(1, left, title), Font(name="Agency FB", size=30, color="FFFFFF"), TITLE_FILL)
end = write_table(ws, tl_tables[p], top=3, left=lefts[p])    # one block per priority
assert tl_total == len(rows) == cre_total                    # every total matches its client list''',
        "why": [
            "Values instead of spill formulas: the #SPILL! errors in the old sheet are gone.",
            "P1 splits into 2nd and 3rd day from days since the last transaction, as in the SQL.",
            "Reference sheets hold exactly the rows each total counts.",
        ],
        "lesson": "Build reports so every total can be traced to a list of rows.",
    },
    {
        "id": "20261116-02", "tool": "pandas", "type": "Wrong result",
        "title": "groupby dropped clients with no TL or CRE",
        "tags": "groupby, NaN keys, fillna",
        "problem": "TL and CRE totals were lower than the number of clients in each priority.",
        "cause": "groupby leaves out rows whose key is blank, so clients without a Manager or Assigned To "
                 "vanished from the counts.",
        "code": r'''rows["Manager"] = rows["Manager"].fillna("No TL")
rows["Assigned To"] = rows["Assigned To"].fillna("No CRE")
# or: df.groupby("Manager", dropna=False)''',
        "why": [
            "A labelled blank keeps the row in the count and shows the gap to the team.",
            "Checking totals against the client lists caught it.",
        ],
        "lesson": "Decide what a blank group key means before grouping.",
    },
    {
        "id": "20261116-03", "tool": "pandas", "type": "Wrong result",
        "title": "'Active ' with a trailing space got no priority",
        "tags": "np.select, strip",
        "problem": "19 Active clients ended up 'Unassigned' in the priority column.",
        "cause": "np.select compared 'Active ' (with a space) to 'Active', which never matches.",
        "code": r'''req["Real-Time Status"] = req["Real-Time Status"].str.strip()   # before the conditions''',
        "why": [
            "The check line listing statuses with no priority showed 'Active ' next to 'Churned'.",
            "Clean labels once, where the data enters, before any rule uses them.",
        ],
        "lesson": "Print the values that matched no rule; they show what to clean.",
    },
    {
        "id": "20261116-04", "tool": "Python", "type": "Error",
        "title": "NameError: name 'req' is not defined",
        "tags": "kernel state, cell order, %run",
        "problem": "The export cell failed at its first use of req.",
        "cause": "It ran in a session where the cells creating req hadn't run (after a restart, an earlier "
                 "error, or as a separate file).",
        "code": r'''print("req" in globals())                  # False: the creating cell hasn't run
%run C:/Users/Administrator/Videos/Office/pullback_sop_full.py   # or: Restart and Run All''',
        "why": [
            "The fix: one file holding loading, rules and export, which runs on its own.",
            "Tested in a fresh Python process, the situation that caused the error.",
        ],
        "lesson": "A cell that depends on other cells is only as safe as the order they ran in.",
    },
    {
        "id": "20261116-05", "tool": "pandas", "type": "How-to",
        "title": "The last word of a narration",
        "tags": "str.rsplit, str[-1]",
        "problem": "Needed the instrument from 'Trade bill for NIFTY26N1725250CE'.",
        "cause": "",
        "code": r'''led["Instrument"] = led["Narration"].str.rsplit(n=1).str[-1]
is_bill = led["LedgerType"].eq("BILL")                     # only trades have instruments''',
        "why": [
            "rsplit(n=1) splits once from the right instead of breaking the whole sentence.",
            "Blank narrations stay blank; non-BILL rows have no instrument to take.",
        ],
        "lesson": "Split only as much as you need.",
    },
    {
        "id": "20261116-06", "tool": "pandas", "type": "How-to",
        "title": "Classifying instruments: crypto spot, other USD, not USD",
        "tags": "set, isin, np.select",
        "problem": "Needed USD instruments split into the platform's crypto spot list and everything else.",
        "cause": "",
        "code": r'''symbol = led["Instrument"].str.strip().str.upper()
is_usd = symbol.str.contains("USD", regex=False, na=False)
led["USD Class"] = np.select([symbol.isin(CRYPTO_SPOT), is_usd],
                             ["Crypto Spot", "Other USD"], default="Not USD")''',
        "why": [
            "np.select uses the first true condition, so crypto is checked before general USD.",
            "Listing 'Other USD' symbols shows new coins to add (the Official Trump Coin's symbol).",
        ],
        "lesson": "Keep the list in a set in the settings, and review what fell outside it.",
    },
    {
        "id": "20261116-07", "tool": "pandas", "type": "Wrong result",
        "title": "Client groups added up to more than the customers (48,557 vs 35,603)",
        "tags": "overlapping groups, set maths",
        "problem": "Crypto Spot (20,167) + Other USD (18,515) + Non-USD (9,875) exceeded the 35,603 customers.",
        "cause": "Clients who traded both crypto and other USD were in both groups, about 12,954 counted twice.",
        "code": r'''groups = {
    "Crypto Spot only": crypto - other,  "Other USD only": other - crypto,
    "Both": crypto & other,              "Non-USD trades only": traded - crypto - other,
    "No trades": in_ledger - traded,
}
assert sum(len(g) for g in groups.values()) == len(in_ledger)''',
        "why": [
            "The client lists were right; only the summary needed groups that don't overlap.",
            "The check stops the run if the groups ever stop adding up.",
        ],
        "lesson": "If a summary must add up to a total, give each client exactly one label.",
    },
    {
        "id": "20261116-08", "tool": "pandas", "type": "Wrong result",
        "title": "'USD client' meant two different things",
        "tags": "definitions, BILL rows",
        "problem": "usd and non_usd_clients came from all ledger rows; the client lists used trades only.",
        "cause": "A deposit narration ending in a word like 'USDT' made a client 'USD' without any USD trade.",
        "code": r'''trades = led[led["LedgerType"].eq("BILL")]           # one table every step uses
usd = trades[trades["Instrument"].str.contains("USD", regex=False, na=False)]''',
        "why": [
            "In the test, a deposit-only client with a 'USDT' narration landed in 'No trades', as it should.",
            "One base table means one definition throughout.",
        ],
        "lesson": "Define each term once, from one table, and build everything from it.",
    },
    {
        "id": "20261116-09", "tool": "Python", "type": "How-to",
        "title": "Turning the USD notebook into a professional .py: a practice plan",
        "tags": "refactoring, settings, tests",
        "problem": "Wanted to practise writing the USD report professionally, not just read a finished version.",
        "cause": "",
        "code": r'''Settings   paths, CRYPTO_SPOT, class names, formats
Helpers    clean_ids, latest_file, classify_instruments
Steps      load_customer_ids -> load_trades -> client_groups -> group_summary
           -> client_table -> write_sheet
Entry      main(), if __name__ == "__main__"   then: ruff format, ruff check, pytest''',
        "why": [
            "Nine steps, each with a check; the answer key goes in a separate folder.",
            "Its stand-in ledger_loader.py must never be copied into the Office folder.",
        ],
        "lesson": "Practise by rebuilding real reports from a blank file, then compare.",
    },
]
