DAY3 = {
    "date": "Saturday, 31 October 2026",
    "focus": "Rebuilding the Stringee + Uno dialer report as a fast, tested script; making it multi-day; "
             "the Uno API token; client trading days.",
    "outcome": "12 entries: 3 errors, 3 wrong results and 6 how-tos. dialer_report.py matched the old notebook "
               "cell for cell on Stringee data, fixed three old bugs, and runs a test day in 2.1 s instead of 7.9 s.",
    "review": "Repeated: debugging code before checking inputs (the report read an old folder), and trusting output "
              "from an older run (the trading-days file). Focus tomorrow: PG40 Day 1, exercises 1 to 5.",
}

ENTRIES3 = [
    {
        "id": "20261031-01", "tool": "Excel", "type": "Error",
        "title": "FILTER rejected: 'BILL' in single quotes",
        "tags": "quotes, FILTER, UNIQUE",
        "problem": "`=unique(FILTER('31 oct 2026'!C:C,'31 oct 2026'!E:E='BILL'))` wouldn't work.",
        "cause": "Excel uses single quotes only around sheet names. Text values need double quotes.",
        "code_lang": "excel",
        "code": r'''=UNIQUE(FILTER('31 oct 2026'!C:C, '31 oct 2026'!E:E="BILL", "No matches"))''',
        "why": [
            "`'31 oct 2026'!` = a sheet name with spaces; `\"BILL\"` = text.",
            "`\"No matches\"` replaces the `#CALC!` error when nothing matches.",
            "The match ignores capitals but not trailing spaces.",
        ],
        "lesson": "Single quotes for sheet names, double quotes for text.",
    },
    {
        "id": "20261031-02", "tool": "pandas", "type": "How-to",
        "title": "Organised, faster Stringee CDR combine script",
        "tags": "pathlib, calamine, xlsxwriter, # %% cells",
        "problem": "The daily script used `os.chdir`, unused imports, a `> 2` file check and slow Excel engines.",
        "cause": "`> 2` let 0 or 1 file through and then failed on `xlsx_files[1]`; Excel lock files counted as inputs.",
        "code_lang": "python",
        "code": r'''files = sorted(f for f in INPUT_DIR.glob("*.xlsx") if not f.name.startswith("~$"))
if len(files) != 2:
    raise ValueError(f"Expected exactly 2 .xlsx files, found {len(files)}: {[f.name for f in files]}")

def read_xlsx(path):
    try:
        return pd.read_excel(path, engine="calamine")     # pip install python-calamine
    except ImportError:
        return pd.read_excel(path)''',
        "why": [
            "`Path` objects carry the full folder, so `os.chdir` isn't needed.",
            "`calamine` reads and `xlsxwriter` writes much faster; the helper falls back if missing.",
            "`format=\"ISO8601\"` reads times with or without fractions of a second.",
            "`# %%` cells in a `.py` file convert to `.ipynb` with VS Code or `jupytext --to notebook`.",
        ],
        "lesson": "Make a file-count check list the files it found; it turns a crash into an answer.",
    },
    {
        "id": "20261031-03", "tool": "pandas", "type": "How-to",
        "title": "Read IDs as text; convert dates and durations after",
        "tags": "dtype, to_timedelta, [h]:mm:ss",
        "problem": "Stringee files mix real date-times, `00:05:40` durations and 12-digit phone numbers.",
        "cause": "A blank cell turns a phone column into floats (`9.19e+11`), and Excel durations arrive as time-of-day values.",
        "code_lang": "python",
        "code": r'''df = pd.read_excel(path, dtype={"ID": str, "Customer number": str, "Hotline": str})
for c in ["Queue duration", "Answer duration", "Hold duration"]:
    df[c] = pd.to_timedelta(df[c].astype(str).str.strip(), errors="coerce")

# writing back: numbers as day fractions + a duration format
out[c] = out[c].dt.total_seconds() / 86_400
writer.sheets["CDR"].set_column(i, i, 14, writer.book.add_format({"num_format": "[h]:mm:ss"}))''',
        "why": [
            "Only IDs need `dtype` at read time; afterwards the float damage is done.",
            "pandas writes timedeltas as `0.003935`; with `[h]:mm:ss` Excel shows `0:05:40` and `SUM` still works.",
            "Writing numbers first matters: pandas' own timedelta cells carry a `0` format that overrides the column's.",
        ],
        "lesson": "Fix types at the boundary: text IDs on the way in, display formats on the way out.",
    },
    {
        "id": "20261031-04", "tool": "pandas", "type": "Wrong result",
        "title": "Old dialer notebook: Uno start times lost and durations zeroed",
        "tags": "regression test, Uno, timedelta",
        "problem": "In the old notebook every Uno call landed in the `20+` slot, with no gaps, Total_Duration 00:00:00 "
                   "and Login Hours 01:00:00.",
        "cause": "The date was glued to Uno's full date-time (`'2026-10-30 2026-10-30 09:12:00'`, which can't parse), "
                 "and a later step set anything not stored as text to `Timedelta(0)`.",
        "code_lang": "python",
        "code": r'''uno_start = pd.to_datetime(
    uno["Call Date"].dt.strftime("%Y-%m-%d") + " " + uno["Call Time"].astype(str).str.strip().str.upper(),
    format="%Y-%m-%d %I:%M:%S %p", errors="coerce")
uno_calls["Total Call Duration"] = to_td(uno["Call Duration"])     # handles text and timedeltas''',
        "why": [
            "Found by running a faithful copy of the old notebook beside the new script on the same test days.",
            "Stringee results matched cell for cell; only Uno rows differed, which pointed straight at the bugs.",
            "A third bug: `int(mins * 60)` cut 1 second from about 2% of hourly talk times (100 s became 99 s).",
        ],
        "lesson": "Before replacing a report, run old and new on the same data and explain every difference.",
    },
    {
        "id": "20261031-05", "tool": "pandas", "type": "How-to",
        "title": "Call gaps with groupby().shift() instead of a loop",
        "tags": "groupby, shift, vectorise",
        "problem": "The gap calculation looped row by row with `.loc`, the slowest part of the notebook.",
        "cause": "Each call needs the previous call's start and duration for the same CRE and day.",
        "code_lang": "python",
        "code": r'''dialers = dialers.sort_values(["Date", "CRM ID", "Call Start Time"], kind="mergesort").reset_index(drop=True)
g = dialers.groupby(["Date", "CRM ID"], sort=False)
prev_start = g["Call Start Time"].shift()
prev_end = prev_start + g["Total Call Duration"].shift()
gap = (dialers["Call Start Time"] - prev_end).clip(lower=pd.Timedelta(0))''',
        "why": [
            "`shift()` moves values down one row inside each group, so the first call of a day gets nothing.",
            "Sorting first is essential; `mergesort` keeps ties in a fixed order.",
            "Summary sums use pre-computed columns (`talk_s.where(conn, 0)`) instead of per-group lambdas.",
            "Test day of 8,162 calls: 7.9 s before, 2.1 s after (0.6 s without saving raw copies).",
        ],
        "lesson": "\"Previous row in the same group\" is a groupby shift, not a loop.",
    },
    {
        "id": "20261031-06", "tool": "pandas", "type": "Error",
        "title": "Grouper for 'Date' not 1-dimensional",
        "tags": "pivot_table, keys",
        "problem": "After adding `\"Date\"` to the hourly pivot keys, the Calls pivot failed.",
        "cause": "That pivot counted `values=\"Date\"`, so `Date` was both a group key and the value counted.",
        "code_lang": "python",
        "code": r'''keys = ["Date", "CRM ID", "Employee code", "Full Name", "Pool", "TL"]
calls = dialers.pivot_table(index=keys, columns="Interval", values="Call Status",
                            aggfunc="count", fill_value=0)''',
        "why": [
            "Count any column that is never blank; `Call Status` always has a value.",
            "The same report then merges Login Hours on `[\"CRM ID\", \"Date\"]` so days don't repeat rows.",
        ],
        "lesson": "A column can be a key or a value in one pivot, not both.",
    },
    {
        "id": "20261031-07", "tool": "pandas", "type": "How-to",
        "title": "Multi-day reports with checks that fail loudly",
        "tags": "concat, drop_duplicates, consistency check",
        "problem": "The report needed to cover any number of days from several exports, some overlapping.",
        "cause": "The old version accepted exactly 2 Stringee files and 1 Uno file and assumed a single day.",
        "code_lang": "python",
        "code": r'''uno = pd.concat([pd.read_csv(f, dtype=uno_text) for f in uno_files], ignore_index=True)
uno = uno.drop_duplicates(subset="Call Id")

check = hourly[on + ["Total Calls"]].merge(summary[on + ["Total_Dialed_Calls"]], on=on, how="left")
print("Hourly totals match the summary:", (check["Total Calls"] == check["Total_Dialed_Calls"]).all())
print("Calls per day:", dialers.groupby(dialers["Date"].dt.strftime("%Y-%m-%d")).size().to_dict())''',
        "why": [
            "3-day test: each day matched a single-day run; 50 overlapping Uno rows removed.",
            "Two reports from the same calls must agree; a mismatch means a join or filter went wrong.",
            "File names show the range: `Summary_2026-10-28_to_2026-10-30.csv`.",
        ],
        "lesson": "Print counts per day and cross-check totals before anyone opens the file.",
    },
    {
        "id": "20261031-08", "tool": "pandas", "type": "Wrong result",
        "title": "Report showed only the latest date: wrong input folder",
        "tags": "inputs, folders, debugging order",
        "problem": "The summary only had 28 Oct, although an export from 1 Oct existed.",
        "cause": "`STRINGEE_DIR` pointed to `Documents\\Dialer\\st_daily`, holding only the 28th. The full export "
                 "was in `Videos\\Office\\Dialer\\CDR\\Stringee`.",
        "code_lang": "python",
        "code": r'''for f, p in zip(st_files, st_parts):
    t = pd.to_datetime(p["Start time"], format="%m/%d/%Y %I:%M:%S %p", errors="coerce")
    print(f"{f.parent.name}/{f.name}: {len(p):,} rows | {t.min()} -> {t.max()}")''',
        "why": [
            "11 rounds were spent on date parsing and header theories; tests ruled both out.",
            "The file list printed on every run (`20261029_052117.xlsx` ...) held the clue from the start.",
            "Printing the folder name beside each file shows a wrong folder at a glance.",
        ],
        "lesson": "Check which files are read, from which folder, and their date ranges before touching the code.",
    },
    {
        "id": "20261031-09", "tool": "pandas", "type": "How-to",
        "title": "Parse 10/28/2026 09:34:25 PM safely",
        "tags": "to_datetime, format, month-first",
        "problem": "Stringee shows start times as `10/28/2026 09:34:25 PM`.",
        "cause": "A guessing parser can swap day and month: in testing it read `11/03/2026` as 11 March.",
        "code_lang": "python",
        "code": r'''st_raw["Start time"] = pd.to_datetime(st_raw["Start time"], format="%m/%d/%Y %I:%M:%S %p", errors="coerce")
unread = st_raw["Start time"].isna().sum()
if unread:
    raise ValueError(f"{unread} Stringee start times could not be read")''',
        "why": [
            "`%m/%d/%Y` = month first; `%I` + `%p` = 12-hour clock with AM/PM.",
            "Real Excel dates that only display this way pass through unchanged.",
            "`errors=\"coerce\"` + the `unread` check stops the run instead of dropping rows silently.",
        ],
        "lesson": "Give date formats explicitly and make failures stop the run.",
    },
    {
        "id": "20261031-10", "tool": "pandas", "type": "How-to",
        "title": "Use the newest team list in a folder",
        "tags": "pathlib, st_mtime",
        "problem": "The team list file name changes with every download.",
        "cause": "A hard-coded file name breaks as soon as a new export arrives.",
        "code_lang": "python",
        "code": r'''team_files = sorted(f for f in TEAM_DIR.iterdir()
                    if f.suffix.lower() in (".csv", ".xlsx") and not f.name.startswith("~$"))
team_file = max(team_files, key=lambda f: f.stat().st_mtime)
ref = (pd.read_csv(team_file, dtype={"Dialer Name": str}) if team_file.suffix.lower() == ".csv"
       else read_xlsx(team_file, dtype={"Dialer Name": str}))''',
        "why": [
            "`st_mtime` = last-modified time; `max` picks the newest.",
            "Only one list is used: combining old and new lists would duplicate CRM IDs.",
            "Same day: `EXCLUDE_STRINGEE_END_CODES = []` keeps CAN_NOT_MAKE_CALL as dialed, not connected.",
        ],
        "lesson": "Point settings at folders, then pick the file by rule and print which one was used.",
    },
    {
        "id": "20261031-11", "tool": "Python", "type": "Error",
        "title": "KeyError on os.environ: token used as the variable name",
        "tags": "environment variables, setx, secrets",
        "problem": "`TOKEN = os.environ[\"<the token>\"]` raised `KeyError`.",
        "cause": "`os.environ[...]` looks a variable up by NAME. The token's value was passed, and no variable has that name.",
        "code_lang": "python",
        "code": r'''# once, in a terminal, then fully restart VS Code:
#   setx UNO_API_TOKEN "your-token"
TOKEN = os.environ["UNO_API_TOKEN"]
print("UNO_API_TOKEN" in os.environ)      # True''',
        "why": [
            "Programs read environment variables only when they start, so restart the editor after `setx`.",
            "A token pasted into chat is exposed: regenerate it and run `setx` again.",
            "The API endpoint is still to come from the Uno panel; Uno looks like DeepCall (unconfirmed).",
        ],
        "lesson": "Secrets live in environment variables, read by name; never in notebooks or chats.",
    },
    {
        "id": "20261031-12", "tool": "pandas", "type": "Wrong result",
        "title": "Over 31 trading days in a month",
        "tags": "nunique, normalize, assert",
        "problem": "The client report showed 155, 229 and 446 \"days\" in single months.",
        "cause": "It still counted BILL rows. The file came from the old pivot: no `Total Trading Days` column existed.",
        "code_lang": "python",
        "code": r'''bill_led["Trade Date"] = bill_led["CreatedAt"].dt.normalize()
pivot = bill_led.pivot_table(index="ClientID", columns="Month", values="Trade Date",
                             aggfunc="nunique", fill_value=0)
assert pivot.max().max() <= 31, "Still counting bills, not days"''',
        "why": [
            "`.dt.normalize()` drops the time; `nunique` counts distinct dates.",
            "The `assert` stops an impossible result before it reaches Excel.",
            "Close the Excel file before exporting, or the old version stays on disk.",
        ],
        "lesson": "Add a check for the impossible (more than 31 days) so wrong logic can't ship quietly.",
    },
]

PATTERNS = [
    ("Check the inputs before the code",
     "20261030-02, 20261031-08",
     "Print which files are read, from which folder, with row counts and date ranges, before changing any logic."),
    ("Repeated rows mean a one-to-many join or duplicate keys",
     "20261029-11, 20261029-12, 20261030-21",
     "Collapse the many side to one row per key first. Check COUNT(*) = COUNT(DISTINCT key), "
     "validate='many_to_one', or duplicated(subset=key)."),
    ("Check what is really stored before filtering",
     "20261029-05, 20261029-08, 20261029-09, 20261030-03, 20261030-07",
     "Look at real values and column names: df.columns, SELECT ... LIMIT 1, COUNTIF with wildcards."),
    ("Duplicate or double-used names break things",
     "20261029-02, 20261030-19, 20261031-06",
     "Two columns with one name, or one column as both pivot key and value. Check names after every rename."),
    ("Never reuse built-in or existing names; names are not values",
     "20261029-01, 20261030-07, 20261030-12, 20261031-11",
     "min, max, all are functions; give each table its own name; os.environ takes a variable's name, not its value."),
    ("Assign results back, and sort by the right column",
     "20261030-01, 20261030-09",
     "sort_values returns a copy: write led = led.sort_values(...). For 'latest per key', sort by the date."),
    ("Calculate in one step, filter in the next",
     "20261029-06",
     "Window functions run after WHERE. Put them in a CTE and filter in the following SELECT."),
    ("Verify against raw rows or an old version",
     "20261029-06, 20261029-07, 20261029-13, 20261030-02, 20261031-04",
     "Compare counts with raw data, and run old and new code on the same input before switching."),
    ("Build checks that fail loudly",
     "20261031-07, 20261031-09, 20261031-12",
     "assert impossible values, raise on unreadable dates, and cross-check two reports built from the same rows."),
    ("Load only what you need",
     "20261030-14, 20261030-15, 20261030-16, 20261030-18",
     "Estimate rows x columns x 8 bytes. Select columns and filter rows before collecting; sink big outputs to disk."),
    ("Text that looks like a date or number isn't one",
     "20261029-04, 20261029-12, 20261030-13, 20261030-20, 20261031-03, 20261031-09",
     "Read IDs as text; give date formats explicitly; convert with to_datetime / to_timedelta / Int64."),
    ("Excel changes data when it saves",
     "20261030-02, 20261030-05, 20261030-21",
     "Never save a CSV from Excel. Long IDs become 2.61029E+17 and times become 59:48.4 for good."),
    ("Trust only output from a fresh run",
     "20261030-07, 20261030-16, 20261031-12",
     "Restart and Run All before trusting a number; close output files in Excel before writing them."),
]
