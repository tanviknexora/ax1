DAY8 = {
    "date": "Wednesday, 11 November 2026",
    "focus": "The Thailand Plan for management (its rules against the spreadsheet), JSON text in Excel, and the "
             "lead-source report: all-time deposits, conversions by event date, source labels, October and "
             "November side by side, and the export.",
    "outcome": "15 entries: 3 errors, 6 wrong results and 6 how-tos. The Thailand Plan is drafted with seven decisions "
               "for management; the lead report runs for any month and exports a sheet per month. Evening: Day 1 of "
               "the notes on using an LLM through its API (card 15).",
    "review": "Repeated: definitions that differed without anyone noticing (demo children, 30-day vs month, source "
              "labels, which date a column counts by) and a check that compared unlike row sets. Open: the SLNo. "
              "check on the 113,534 repeated ledger rows, and management's answers on the Thailand decisions.",
}

ENTRIES8 = [
    {
        "id": "20261111-01", "tool": "Excel", "type": "How-to",
        "title": "LET: work a value out once, show a message when it's below 6",
        "tags": "LET, IF, text joining",
        "problem": "=MAX(INT(D2/2),INT(J2+(J2*0.1))) had to print 'Currently ineligible: add N more clients to "
                   "qualify' whenever the result was below 6.",
        "cause": "Without LET the MAX(...) has to be written three times (test, message, result), and the copies "
                 "drift apart when one is edited.",
        "code": r'''=LET(v, MAX(INT(D2/2), INT(J2*1.1)),
     need, 6 - v,
     IF(v < 6,
        "Currently ineligible: add " & need & IF(need = 1, " more client", " more clients") & " to qualify",
        v))''',
        "why": [
            "LET names a value once (v, need) and reuses it, like a variable.",
            "& joins text and numbers into one message.",
            "IF(need = 1, ...) keeps the grammar right for one client.",
        ],
        "lesson": "When a formula repeats a calculation, name it with LET.",
    },
    {
        "id": "20261111-02", "tool": "Excel", "type": "Wrong result",
        "title": "A message in a number column turned the target into #VALUE!",
        "tags": "#VALUE!, mixed column, IFERROR",
        "problem": "In thailand_tripv3, Expected Trade Value =(S2*1.05)*Q2 showed #VALUE! wherever Q held the "
                   "'Currently ineligible' message.",
        "cause": "Q mixed numbers and text. Any formula that multiplies Q fails on the text rows, and SUM skips them "
                 "silently.",
        "code": r'''Q2  Required active:   =MAX(6, INT((D2-E2)/2), ROUNDUP(ROUND(I2*1.1, 6), 0))     (always a number)
R2  Status:            =IF(AND(D2-E2>=6, I2>=6), "Entered", "Not entered: needs " & MAX(0, 6-I2) & " more active")
T2  Trade value target: =IF(I2=0, 0, L2/I2*1.05*Q2)''',
        "why": [
            "One column, one type: numbers that feed other formulas never share a column with messages.",
            "IF(I2=0, 0, ...) also stops a #DIV/0! for brokers with no active clients (624 in October).",
            "ROUND inside ROUNDUP stops 11.000000000000002 rounding up to 12.",
        ],
        "lesson": "Keep the number and the message in separate columns.",
    },
    {
        "id": "20261111-03", "tool": "Excel", "type": "Wrong result",
        "title": "The plan's rules and the spreadsheet's formulas said different things",
        "tags": "rule definitions, INT, demo children",
        "problem": "Drafting the Thailand Plan from thailand_tripv3: the written rules and the formulas disagreed in "
                   "five places.",
        "cause": "Each formula was written on its own: children counted demo accounts, growth used the 30-day count "
                 "not October's, 'Half Clients Active' used Converted / 2, INT dropped growth below 10 active, and "
                 "nothing stopped a requirement below 6.",
        "code": r'''rule as written          sheet as built                        effect (Oct 2026)
50% of children          INT(Children/2), demo included        T66541: 80, not 49
10% activity growth      INT(Active_30days*1.1)                7 x 1.1 = 7.7 -> 7
6 active minimum         requirement can be 4 or 5             3 entrants: #VALUE!
(third base for 50%)     Half Clients Active = Converted/2     3 definitions of 50%''',
        "why": [
            "INT always rounds down, so 10% of anything under 10 becomes 0.",
            "A floor of 6 in the formula makes rule 3 consistent with rule 2.",
            "Cleaning up all four cut the requirement from 421 to 343 active clients and the target from 42.5M "
            "to 31.0M.",
        ],
        "lesson": "Write each rule as one formula with named inputs before building columns from it.",
    },
    {
        "id": "20261111-04", "tool": "Excel", "type": "How-to",
        "title": "Pull Client_Id out of JSON text in a cell",
        "tags": "TEXTAFTER, TEXTBEFORE, REGEXEXTRACT, Flash Fill",
        "problem": "A column held JSON like {\"Client_Name\":...,\"Client_Id\":\"P157544\",...}; only the client ID "
                   "was needed.",
        "cause": "The ID sits between known markers: after \"Client_Id\":\" and before the next quote.",
        "code": r'''=IFERROR(TEXTBEFORE(TEXTAFTER(AZ2, "Client_Id"":"""), """"), "")      Excel 365 / 2021
=IFERROR(REGEXEXTRACT(AZ2, "Client_Id\W+(\w+)", 2), "")                  Excel 365 (2024 updates)
Ctrl+E (Flash Fill) after typing the first ID by hand                     one-off, not live
Power Query: Transform > Parse > JSON                                      every field, monthly''',
        "why": [
            "Inside an Excel string, \"\"\"\" is one quote character: quotes are doubled.",
            "\\W+ skips the punctuation after the key, (\\w+) captures the ID, return mode 2 returns the capture.",
            "Flash Fill guesses a pattern and writes plain values: check a few rows.",
        ],
        "lesson": "Extract between markers, not by counting characters.",
    },
    {
        "id": "20261111-05", "tool": "pandas", "type": "Wrong result",
        "title": "113,534 repeated ledger rows in every month (all-time deposits too high?)",
        "tags": "duplicates, SLNo., ledger overlap",
        "problem": "All-time deposits looked wrong. Checks: 0 clients under 2 leads, IDs all matched, only one "
                   "DEPOSIT type, nobody deposited before their lead, but 113,534 rows repeated on client, time, "
                   "type and amount, spread over every month since Sep 2025.",
        "cause": "Not yet confirmed. A spread like that isn't a single base/append overlap: either an append file "
                 "repeats history, two appends overlap, or the rows are separate real entries that look alike.",
        "code": r'''KEY = ['ClientID', 'CreatedAt', 'LedgerType', 'Debit', 'Credit']
led = get_final_ledger(as_pandas=True, columns=tuple(KEY + ['SLNo.']))
before = len(led)
led = led.drop_duplicates(subset=KEY + ['SLNo.'])        # same values AND same ledger ID = a copy
print("True copies removed:", before - len(led))''',
        "why": [
            "Dropping on the values alone would also delete real trades that close in the same second for the "
            "same amount.",
            "Adding the ledger's own row ID removes only true copies.",
            "Status: open until the SLNo. counts per source (base, appends, across) are read.",
        ],
        "lesson": "Before deleting duplicates, prove they are copies with the record's own ID.",
    },
    {
        "id": "20261111-06", "tool": "pandas", "type": "Wrong result",
        "title": "A check compared two different sets of rows",
        "tags": "diagnostics, like with like",
        "problem": "'converted_at filled - raw: 35,244 | after parsing: 31,192' suggested 4,052 dates lost in "
                   "parsing.",
        "cause": "The raw count was taken on the whole file; the parsed count on df, which had the Old Portal_1YT "
                 "rows removed. The gap may be those rows, not parsing.",
        "code": r'''raw_f = raw[raw['tag'] != 'Old Portal_1YT']              # same filter as df
parsed = pd.to_datetime(raw_f['converted_at'], errors='coerce')
lost = raw_f['converted_at'].notna() & parsed.isna()
print("Same rows - raw:", int(raw_f['converted_at'].notna().sum()), "| parsed:", int(parsed.notna().sum()))
print(raw_f.loc[lost, 'converted_at'].astype(str).head(10))''',
        "why": [
            "A before/after comparison only means something when both sides went through the same filters.",
            "Printing the failing values shows the cause instead of guessing it.",
        ],
        "lesson": "Compare like with like: apply the same filters to both sides of a check.",
    },
    {
        "id": "20261111-07", "tool": "pandas", "type": "How-to",
        "title": "All-time deposits for every client in the leads file",
        "tags": "set of IDs, groupby, map",
        "problem": "Needed all-time deposits for every client in df, not only for the month's leads.",
        "cause": "leads_id came from the filtered October leads, so clients with older leads had no figure.",
        "code": r'''df['zynixx_client_id'] = up(df['zynixx_client_id']).where(df['zynixx_client_id'].notna())
df_ids = set(df['zynixx_client_id'].dropna())                      # every client in the file
leads_led = led[led['ClientID'].isin(df_ids)]
all_dep_by_client = leads_led[leads_led['LedgerType'].eq('DEPOSIT')].groupby('ClientID')['Credit'].sum()
df['All_Time_Deposit'] = df['zynixx_client_id'].map(all_dep_by_client).fillna(0)''',
        "why": [
            ".where(notna) keeps blank IDs blank instead of turning them into the text 'NAN'.",
            "A client with several rows in df carries the full total on each row: deduplicate per client before "
            "summing per source.",
        ],
        "lesson": "Build the ID list from the widest table the question needs, then filter later.",
    },
    {
        "id": "20261111-08", "tool": "pandas", "type": "Wrong result",
        "title": "Filtering leads by lead date missed conversions of earlier leads",
        "tags": "cohort vs activity, event date",
        "problem": "The October report kept only leads created in October, so a September lead that converted or "
                   "deposited in October never counted.",
        "cause": "One filter was answering two questions. New leads count by lead date; conversions, first deposits "
                 "and deposits count by the date they happened, whatever month the lead came in.",
        "code": r'''clients = (df.dropna(subset=['zynixx_client_id'])
             .sort_values(['converted_at', 'lead_date'], na_position='last')      # converted lead first
             .drop_duplicates('zynixx_client_id'))                                 # one source per client

new = df[in_month(df['lead_date'])]                  # view 1: new leads, by lead date
conv = clients[in_month(clients['converted_at'])]    # view 2: events, by their own date
ftd = clients[in_month(clients['ftd_date'])]''',
        "why": [
            "Every client needs one source: the lead that converted, else the earliest.",
            "converted_from_earlier_leads shows exactly what the old filter was missing.",
            "Which lead gets the credit (converting lead or last touch) is a rule to confirm with the team.",
        ],
        "lesson": "Count each column by its own date, and write that date in the report's notes.",
    },
    {
        "id": "20261111-09", "tool": "pandas", "type": "Error",
        "title": "KeyError: 'converted_in_month' not found in columns (astype)",
        "tags": "stale cell, astype",
        "problem": "KeyError: \"Only a column name can be used for the key in a dtype mappings argument. "
                   "'converted_in_month' not found in columns.\"",
        "cause": "The new column was added to the counts list, but the cell that builds activity hadn't been run "
                 "again, so the table in memory was the old one.",
        "code": r'''activity = pd.concat([..., df[in_month(df['converted_at'])].groupby('lead_source_1').size()
                                .rename('converted_in_month'), ...], axis=1)
print(activity.columns.tolist())        # the new name must be in this list
# then: Restart and Run All''',
        "why": [
            "A notebook keeps variables from cells run earlier; editing a cell changes nothing until it runs.",
            "astype({...}) refuses names that aren't columns, so the error names the missing one.",
        ],
        "lesson": "After editing a cell that others depend on, Restart and Run All.",
    },
    {
        "id": "20261111-10", "tool": "pandas", "type": "Wrong result",
        "title": "One source under three labels: Meta-IMR, (META-IMR), Meta 1yt IMR",
        "tags": "labels, replace, value_counts",
        "problem": "The (META-IMR) row showed 0 conversions and 0 FTD but 2,000 all-time deposit, against an "
                   "expected 4 conversions.",
        "cause": "Three spellings (1,587 / 306 / 1 leads) made three rows. The October conversions sat under "
                 "Meta-IMR; the rest were November. FTD 0 with all-time 2,000 was right: that client deposited "
                 "outside October.",
        "code": r'''imr = df[df['lead_source_1'].astype(str).str.contains('IMR', case=False, na=False)]
print(imr['lead_source_1'].value_counts(dropna=False))           # every spelling
df['lead_source_1'] = df['lead_source_1'].replace({'(META-IMR)': 'Meta-IMR', 'Meta 1yt IMR': 'Meta-IMR'})''',
        "why": [
            "groupby treats every spelling as a different group.",
            "A replace dictionary merges only the labels named, so no other source changes.",
            "Of 6 converted IMR leads, 2 converted in October, 3 in November, 1 in September.",
        ],
        "lesson": "Before grouping by a label, list its spellings with value_counts.",
    },
    {
        "id": "20261111-11", "tool": "pandas", "type": "How-to",
        "title": "Mixed date formats: format='ISO8601' instead of errors='coerce'",
        "tags": "to_datetime, ISO8601",
        "problem": "Some converted_at values had milliseconds and some didn't.",
        "cause": "pandas guesses one format from the first value; with errors='coerce', anything that doesn't fit "
                 "becomes blank without a warning.",
        "code": r'''df['lead_date'] = pd.to_datetime(df['lead_date'], format='ISO8601')
df['converted_at'] = pd.to_datetime(df['converted_at'], format='ISO8601')''',
        "why": [
            "ISO8601 reads 2026-10-05 10:00:00 and 2026-10-05 10:00:00.537 alike.",
            "No errors='coerce': a truly broken date raises instead of silently removing a conversion.",
        ],
        "lesson": "Never let errors='coerce' decide silently: count what it blanked, or don't use it.",
    },
    {
        "id": "20261111-12", "tool": "pandas", "type": "How-to",
        "title": "The same report for any month: lead_summary(month)",
        "tags": "function, MonthBegin, pd.concat dict",
        "problem": "Needed November alongside October with identical rules.",
        "cause": "Everything that depends on the month moved into one function; facts that don't (first deposit, "
                 "traded, all-time) are worked out once outside it.",
        "code": r'''MONTHS = ['2026-10', '2026-11']

def lead_summary(month):
    start = pd.Timestamp(month)
    end = start + pd.offsets.MonthBegin(1)
    in_month = lambda s: (s >= start) & (s < end)
    ...                                              # month_deposit, trade_volume, views 1 and 2
    return out

summaries = {m: lead_summary(m) for m in MONTHS}
combined = pd.concat(summaries, names=['month']).reset_index(level=0)''',
        "why": [
            "Column names became month-neutral (month_deposit), since they hold any month's figures.",
            "pd.concat on a dict uses the keys as a new 'month' column.",
            "A print line per month checks deposits against the ledger.",
        ],
        "lesson": "When a report repeats per period, make the period a parameter.",
    },
    {
        "id": "20261111-13", "tool": "Python", "type": "Error",
        "title": "PermissionError: [Errno 13] Permission denied writing the Excel file",
        "tags": "PermissionError, open file, try/except",
        "problem": "PermissionError: [Errno 13] Permission denied: "
                   "'C:\\Users\\Administrator\\Downloads\\Lead_Source_Summary_2026-10.xlsx'",
        "cause": "The file from an earlier run was open in Excel, and Windows locks open files.",
        "code": r'''try:
    export_lead_summary(s, path, pd.Timestamp(month), ledger_up_to=as_of)
except PermissionError:                                    # the file is open in Excel
    path = rf"{folder}\Lead_Source_Summary_{month}_{pd.Timestamp.now():%H%M%S}.xlsx"
    export_lead_summary(s, path, pd.Timestamp(month), ledger_up_to=as_of)''',
        "why": [
            "Close the file (check minimised Excel windows) and run again; or save a timed copy automatically.",
            "Catching only PermissionError keeps every other error visible.",
        ],
        "lesson": "Close output files in Excel before a run writes them.",
    },
    {
        "id": "20261111-14", "tool": "Python", "type": "How-to",
        "title": "Export: one column list drives the bands, month-to-date title, a sheet per month",
        "tags": "openpyxl, COLUMNS spec, ExcelWriter",
        "problem": "The export module had to take the new columns, any month, and several months in one file.",
        "cause": "Bands, widths and formats were positional; adding a column meant editing several places.",
        "code": r'''COLUMNS = [("lead_source_1", "Lead Source", "text", ""),
           ("converted_in_month", "Converted", "int", "CONVERSIONS"),
           ("month_deposit", "{mon} Deposit", "money", "DEPOSITS"), ...]   # (column, header, kind, band)

export_lead_summaries(summaries, path, ledger_up_to=as_of)   # sheets 'Oct 2026', 'Nov 2026'
# title adds "(month to date)" when the ledger ends before the month does''',
        "why": [
            "Bands are worked out from runs of the same band name, widths from the kind.",
            "A column missing from a summary is skipped instead of crashing.",
            "Recalculated: zero formula errors; every total matched pandas in both sheets.",
        ],
        "lesson": "Describe a layout as data (one list), and let the code draw it.",
    },
]

ENTRIES8 += [
    {
        "id": "20261111-15", "tool": "Python", "type": "Error",
        "title": "TypeError: unexpected keyword argument 'temperature' (code from an older tutorial)",
        "tags": "anthropic package, temperature, prefill",
        "problem": "Older tutorials call client.messages.create(..., temperature=0.2). With the anthropic package "
                   "(version 2.8.0) the call fails before anything is sent.",
        "cause": "Current Claude models don't accept sampling settings such as temperature (the API returns a 400 "
                 "error), and the current Python package no longer takes the argument. Prefilling the start of the "
                 "answer is refused on current models too.",
        "code": r'''client.messages.create(model=MODEL, max_tokens=10, temperature=0.2, messages=[...])
# TypeError: Messages.create() got an unexpected keyword argument 'temperature'

# steer with instructions instead
SYSTEM = "Reply with exactly one of: Interested, Not interested, Callback."''',
        "why": [
            "Checked against the official Messages API documentation and the installed package.",
            "Instructions in the prompt control length and format more clearly anyway.",
            "When a tutorial's code fails, check its date before debugging your own code.",
        ],
        "lesson": "Check a tutorial's date before trusting its arguments.",
    },
]

# ---- Patterns: carried from 10 November, extended with today's cards ----------------------------
from entries_10 import PATTERNS as _PREVIOUS

_ADD = {
    "Agree the output before building": ["20261111-03", "20261111-08"],
    "Check what is really stored before filtering": ["20261111-05", "20261111-10"],
    "Repeated rows mean a one-to-many join or duplicate keys": ["20261111-05"],
    "Verify against raw rows or an old version": ["20261111-06"],
    "Text that looks like a date or number isn't one": ["20261111-02", "20261111-11"],
    "Trust only output from a fresh run": ["20261111-09", "20261111-13"],
    "Try the edge cases of every business rule": ["20261111-03"],
    "Name each setting and window once": ["20261111-12"],
    "One label per row when groups must add up": ["20261111-08"],
    "Duplicate or double-used names break things": ["20261111-10"],
}
PATTERNS = []
for name, seen, what in _PREVIOUS:
    PATTERNS.append((name, seen + "".join(", " + i for i in _ADD.get(name, [])), what))

PATTERNS.insert(8, ("Every number counts by one stated date",
                    "20261110-10, 20261111-08, 20261111-10",
                    "Lead date, event date, rolling 30 days: name the date each column counts by, keep views apart, "
                    "and print the window in every run and in the report's notes."))
