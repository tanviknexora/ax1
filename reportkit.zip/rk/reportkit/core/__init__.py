"""Shared building blocks: written once, used by every report."""
