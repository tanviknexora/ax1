"""The algorithms behind several reports, kept separate so each can be tested alone.

Concepts: a min-heap for fair sharing (greedy), binary search for bands, and breadth-
first search for referral trees.
"""

from __future__ import annotations

import heapq
from collections import deque
from collections.abc import Hashable, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd


def assign_least_loaded(load: Mapping[str, int], items: Iterable[Hashable]) -> dict:
    """Give each item to whoever has the fewest so far (greedy, with a min-heap).

    Ties go to the alphabetically first owner, so the result is the same on every run.
    """
    heap = [(count, owner) for owner, count in load.items()]
    heapq.heapify(heap)
    assigned = {}
    for item in items:
        count, owner = heapq.heappop(heap)
        assigned[item] = owner
        heapq.heappush(heap, (count + 1, owner))
    return assigned


def band_labels(
    values: pd.Series, edges: Sequence[float], labels: Sequence[str]
) -> pd.Series:
    """Label each number with its band, by binary search over the band edges.

    edges [2, 4] and labels ['0-1', '2-3', '4+'] put 3 in '2-3'. Blanks stay blank.
    """
    if len(labels) != len(edges) + 1:
        raise ValueError("there must be one more label than edges")
    known = values.notna().to_numpy()
    out = np.full(len(values), None, dtype=object)
    position = np.searchsorted(
        edges, values[known].to_numpy(dtype="float64"), side="right"
    )
    out[known] = np.asarray(labels, dtype=object)[position]
    return pd.Series(
        pd.Categorical(out, categories=list(labels), ordered=True), index=values.index
    )


def bfs_levels(children: Mapping[str, Sequence[str]], root: str) -> dict[str, int]:
    """Level of everyone below root: direct children are level 1. Loops are ignored."""
    level = {root: 0}
    queue = deque([root])
    while queue:
        node = queue.popleft()
        for child in children.get(node, ()):
            if child not in level:
                level[child] = level[node] + 1
                queue.append(child)
    del level[root]
    return level
