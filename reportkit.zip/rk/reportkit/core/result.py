"""What every run produces, and the checks that keep reports honest."""

from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from reportkit.settings import TOTAL


@dataclass
class Report:
    """One report's results: named tables (the first is the summary) and its checks."""

    name: str
    title: str
    tables: dict[str, pd.DataFrame]
    checks: dict[str, object] = field(default_factory=dict)

    @property
    def summary(self) -> pd.DataFrame:
        return next(iter(self.tables.values()))


def reconcile(label: str, got: float, expected: float, tolerance: float = 1e-6) -> None:
    """Stop the run when two numbers that must match don't: the report is wrong."""
    if abs(float(got) - float(expected)) > tolerance:
        raise ValueError(f"{label}: got {got:,}, expected {expected:,}")


def unknown_values(values: pd.Series, known: set | frozenset) -> dict[str, int]:
    """Values no rule covers, with counts: list them, never drop them silently."""
    unknown = values[~values.isin(known)]
    return {str(k): int(v) for k, v in unknown.value_counts(dropna=False).items()}


def with_total(table: pd.DataFrame, label_col: str) -> pd.DataFrame:
    """The table with a Total row that sums every number column.

    Each column keeps its own type, so whole-number counts don't turn into decimals.
    """
    numbers = table.select_dtypes("number").columns
    total_row = pd.DataFrame(
        [{label_col: TOTAL, **{c: table[c].sum() for c in numbers}}]
    )
    out = pd.concat([table, total_row], ignore_index=True)
    return out.astype({c: table[c].dtype for c in numbers})
