"""Dates and time zones: one calendar for every report.

Concept: compare times only after both sides are in the same zone, and count calendar
days (normalize) rather than 24-hour blocks.
"""

from __future__ import annotations

import pandas as pd

from reportkit.settings import DATA_TZ, REPORT_TZ


def to_report_time(values: pd.Series) -> pd.Series:
    """Any date column -> time-zone-aware REPORT_TZ times. Unreadable: blank."""
    if pd.api.types.is_datetime64_any_dtype(values):
        parsed = values
    else:
        parsed = pd.to_datetime(values, format="ISO8601", errors="coerce", utc=False)
    if parsed.dt.tz is None:
        parsed = parsed.dt.tz_localize(DATA_TZ)
    return parsed.dt.tz_convert(REPORT_TZ)


def report_timestamp(value: str | pd.Timestamp | None = None) -> pd.Timestamp:
    """A moment in REPORT_TZ: now by default, or the given date or time."""
    if value is None:
        return pd.Timestamp.now(tz=REPORT_TZ)
    stamp = pd.Timestamp(value)
    return (
        stamp.tz_localize(REPORT_TZ)
        if stamp.tzinfo is None
        else stamp.tz_convert(REPORT_TZ)
    )


def days_since(dates: pd.Series, as_of: pd.Timestamp) -> pd.Series:
    """Whole calendar days from each date to as_of, in REPORT_TZ. Blank stays blank."""
    local = to_report_time(dates)
    today = report_timestamp(as_of).normalize()
    return (today - local.dt.normalize()).dt.days.astype("Int64")


def month_bounds(month: str | pd.Period) -> tuple[pd.Timestamp, pd.Timestamp]:
    """Start (included) and end (excluded) of a calendar month in REPORT_TZ."""
    period = pd.Period(month, freq="M")
    start = report_timestamp(period.start_time)
    return start, report_timestamp((period + 1).start_time)


def in_window(dates: pd.Series, start: pd.Timestamp, end: pd.Timestamp) -> pd.Series:
    """True where start <= date < end. Blank dates are never in the window."""
    return ((dates >= start) & (dates < end)).fillna(False).astype(bool)
