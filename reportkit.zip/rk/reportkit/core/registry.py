"""The list of reports: each report module registers itself here.

Concept: a registry decouples "what reports exist" from "how to run one" (the same idea
as nexora_reports' core/reports.py, where each Django app registers on the home page).
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field

import pandas as pd

from reportkit.core.dates import month_bounds, report_timestamp
from reportkit.core.result import Report


@dataclass(frozen=True)
class InputSpec:
    """One input file's contract: where to find it, which columns it must have."""

    pattern: str  # file name pattern; the newest match is used
    columns: dict[str, str]  # column in the file -> name used in the code
    dates: tuple[str, ...] = ()  # code names to read as dates (into REPORT_TZ)


@dataclass(frozen=True)
class RunContext:
    """Values chosen for one run: never settings, so a past month can be re-run."""

    as_of: pd.Timestamp = field(default_factory=report_timestamp)
    month: pd.Period | None = None

    @property
    def window(self) -> tuple[pd.Timestamp, pd.Timestamp]:
        if self.month is None:
            raise ValueError("this report needs a month (--month YYYY-MM)")
        return month_bounds(self.month)


@dataclass(frozen=True)
class ReportSpec:
    """Everything the runner needs to know about one report."""

    name: str
    title: str
    inputs: dict[str, InputSpec]
    build: Callable[[dict[str, pd.DataFrame], RunContext], Report]
    monthly: bool = False


_REPORTS: dict[str, ReportSpec] = {}


def register(spec: ReportSpec) -> ReportSpec:
    """Add a report. Two reports can't share a name."""
    if spec.name in _REPORTS:
        raise ValueError(f"a report called {spec.name!r} is already registered")
    _REPORTS[spec.name] = spec
    return spec


def get_report(name: str) -> ReportSpec:
    """The report called name, or an error listing the real names."""
    try:
        return _REPORTS[name]
    except KeyError:
        raise KeyError(
            f"no report {name!r}; choose from: {', '.join(sorted(_REPORTS))}"
        ) from None


def all_reports() -> list[ReportSpec]:
    return [_REPORTS[name] for name in sorted(_REPORTS)]
