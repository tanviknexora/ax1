"""Reading inputs against their contracts, and writing reports to Excel."""

from __future__ import annotations

import csv
import importlib.util
from pathlib import Path

import pandas as pd
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

from reportkit.core.dates import to_report_time
from reportkit.core.registry import InputSpec
from reportkit.core.result import Report
from reportkit.settings import (
    COUNT_FORMAT,
    DATE_FORMAT,
    HEADER_FILL,
    MONEY_FORMAT,
    REPORT_TZ,
    TOTAL,
)

# Why: pyarrow reads CSV files several times faster; fall back if it isn't installed.
CSV_ENGINE = "pyarrow" if importlib.util.find_spec("pyarrow") else "c"
MONEY_WORDS = ("debit", "credit", "deposit", "value", "amount", "target", "net")


def latest_file(folder: Path, pattern: str) -> Path:
    """The most recently saved file matching pattern: no '(19)' written into code."""
    files = list(Path(folder).glob(pattern))
    if not files:
        raise FileNotFoundError(f"no file matching {pattern!r} in {folder}")
    return max(files, key=lambda f: f.stat().st_mtime)


def read_input(path: Path, spec: InputSpec) -> pd.DataFrame:
    """Only the contracted columns, renamed, with dates in REPORT_TZ."""
    with open(path, newline="", encoding="utf-8-sig") as f:
        header = next(csv.reader(f))
    missing = [col for col in spec.columns if col not in header]
    if missing:
        raise ValueError(f"{Path(path).name} is missing columns: {missing}")
    df = pd.read_csv(path, usecols=list(spec.columns), engine=CSV_ENGINE)
    df = df.rename(columns=spec.columns)
    return df.assign(**{col: to_report_time(df[col]) for col in spec.dates})


def excel_ready(table: pd.DataFrame) -> pd.DataFrame:
    """Excel can't store time zones: show times as IST wall-clock times."""
    out = table.copy()
    for col in out.columns:
        if isinstance(out[col].dtype, pd.DatetimeTZDtype):
            out[col] = out[col].dt.tz_convert(REPORT_TZ).dt.tz_localize(None)
    return out


def _number_format(column: str, series: pd.Series) -> str | None:
    if pd.api.types.is_datetime64_any_dtype(series):
        return DATE_FORMAT
    if pd.api.types.is_float_dtype(series) or any(
        w in column.lower() for w in MONEY_WORDS
    ):
        return MONEY_FORMAT if pd.api.types.is_numeric_dtype(series) else None
    if pd.api.types.is_integer_dtype(series):
        return COUNT_FORMAT
    return None


def write_workbook(report: Report, path: Path) -> Path:
    """One sheet per table (summary first), then a Checks sheet. Total rows in bold."""
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        for name, table in report.tables.items():
            sheet = excel_ready(table)
            sheet.to_excel(writer, sheet_name=name[:31], index=False)
            _style(writer.sheets[name[:31]], sheet)
        checks = pd.DataFrame(
            {
                "Check": list(report.checks),
                "Value": [str(v) for v in report.checks.values()],
            }
        )
        checks.to_excel(writer, sheet_name="Checks", index=False)
        _style(writer.sheets["Checks"], checks)
    return path


def _style(ws, table: pd.DataFrame) -> None:
    fill = PatternFill("solid", fgColor=HEADER_FILL)
    for j, col in enumerate(table.columns, start=1):
        ws.cell(1, j).font, ws.cell(1, j).fill = Font(bold=True), fill
        sample = table[col].head(200).astype(str)
        width = max([len(str(col))] + sample.str.len().tolist())
        ws.column_dimensions[get_column_letter(j)].width = min(width + 2, 60)
        fmt = _number_format(str(col), table[col])
        if fmt:
            for r in range(2, len(table) + 2):
                ws.cell(r, j).number_format = fmt
    first = table.columns[0] if len(table.columns) else None
    if first is not None:
        for r, value in enumerate(table[first].astype(str), start=2):
            if value == TOTAL:
                for j in range(1, len(table.columns) + 1):
                    ws.cell(r, j).font = Font(bold=True)
    ws.freeze_panes = "A2"
