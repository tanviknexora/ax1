"""Cleaning text and IDs the same way everywhere, so the same client always matches."""

from __future__ import annotations

import pandas as pd


def clean_ids(ids: pd.Series) -> pd.Series:
    """IDs trimmed and upper-cased: ' s217514' and 'S217514' become the same key."""
    return ids.astype("string").str.strip().str.upper()


def clean_text(values: pd.Series) -> pd.Series:
    """Text with the spaces trimmed: 'Active ' becomes 'Active'. Blanks stay blank."""
    return values.astype("string").str.strip()


def text_key(values: pd.Series) -> pd.Series:
    """Lower-case letters and digits only: 'Ringing / Busy' and 'Ringing/Busy' match."""
    return values.astype("string").str.lower().str.replace(r"[^a-z0-9]", "", regex=True)


def is_true(values: pd.Series, true_words: frozenset[str]) -> pd.Series:
    """'TRUE', 'yes', '1' -> True; anything else, or blank, is False."""
    return (
        values.astype("string").str.strip().str.lower().isin(true_words).fillna(False)
    )
