"""Running a report: find files, load, build, save; every stage timed."""

from __future__ import annotations

import logging
import time
from pathlib import Path

import pandas as pd

from reportkit.core.io import latest_file, read_input, write_workbook
from reportkit.core.registry import ReportSpec, RunContext
from reportkit.core.result import Report
from reportkit.settings import OUTPUT_NAME

log = logging.getLogger(__name__)


def find_inputs(
    spec: ReportSpec, data_dir: Path, overrides: dict[str, Path]
) -> dict[str, Path]:
    """A path for every input: an override if given, else the newest matching file."""
    unknown = set(overrides) - set(spec.inputs)
    if unknown:
        raise ValueError(
            f"{spec.name} has no input called {sorted(unknown)}; "
            f"its inputs are {sorted(spec.inputs)}"
        )
    return {
        name: Path(overrides[name])
        if name in overrides
        else latest_file(data_dir, input_spec.pattern)
        for name, input_spec in spec.inputs.items()
    }


def run_report(
    spec: ReportSpec,
    context: RunContext,
    data_dir: Path,
    out_dir: Path,
    overrides: dict[str, Path] | None = None,
) -> tuple[Report, Path]:
    """Load, build and save one report. Returns the report and where it was saved."""
    if spec.monthly and context.month is None:
        raise ValueError(f"{spec.name} is a monthly report: give --month YYYY-MM")
    timings = {}
    t0 = time.perf_counter()
    paths = find_inputs(spec, Path(data_dir), overrides or {})
    data = {name: read_input(path, spec.inputs[name]) for name, path in paths.items()}
    timings["load_ms"] = round((time.perf_counter() - t0) * 1000)

    t0 = time.perf_counter()
    report = spec.build(data, context)
    timings["build_ms"] = round((time.perf_counter() - t0) * 1000)

    # Recorded before saving, so the workbook's Checks sheet shows them too.
    report.checks.update({f"input: {k}": v.name for k, v in paths.items()} | timings)

    stamp = str(context.month) if spec.monthly else f"{context.as_of:%Y-%m-%d}"
    out_dir.mkdir(parents=True, exist_ok=True)
    t0 = time.perf_counter()
    path = write_workbook(
        report, out_dir / OUTPUT_NAME.format(report=spec.name, stamp=stamp)
    )
    timings["save_ms"] = round((time.perf_counter() - t0) * 1000)
    log.info("%s: %s | %s", spec.name, path.name, timings)
    return report, path


def parse_month(value: str | None) -> pd.Period | None:
    return None if value is None else pd.Period(value, freq="M")
