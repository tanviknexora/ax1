"""The command line: list the reports, run one, or try everything on demo data.

python -m reportkit list python -m reportkit run call_list --data-dir
C:/Users/Administrator/Downloads python -m reportkit run usd_clients --month 2026-10
--input ledger=C:/data/ledger.csv python -m reportkit demo --out reportkit_demo
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import reportkit.reports  # noqa: F401  (registers every report)
from reportkit.core.dates import report_timestamp
from reportkit.core.registry import RunContext, all_reports, get_report
from reportkit.core.runner import parse_month, run_report
from reportkit.demo import AS_OF, write_demo_data
from reportkit.settings import DEFAULT_DATA_DIR

log = logging.getLogger("reportkit")
DEMO_MONTH = "2026-10"


def parse_inputs(pairs: list[str]) -> dict[str, Path]:
    """['ledger=C:/x.csv'] -> {'ledger': Path('C:/x.csv')}."""
    inputs = {}
    for pair in pairs:
        name, sep, path = pair.partition("=")
        if not sep or not name or not path:
            raise ValueError(f"--input needs NAME=PATH, got {pair!r}")
        inputs[name.strip()] = Path(path.strip())
    return inputs


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="reportkit", description="Nexora business reports."
    )
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("list", help="show every report and the files it needs")

    run = commands.add_parser("run", help="run one report")
    run.add_argument("report", choices=[spec.name for spec in all_reports()])
    run.add_argument(
        "--data-dir",
        type=Path,
        default=DEFAULT_DATA_DIR,
        help="folder with the exports (the newest matching file is used)",
    )
    run.add_argument(
        "--input",
        action="append",
        default=[],
        metavar="NAME=PATH",
        help="use this file for one input instead of searching",
    )
    run.add_argument("--month", help="YYYY-MM, for monthly reports")
    run.add_argument(
        "--as-of", help="date or time to count days from (default: now, IST)"
    )
    run.add_argument("--out", type=Path, default=Path("reports_out"))

    demo = commands.add_parser(
        "demo", help="write sample data and run every report on it"
    )
    demo.add_argument("--out", type=Path, default=Path("reportkit_demo"))
    return parser


def cmd_list(_args: argparse.Namespace) -> None:
    for spec in all_reports():
        when = "monthly" if spec.monthly else "daily"
        files = ", ".join(
            f"{name} ({inp.pattern})" for name, inp in spec.inputs.items()
        )
        print(f"{spec.name:<16} {when:<8} {spec.title}: {files}")


def cmd_run(args: argparse.Namespace) -> None:
    context = RunContext(
        as_of=report_timestamp(args.as_of), month=parse_month(args.month)
    )
    report, path = run_report(
        get_report(args.report),
        context,
        args.data_dir,
        args.out,
        parse_inputs(args.input),
    )
    print(report.summary.to_string(index=False))
    print(f"Saved {path}")


def cmd_demo(args: argparse.Namespace) -> None:
    data_dir = args.out / "data"
    write_demo_data(data_dir)
    context = RunContext(as_of=AS_OF, month=parse_month(DEMO_MONTH))
    for spec in all_reports():
        report, path = run_report(spec, context, data_dir, args.out / "reports")
        print(f"\n== {spec.title} -> {path.name}")
        print(report.summary.head(8).to_string(index=False))


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    args = build_parser().parse_args(argv)
    commands = {"list": cmd_list, "run": cmd_run, "demo": cmd_demo}  # a dispatch table
    try:
        commands[args.command](args)
    except (ValueError, KeyError, FileNotFoundError) as err:
        log.error("%s", err)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
