"""Settings every report shares. Each report's own rules sit at its top."""

from pathlib import Path

# ---- Time and calendar ------------------------------------------------------------
REPORT_TZ = "Asia/Kolkata"  # days and months are counted on the IST calendar
DATA_TZ = "UTC"  # timestamps written without a zone are taken to be UTC

# ---- Files ------------------------------------------------------------------------
DEFAULT_DATA_DIR = Path.home() / "Downloads"  # where exports are looked for
OUTPUT_NAME = "{report}_{stamp}.xlsx"  # every output carries the run's date

# ---- Ledger meaning ---------------------------------------------------------------
TRADE_TYPE = "BILL"  # ledger rows that are trades; Debit on them is the trade value
DEPOSIT_TYPE = "DEPOSIT"

# ---- Labels people see ------------------------------------------------------------
NO_OWNER = "No owner"  # a blank manager, agent or owner
TOTAL = "Total"  # the label of every total row

# ---- Excel layout -----------------------------------------------------------------
HEADER_FILL = "FFE699"
MONEY_FORMAT = "#,##0.00;[Red]-#,##0.00"
COUNT_FORMAT = "#,##0"
DATE_FORMAT = "dd-mmm-yyyy hh:mm"
