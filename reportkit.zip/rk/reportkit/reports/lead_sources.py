"""Lead sources: leads, conversions, first deposits and deposits per source.

One month at a time.

Business rules:
* Spellings of the same source are merged ((META-IMR) and Meta 1yt IMR are Meta-IMR),
  and sources in EXCLUDED_SOURCES are left out.
* Each client has one source: from the lead that converted, else from the earliest lead.
* Leads count by lead date, conversions by conversion date, first deposits by the date
  of the client's first ever deposit: each number counts by its own date.
* Deposits from clients with no lead are shown as NO_LEAD, so the table adds up to the
  ledger.
"""

from __future__ import annotations

import pandas as pd

from reportkit.core.cleaning import clean_ids, clean_text
from reportkit.core.dates import in_window
from reportkit.core.registry import InputSpec, ReportSpec, RunContext, register
from reportkit.core.result import Report, reconcile, with_total
from reportkit.settings import DEPOSIT_TYPE

NAME = "lead_sources"

# ---- Input contract ---------------------------------------------------------------
INPUTS = {
    "leads": InputSpec(
        pattern="leads_analysis*.csv",
        columns={
            "lead_id": "lead_id",
            "zynixx_client_id": "client_id",
            "lead_source": "source",
            "lead_date": "lead_date",
            "converted_at": "converted_at",
        },
        dates=("lead_date", "converted_at"),
    ),
    "ledger": InputSpec(
        pattern="ledger*.csv",
        columns={
            "ClientID": "client_id",
            "CreatedAt": "created_at",
            "LedgerType": "ledger_type",
            "Credit": "credit",
        },
        dates=("created_at",),
    ),
}

# ---- Business rules ---------------------------------------------------------------
SOURCE_ALIASES = {"(META-IMR)": "Meta-IMR", "Meta 1yt IMR": "Meta-IMR"}
EXCLUDED_SOURCES = frozenset({"Old Portal_1YT"})
NO_LEAD = "No lead"
UNKNOWN_SOURCE = "Unknown source"


def clean_leads(raw: pd.DataFrame, checks: dict) -> pd.DataFrame:
    """Clean IDs, merge spellings of a source, drop excluded sources."""
    source = clean_text(raw["source"])
    source = source.map(SOURCE_ALIASES).fillna(source).fillna(UNKNOWN_SOURCE)
    leads = raw.assign(client_id=clean_ids(raw["client_id"]), source=source)
    excluded = leads["source"].isin(EXCLUDED_SOURCES)
    checks["leads from excluded sources"] = int(excluded.sum())
    return leads[~excluded]


def source_per_client(leads: pd.DataFrame) -> pd.Series:
    """client_id -> source: the converted lead first, otherwise the earliest lead.

    Sorting decides which duplicate survives drop_duplicates.
    """
    ranked = (
        leads.dropna(subset=["client_id"])
        .assign(converted=lambda t: t["converted_at"].notna())
        .sort_values(
            ["client_id", "converted", "converted_at", "lead_date"],
            ascending=[True, False, True, True],
            na_position="last",
        )
    )
    return ranked.drop_duplicates("client_id").set_index("client_id")["source"]


def first_deposits(ledger: pd.DataFrame) -> pd.DataFrame:
    """Each client's first ever deposit. idxmin picks each client's earliest row."""
    deposits = ledger[
        ledger["ledger_type"].astype("string").str.upper().eq(DEPOSIT_TYPE)
    ]
    first = deposits.loc[deposits.groupby("client_id")["created_at"].idxmin()]
    return first[["client_id", "created_at", "credit"]].rename(
        columns={"created_at": "first_deposit_at", "credit": "first_deposit"}
    )


def source_of_rows(rows: pd.DataFrame, source_of: pd.Series) -> pd.Series:
    """Each row's client's source; NO_LEAD for clients with no lead."""
    return rows["client_id"].map(source_of).fillna(NO_LEAD)


def build(data: dict[str, pd.DataFrame], context: RunContext) -> Report:
    checks: dict = {"month": str(context.month)}
    start, end = context.window
    leads = clean_leads(data["leads"], checks)
    source_of = source_per_client(leads)
    ledger = data["ledger"].assign(client_id=clean_ids(data["ledger"]["client_id"]))
    deposits = ledger[
        ledger["ledger_type"].astype("string").str.upper().eq(DEPOSIT_TYPE)
    ]
    month_deposits = deposits[in_window(deposits["created_at"], start, end)]
    ftd = first_deposits(ledger)
    ftd_in_month = ftd[in_window(ftd["first_deposit_at"], start, end)]

    new = in_window(leads["lead_date"], start, end)
    converted = in_window(leads["converted_at"], start, end)
    table = pd.concat(
        {
            "leads": leads[new].groupby("source").size(),
            "conversions": leads[converted].groupby("source").size(),
            "first_deposits": ftd_in_month.groupby(
                source_of_rows(ftd_in_month, source_of)
            ).size(),
            "depositors": month_deposits.groupby(
                source_of_rows(month_deposits, source_of)
            )["client_id"].nunique(),
            "deposits": month_deposits.groupby(
                source_of_rows(month_deposits, source_of)
            )["credit"].sum(),
        },
        axis=1,
    ).fillna(0)
    counts = ["leads", "conversions", "first_deposits", "depositors"]
    table[counts] = table[counts].astype(int)
    total_deposits = table["deposits"].sum()
    table["deposit_share_pct"] = (
        100 * table["deposits"] / total_deposits if total_deposits else 0.0
    )
    table = (
        table.sort_values("deposits", ascending=False)
        .rename_axis("source")
        .reset_index()
    )
    table = with_total(
        table, "source"
    )  # total before rounding, so the shares add up to 100
    table["deposit_share_pct"] = table["deposit_share_pct"].round(1)
    reconcile(
        "deposits per source vs the ledger",
        table["deposits"].iloc[-1],
        month_deposits["credit"].sum(),
        tolerance=0.01,
    )

    clients = (
        source_of.rename("source")
        .rename_axis("client_id")
        .reset_index()
        .merge(ftd, on="client_id", how="left", validate="one_to_one")
    )
    checks["clients with a source"] = len(source_of)
    return Report(
        name=NAME,
        title="Lead sources",
        checks=checks,
        tables={"By source": table, "Clients": clients},
    )


SPEC = register(
    ReportSpec(
        name=NAME, title="Lead sources", inputs=INPUTS, build=build, monthly=True
    )
)
