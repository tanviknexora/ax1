"""Call list (Pullback SOP): who to call, in what order, counted per TL and per CRE.

Business rules:
* Priority comes from the real-time status: Active P1, Inactive P2, Sleeping and Stale
  P3, Lost Lead and Dormant P4.
* Anyone who traded or was called in the last RECENT_DAYS days isn't called again yet.
* P2 to P4 also need more than CALL_GAP_DAYS since the last call; never-called clients
  are due.
* P1 counts only on the 2nd and 3rd day after the last trade, as in the SQL call list.
* Clients with no CRE are shared out to whoever has the fewest (a greedy min-heap).
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from reportkit.core.cleaning import clean_ids, clean_text
from reportkit.core.dates import days_since
from reportkit.core.dsa import assign_least_loaded, band_labels
from reportkit.core.registry import InputSpec, ReportSpec, RunContext, register
from reportkit.core.result import Report, reconcile, unknown_values, with_total
from reportkit.settings import NO_OWNER, TOTAL

NAME = "call_list"

# ---- Input contract ---------------------------------------------------------------
INPUTS = {
    "customers": InputSpec(
        pattern="trading-customers*.csv",
        columns={
            "Client ID": "client_id",
            "Real-Time Status": "status",
            "Manager": "manager",
            "Assigned To": "agent",
            "Last Transaction": "last_txn",
            "Last Call": "last_call",
        },
        dates=("last_txn", "last_call"),
    ),
}

# ---- Business rules ---------------------------------------------------------------
PRIORITY_BY_STATUS = {
    "Active": "P1",
    "Inactive": "P2",
    "Sleeping": "P3",
    "Stale": "P3",
    "Lost Lead": "P4",
    "Dormant": "P4",
}
RECENT_DAYS = 2  # traded or called fewer than this many days ago: not yet
CALL_GAP_DAYS = {
    "P1": None,
    "P2": 4,
    "P3": 4,
    "P4": 4,
}  # last call more than this long ago
INCLUDE_NEVER_CALLED = True  # a client never called counts as due
P1_DAYS = {
    2: "P1 2nd day",
    3: "P1 3rd day",
}  # days since the last trade -> P1 call type
CALL_TYPES = (*P1_DAYS.values(), "P2", "P3", "P4")

# ---- Layout -----------------------------------------------------------------------
TXN_BAND_EDGES = (2, 4, 8, 15)
TXN_BAND_LABELS = ("0-1 days", "2-3 days", "4-7 days", "8-14 days", "15+ days")
QUEUE_LENGTH = 50  # how many clients each CRE's ranked queue shows
LIST_COLUMNS = [
    "call_rank",
    "agent",
    "client_id",
    "status",
    "call_type",
    "manager",
    "agent_assigned",
    "last_txn",
    "days_since_txn",
    "txn_band",
    "last_call",
    "days_since_call",
]


def clean(raw: pd.DataFrame, checks: dict) -> pd.DataFrame:
    """Trim text, label blank TLs, keep one row per client; count what changed."""
    df = raw.assign(
        client_id=clean_ids(raw["client_id"]),
        status=clean_text(raw["status"]),
        manager=clean_text(raw["manager"]).fillna(NO_OWNER),
        agent=clean_text(raw["agent"]),
    )
    duplicated = df["client_id"].duplicated()
    checks["duplicate clients dropped"] = int(duplicated.sum())
    df = df[~duplicated]
    checks["statuses with no priority"] = unknown_values(
        df["status"], set(PRIORITY_BY_STATUS)
    )
    return df


def add_priority(df: pd.DataFrame, as_of: pd.Timestamp) -> pd.DataFrame:
    """Days since the last trade and call (IST calendar days), and the priority."""
    return df.assign(
        days_since_txn=days_since(df["last_txn"], as_of),
        days_since_call=days_since(df["last_call"], as_of),
        priority=df["status"].map(PRIORITY_BY_STATUS),
    )


def select_due(df: pd.DataFrame, checks: dict) -> pd.DataFrame:
    """The clients to call today, with their call type (P1's day, or P2 to P4)."""
    txn, call = df["days_since_txn"], df["days_since_call"]
    recent = txn.lt(RECENT_DAYS).fillna(False) | call.lt(RECENT_DAYS).fillna(False)
    gap = df["priority"].map(CALL_GAP_DAYS).astype("Float64")  # <NA>: no gap rule
    never_called = call.isna()
    gap_ok = (
        gap.isna() | call.gt(gap).fillna(False) | (never_called & INCLUDE_NEVER_CALLED)
    )
    p1_day_ok = df["priority"].ne("P1") | txn.isin(list(P1_DAYS)).fillna(False)
    keep = (df["priority"].notna() & ~recent & gap_ok & p1_day_ok).astype(bool)
    due = df[keep]
    checks["never called, on the list"] = int((keep & never_called).sum())
    call_type = np.where(
        due["priority"].eq("P1"), due["days_since_txn"].map(P1_DAYS), due["priority"]
    )
    return due.assign(call_type=call_type)


def share_unowned(due: pd.DataFrame, checks: dict) -> pd.DataFrame:
    """Give each client with no CRE to the CRE with the fewest clients so far."""
    unowned = due["agent"].isna()
    agents = sorted(due["agent"].dropna().unique())
    checks["clients with no CRE, shared out"] = int(unowned.sum()) if agents else 0
    if not agents or not unowned.any():
        return due.assign(agent=due["agent"].fillna(NO_OWNER), agent_assigned=False)
    load = due["agent"].value_counts().reindex(agents, fill_value=0).to_dict()
    new_agent = assign_least_loaded(load, sorted(due.loc[unowned, "client_id"]))
    return due.assign(
        agent=due["agent"].fillna(due["client_id"].map(new_agent)),
        agent_assigned=unowned,
    )


def rank_calls(due: pd.DataFrame) -> pd.DataFrame:
    """Each CRE's calling order: P1 first, then longest without a call.

    Never-called clients come first. The client ID is the last sort key: without a
    tie-break, tied clients could swap places between runs.
    """
    ordered = due.sort_values(
        ["priority", "days_since_call", "client_id"],
        ascending=[True, False, True],
        na_position="first",
        kind="stable",
    )
    return ordered.assign(call_rank=ordered.groupby("agent").cumcount() + 1)


def count_by(due: pd.DataFrame, owner: str, label: str) -> pd.DataFrame:
    """Clients per owner and call type, with a Total column and a Total row."""
    table = (
        due.groupby([owner, "call_type"])
        .size()
        .unstack(fill_value=0)
        .reindex(columns=list(CALL_TYPES), fill_value=0)
    )
    table[TOTAL] = table.sum(axis=1)
    table = table.sort_values(TOTAL, ascending=False).rename_axis(label).reset_index()
    table.columns.name = None
    return with_total(table, label)


def build(data: dict[str, pd.DataFrame], context: RunContext) -> Report:
    checks: dict = {"as of": f"{context.as_of:%d %b %Y %H:%M}"}
    clients = add_priority(clean(data["customers"], checks), context.as_of)
    due = rank_calls(share_unowned(select_due(clients, checks), checks))
    due = due.assign(
        txn_band=band_labels(due["days_since_txn"], TXN_BAND_EDGES, TXN_BAND_LABELS)
    )

    by_tl = count_by(due, "manager", "TL")
    by_cre = count_by(due, "agent", "CRE")
    reconcile("TL total vs the call list", by_tl[TOTAL].iloc[-1], len(due))
    reconcile("CRE total vs the call list", by_cre[TOTAL].iloc[-1], len(due))
    checks["on the call list"] = len(due)

    return Report(
        name=NAME,
        title="Call list (Pullback SOP)",
        checks=checks,
        tables={
            "By TL": by_tl,
            "By CRE": by_cre,
            f"Top {QUEUE_LENGTH} per CRE": due.loc[
                due["call_rank"] <= QUEUE_LENGTH, LIST_COLUMNS
            ],
            "Call list": due[LIST_COLUMNS],
        },
    )


SPEC = register(
    ReportSpec(name=NAME, title="Call list (Pullback SOP)", inputs=INPUTS, build=build)
)
