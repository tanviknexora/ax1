"""USD clients: who traded crypto spot, other USD instruments, or neither, in one month.

Business rules:
* A trade is a BILL row; its instrument is the last word of the Narration.
* Crypto spot is the platform's list in CRYPTO_SPOT; any other symbol containing 'USD'
  is Other USD; everything else is Not USD.
* Every customer lands in exactly one group, so the groups add up to the customer count.
  (Overlapping groups once added up to 48,557 from 35,603 customers.)
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from reportkit.core.cleaning import clean_ids
from reportkit.core.dates import in_window
from reportkit.core.registry import InputSpec, ReportSpec, RunContext, register
from reportkit.core.result import Report, reconcile, with_total
from reportkit.settings import TRADE_TYPE

NAME = "usd_clients"

# ---- Input contract ---------------------------------------------------------------
LEDGER = InputSpec(
    pattern="ledger*.csv",
    columns={
        "ClientID": "client_id",
        "CreatedAt": "created_at",
        "LedgerType": "ledger_type",
        "Debit": "debit",
        "Credit": "credit",
        "Narration": "narration",
    },
    dates=("created_at",),
)
INPUTS = {
    "customers": InputSpec(
        pattern="trading-customers*.csv", columns={"Client ID": "client_id"}
    ),
    "ledger": LEDGER,
}

# ---- Business rules ---------------------------------------------------------------
# The symbols stay a compact grid: the formatter would put each on its own line.
# fmt: off
CRYPTO_SPOT = frozenset({
    "AAVEUSD", "ADAUSD", "ALGOUSD", "ATOMUSD", "AXSUSD", "BNBUSD", "BTCUSD", "DOGEUSD",
    "DOTUSD", "ETCUSD", "ETHUSD", "FILUSD", "GRTUSD", "ICPUSD", "IOTAUSD", "LINKUSD",
    "LRCUSD", "LTCUSD", "MANAUSD", "NEARUSD", "SOLUSD", "TRXUSD", "UNIUSD", "XRPUSD",
    "ZECUSD",
})  # Official Trump Coin: add its symbol as it appears in the Narration
# fmt: on
CRYPTO, OTHER_USD, NOT_USD = "Crypto Spot", "Other USD", "Not USD"
GROUPS = (
    "Crypto Spot only",
    "Other USD only",
    "Both Crypto Spot and Other USD",
    "Non-USD trades only",
    "No trades",
    "No ledger rows",
)


def classify(instruments: pd.Series) -> pd.Series:
    """Crypto Spot, Other USD or Not USD. The first matching condition wins."""
    symbol = instruments.astype("string").str.strip().str.upper()
    in_crypto = symbol.isin(CRYPTO_SPOT).fillna(False).astype(bool)
    is_usd = symbol.str.contains("USD", regex=False).fillna(False).astype(bool)
    return pd.Series(
        np.select([in_crypto, is_usd], [CRYPTO, OTHER_USD], NOT_USD),
        index=instruments.index,
    )


def month_trades(
    ledger: pd.DataFrame, customers: set, context: RunContext
) -> pd.DataFrame:
    """This month's BILL rows of these customers, with instrument and class."""
    start, end = context.window
    rows = ledger.assign(client_id=clean_ids(ledger["client_id"]))
    rows = rows[
        rows["client_id"].isin(customers) & in_window(rows["created_at"], start, end)
    ]
    trades = rows[
        rows["ledger_type"].astype("string").str.strip().str.upper().eq(TRADE_TYPE)
    ]
    instrument = trades["narration"].astype("string").str.rsplit(n=1).str[-1]
    return trades.assign(instrument=instrument, usd_class=classify(instrument))


def client_groups(
    trades: pd.DataFrame, in_ledger: set, customers: set
) -> dict[str, set]:
    """Every customer in exactly one group, by set maths."""
    crypto = set(trades.loc[trades["usd_class"].eq(CRYPTO), "client_id"])
    other = set(trades.loc[trades["usd_class"].eq(OTHER_USD), "client_id"])
    traded = set(trades["client_id"])
    members = [
        crypto - other,
        other - crypto,
        crypto & other,
        traded - crypto - other,
        in_ledger - traded,
        customers - in_ledger,
    ]
    return dict(zip(GROUPS, members, strict=True))


def client_table(groups: dict[str, set], trades: pd.DataFrame) -> pd.DataFrame:
    """One row per customer: group, trades, instruments, money, first and last trade."""
    group_of = {cid: name for name, ids in groups.items() for cid in ids}
    per_client = trades.groupby("client_id").agg(
        trades=("instrument", "size"),
        instruments=("instrument", lambda s: ", ".join(sorted(s.dropna().unique()))),
        debit=("debit", "sum"),
        credit=("credit", "sum"),
        first_trade=("created_at", "min"),
        last_trade=("created_at", "max"),
    )
    table = per_client.reindex(sorted(group_of)).rename_axis("client_id").reset_index()
    table = table.assign(
        group=table["client_id"].map(group_of),
        trades=table["trades"].fillna(0).astype(int),
        instruments=table["instruments"].fillna(""),
        debit=table["debit"].fillna(0.0),
        credit=table["credit"].fillna(0.0),
    )
    table["net"] = table["credit"] - table["debit"]
    table["group_order"] = table["group"].map(
        {name: i for i, name in enumerate(GROUPS)}
    )
    table = table.sort_values(
        ["group_order", "trades", "client_id"], ascending=[True, False, True]
    )
    columns = [
        "client_id",
        "group",
        "trades",
        "instruments",
        "debit",
        "credit",
        "net",
        "first_trade",
        "last_trade",
    ]
    return table[columns].reset_index(drop=True)


def build(data: dict[str, pd.DataFrame], context: RunContext) -> Report:
    customers = set(clean_ids(data["customers"]["client_id"]).dropna())
    start, end = context.window
    ledger_ids = clean_ids(data["ledger"]["client_id"])
    seen = in_window(data["ledger"]["created_at"], start, end)
    in_ledger = set(ledger_ids[seen]) & customers
    trades = month_trades(data["ledger"], customers, context)
    groups = client_groups(trades, in_ledger, customers)

    summary = with_total(
        pd.DataFrame(
            {"Group": list(groups), "Clients": [len(v) for v in groups.values()]}
        ),
        "Group",
    )
    reconcile("groups vs customers", summary["Clients"].iloc[-1], len(customers))
    by_instrument = (
        trades.groupby(["usd_class", "instrument"])
        .agg(
            trades=("client_id", "size"),
            clients=("client_id", "nunique"),
            debit=("debit", "sum"),
            credit=("credit", "sum"),
        )
        .reset_index()
        .sort_values(["usd_class", "trades"], ascending=[True, False])
    )
    checks = {
        "month": str(context.month),
        "customers": len(customers),
        "customers in the ledger this month": len(in_ledger),
        "trades": len(trades),
    }
    return Report(
        name=NAME,
        title="USD clients",
        checks=checks,
        tables={
            "Groups": summary,
            "By instrument": by_instrument,
            "Clients": client_table(groups, trades),
        },
    )


SPEC = register(
    ReportSpec(name=NAME, title="USD clients", inputs=INPUTS, build=build, monthly=True)
)
