"""Not connected: leads whose most recent calls were all unreachable.

The pandas version of the SQL used in Metabase, with the same rules:
* One disposition per call: the newest one that isn't blank.
* Dispositions match whatever the spelling ('Ringing / Busy' = 'Ringing/Busy').
* Calls still being placed, or that failed in the system, are ignored.
* The run (streak) counts from the newest call back to the first call with another
  outcome.
"""

from __future__ import annotations

import re

import pandas as pd

from reportkit.core.cleaning import clean_ids, clean_text, text_key
from reportkit.core.registry import InputSpec, ReportSpec, RunContext, register
from reportkit.core.result import Report, with_total
from reportkit.settings import NO_OWNER

NAME = "not_connected"

# ---- Input contract ---------------------------------------------------------------
INPUTS = {
    "leads": InputSpec(
        pattern="old_leads*.csv",
        columns={
            "lead_id": "lead_id",
            "zynixx_client_id": "client_id",
            "followup_owner": "owner",
        },
    ),
    "calls": InputSpec(
        pattern="call_logs*.csv",
        columns={
            "call_id": "call_id",
            "lead_id": "lead_id",
            "started_at": "started_at",
            "status": "status",
            "disposition": "disposition",
        },
        dates=("started_at",),
    ),
}

# ---- Business rules ---------------------------------------------------------------
NOT_CONNECTED = (
    "Ringing/Busy",
    "Switched off",
    "Invalid Number",
    "Did not Connected /Out of Service",
    "Disconnected by customer",
    "Zero",
    "Didn't connect",
    "No Answer",
)
NOT_CONNECTED_KEYS = frozenset(
    re.sub(r"[^a-z0-9]", "", name.lower()) for name in NOT_CONNECTED
)
IGNORED_STATUSES = frozenset({"placing", "call_failed"})
MIN_STREAK = 5  # this many newest calls (or more) all unreachable
SHOWN_CALLS = 5  # how many recent calls the list shows


def prepare_calls(calls: pd.DataFrame, lead_ids: set, checks: dict) -> pd.DataFrame:
    """The leads' calls, one disposition each, ranked newest first (1 = newest)."""
    calls = calls.assign(
        lead_id=clean_ids(calls["lead_id"]),
        disposition=clean_text(calls["disposition"]),
    )
    status = calls["status"].astype("string").str.strip().str.lower()
    ignored = status.isin(IGNORED_STATUSES).fillna(False)
    checks["calls ignored by status"] = int(ignored.sum())
    calls = calls[~ignored & calls["lead_id"].isin(lead_ids)]

    # Several rows for one call: keep the newest row that has a disposition.
    has_disposition = calls["disposition"].notna()
    one_each = (
        calls.assign(has_disposition=has_disposition)
        .sort_values(["call_id", "has_disposition"], kind="stable")
        .drop_duplicates("call_id", keep="last")
    )
    checks["extra disposition rows dropped"] = len(calls) - len(one_each)

    ranked = one_each.sort_values(
        ["lead_id", "started_at", "call_id"], ascending=[True, False, False]
    )
    return ranked.assign(
        rank=ranked.groupby("lead_id").cumcount() + 1,
        not_connected=text_key(ranked["disposition"])
        .isin(NOT_CONNECTED_KEYS)
        .fillna(False)
        .astype(bool),
    )


def streaks(calls: pd.DataFrame) -> pd.DataFrame:
    """Per lead: calls, the unreachable run, the last other outcome, recent calls."""
    total = calls.groupby("lead_id").size()
    other = calls[~calls["not_connected"]]
    first_other = other.groupby("lead_id")["rank"].min()
    recent = calls[calls["rank"] <= SHOWN_CALLS]
    label = (
        recent["disposition"].fillna("(no disposition)")
        + " ("
        + recent["started_at"].dt.strftime("%d %b %H:%M")
        + ")"
    )
    return pd.DataFrame(
        {
            "total_calls": total,
            "not_connected_streak": first_other.reindex(total.index).fillna(total + 1)
            - 1,
            "last_other_outcome_at": other.groupby("lead_id")["started_at"].max(),
            "last_calls": label.groupby(recent["lead_id"]).agg(" | ".join),
        }
    ).astype({"not_connected_streak": "int64"})


def build(data: dict[str, pd.DataFrame], context: RunContext) -> Report:
    leads = data["leads"].assign(
        lead_id=clean_ids(data["leads"]["lead_id"]),
        owner=clean_text(data["leads"]["owner"]).fillna(NO_OWNER),
    )
    leads = leads.drop_duplicates("lead_id")
    checks: dict = {"leads checked": len(leads)}
    calls = prepare_calls(data["calls"], set(leads["lead_id"]), checks)
    per_lead = streaks(calls)
    hits = per_lead[per_lead["not_connected_streak"] >= MIN_STREAK]
    result = leads.merge(
        hits, left_on="lead_id", right_index=True, how="inner", validate="one_to_one"
    ).sort_values(["not_connected_streak", "lead_id"], ascending=[False, True])
    by_owner = (
        result.groupby("owner")
        .size()
        .rename("leads")
        .sort_values(ascending=False)
        .rename_axis("owner")
        .reset_index()
    )
    checks[f"leads not connected for the last {MIN_STREAK} calls or more"] = len(result)
    return Report(
        name=NAME,
        title="Not connected",
        checks=checks,
        tables={"By owner": with_total(by_owner, "owner"), "Not connected": result},
    )


SPEC = register(
    ReportSpec(name=NAME, title="Not connected", inputs=INPUTS, build=build)
)
