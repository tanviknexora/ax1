"""Broker program: each referrer's children, activity, trade value and eligibility.

Business rules (each target is a named setting below):
* Demo children are counted separately and never count towards targets.
* Trade value is the Debit on the children's BILL rows (client losses); this definition
  is one of the decisions the Thailand plan asks management to confirm.
* The trade-value target grows by GROWTH on last month's value once it's above the
  minimum; below the minimum, the target is the minimum.
* Eligible: at least MIN_CHILDREN real children, NEW_CLIENTS_TARGET new ones this month,
  and trade value at or above the target. Otherwise the reasons are spelled out.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from reportkit.core.cleaning import clean_ids, is_true
from reportkit.core.dates import in_window, month_bounds
from reportkit.core.dsa import bfs_levels
from reportkit.core.registry import InputSpec, ReportSpec, RunContext, register
from reportkit.core.result import Report, reconcile, with_total
from reportkit.settings import TRADE_TYPE

NAME = "broker_program"

# ---- Input contract ---------------------------------------------------------------
INPUTS = {
    "referrals": InputSpec(
        pattern="referrals*.csv",
        columns={
            "referrer_client_id": "referrer_id",
            "client_id": "client_id",
            "is_demo": "is_demo",
            "created_at": "created_at",
        },
        dates=("created_at",),
    ),
    "ledger": InputSpec(
        pattern="ledger*.csv",
        columns={
            "ClientID": "client_id",
            "CreatedAt": "created_at",
            "LedgerType": "ledger_type",
            "Debit": "debit",
        },
        dates=("created_at",),
    ),
}

# ---- Program targets --------------------------------------------------------------
MIN_CHILDREN = 6  # real (non-demo) children needed to qualify
NEW_CLIENTS_TARGET = 6  # real children added this month
MIN_TRADE_VALUE = 60_000.0  # the lowest trade-value target
GROWTH = 0.02  # target growth on last month's trade value
TRUE_WORDS = frozenset({"true", "yes", "1"})  # how the export writes 'demo'


def clean_links(raw: pd.DataFrame, checks: dict) -> pd.DataFrame:
    """Clean IDs and the demo flag; keep one referrer per child (the most recent link).

    A child under two referrers would have its trade value counted twice.
    """
    links = raw.assign(
        referrer_id=clean_ids(raw["referrer_id"]),
        client_id=clean_ids(raw["client_id"]),
        is_demo=is_true(raw["is_demo"], TRUE_WORDS),
    ).dropna(subset=["client_id"])
    latest = links.sort_values("created_at", kind="stable").drop_duplicates(
        "client_id", keep="last"
    )
    checks["children with more than one referrer (latest link kept)"] = len(
        links
    ) - len(latest)
    return latest


def trade_value(
    ledger: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp
) -> pd.Series:
    """client_id -> sum of Debit on BILL rows between start and end."""
    is_trade = (
        ledger["ledger_type"].astype("string").str.strip().str.upper().eq(TRADE_TYPE)
    )
    rows = ledger[is_trade & in_window(ledger["created_at"], start, end)]
    return rows.groupby(clean_ids(rows["client_id"]))["debit"].sum()


def downline_sizes(links: pd.DataFrame) -> pd.Series:
    """referrer -> everyone below them at any level, by breadth-first search."""
    real = links[~links["is_demo"]]
    children = real.groupby("referrer_id")["client_id"].apply(list).to_dict()
    return pd.Series(
        {ref: len(bfs_levels(children, ref)) for ref in children}, dtype="int64"
    )


def eligibility(table: pd.DataFrame) -> pd.DataFrame:
    """ELIGIBLE, or the reasons not, joined into one readable column."""
    reasons = pd.DataFrame(
        {
            "children": np.where(
                table["children"] < MIN_CHILDREN,
                f"fewer than {MIN_CHILDREN} real children",
                "",
            ),
            "new": np.where(
                table["new_clients_needed"] > 0,
                "needs "
                + table["new_clients_needed"].astype(str)
                + " more new client"
                + np.where(table["new_clients_needed"] == 1, "", "s"),
                "",
            ),
            "value": np.where(
                table["trade_value"] < table["target_trade_value"],
                "trade value below target",
                "",
            ),
        },
        index=table.index,
    )
    joined = reasons["children"] + "|" + reasons["new"] + "|" + reasons["value"]
    reason = joined.str.replace(r"\|+", "; ", regex=True).str.strip("; ")
    return table.assign(
        status=np.where(reason.eq(""), "ELIGIBLE", "NOT ELIGIBLE"),
        reason=reason.replace("", "All targets met"),
    )


def build(data: dict[str, pd.DataFrame], context: RunContext) -> Report:
    start, end = context.window
    prev_start, prev_end = month_bounds(context.month - 1)
    checks: dict = {"month": str(context.month)}
    links = clean_links(data["referrals"], checks)
    value_now = trade_value(data["ledger"], start, end)
    value_before = trade_value(data["ledger"], prev_start, prev_end)

    links = links.assign(
        real=~links["is_demo"],
        added=~links["is_demo"] & in_window(links["created_at"], start, end),
        child_value=links["client_id"]
        .map(value_now)
        .fillna(0.0)
        .where(~links["is_demo"], 0.0),
        child_value_before=links["client_id"]
        .map(value_before)
        .fillna(0.0)
        .where(~links["is_demo"], 0.0),
    )
    links["active"] = links["real"] & links["child_value"].gt(0)

    table = links.groupby("referrer_id").agg(
        children=("real", "sum"),
        demo_children=("is_demo", "sum"),
        added_this_month=("added", "sum"),
        active_this_month=("active", "sum"),
        trade_value=("child_value", "sum"),
        previous_trade_value=("child_value_before", "sum"),
    )
    table["downline_all_levels"] = downline_sizes(links).reindex(table.index).fillna(0)
    table["target_trade_value"] = np.where(
        table["previous_trade_value"] >= MIN_TRADE_VALUE,
        table["previous_trade_value"] * (1 + GROWTH),
        MIN_TRADE_VALUE,
    ).round(2)
    table["new_clients_needed"] = (NEW_CLIENTS_TARGET - table["added_this_month"]).clip(
        lower=0
    )
    table = eligibility(table.astype({"downline_all_levels": "int64"}))
    table = table.sort_values(["status", "trade_value"], ascending=[True, False])
    table = with_total(table.rename_axis("referrer_id").reset_index(), "referrer_id")

    real_children = set(links.loc[links["real"], "client_id"])
    expected = value_now[value_now.index.isin(real_children)].sum()
    reconcile(
        "trade value vs the ledger",
        table["trade_value"].iloc[-1],
        expected,
        tolerance=0.01,
    )
    active = links.loc[links["active"], ["referrer_id", "client_id", "child_value"]]
    checks.update(
        {
            "referrers": int(len(table) - 1),
            "eligible": int(table["status"].eq("ELIGIBLE").sum()),
        }
    )
    return Report(
        name=NAME,
        title="Broker program",
        checks=checks,
        tables={
            "Program": table,
            "Active children": active.rename(
                columns={"child_value": "trade_value"}
            ).sort_values("trade_value", ascending=False),
        },
    )


SPEC = register(
    ReportSpec(
        name=NAME, title="Broker program", inputs=INPUTS, build=build, monthly=True
    )
)
