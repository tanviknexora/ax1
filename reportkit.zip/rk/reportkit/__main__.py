"""Lets the package run as a program: python -m reportkit ..."""

import sys

from reportkit.cli import main

sys.exit(main())
