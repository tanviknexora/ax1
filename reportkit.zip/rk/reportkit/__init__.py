"""reportkit: Nexora's business reports, built one consistent way.

Every report is a small module in reportkit/reports that declares its input files and
builds a Report from loaded data. Shared pieces (dates, cleaning, files, checks,
algorithms) live in reportkit/core, written once. Run `python -m reportkit --help` to
start.
"""

__version__ = "1.0.0"
