"""Realistic sample files for every report, so reportkit runs without company data.

The data is deliberately messy in the ways real exports are: stray spaces, lower-case
IDs, duplicates, blank owners, several spellings of one source, demo children, and calls
with two disposition rows.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

SEED = 2026
AS_OF = pd.Timestamp("2026-11-16 10:00", tz="Asia/Kolkata")


def _iso(times: pd.Series) -> pd.Series:
    """UTC timestamps as text ending in Z, as the exports write them."""
    return times.dt.tz_convert("UTC").dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")


def write_demo_data(folder: Path) -> dict[str, Path]:
    """Write one file per input pattern into folder; return the paths."""
    rng = np.random.default_rng(SEED)
    folder.mkdir(parents=True, exist_ok=True)
    n = 400
    ids = [f"S{200000 + i}" for i in range(n)]

    def ago(max_days: float, size: int) -> pd.Series:
        return pd.Series(
            AS_OF - pd.to_timedelta(rng.uniform(0, max_days, size), unit="D")
        )

    customers = pd.DataFrame(
        {
            "Client ID": ids,
            "Real-Time Status": rng.choice(
                [
                    "Active",
                    "Inactive",
                    "Sleeping",
                    "Stale",
                    "Lost Lead",
                    "Dormant",
                    "Active ",
                    "Churned",
                ],
                n,
                p=[0.3, 0.15, 0.15, 0.1, 0.1, 0.1, 0.05, 0.05],
            ),
            "Manager": rng.choice(
                ["Parth", "Rajinder", "Swathi", None], n, p=[0.32, 0.32, 0.32, 0.04]
            ),
            "Assigned To": rng.choice([f"CRE{i}" for i in range(1, 7)] + [None], n),
            "Last Transaction": _iso(ago(6, n)),
            "Last Call": _iso(ago(9, n)),
            "Balance": rng.integers(0, 50_000, n),
        }
    )
    customers.loc[rng.random(n) < 0.1, "Last Call"] = None
    customers = pd.concat(
        [customers, customers.head(4)], ignore_index=True
    )  # duplicates

    style = dict(
        zip(ids, rng.choice(["crypto", "usd", "both", "nifty"], n), strict=True)
    )
    symbols = {
        "crypto": ["BTCUSD", "ETHUSD", "SOLUSD"],
        "usd": ["XAUUSD", "EURUSD"],
        "both": ["BTCUSD", "XAUUSD"],
        "nifty": ["NIFTY26N1725250CE"],
    }
    rows = 6000
    who = rng.choice(ids[:360], rows)  # the last 40 customers have no ledger rows
    kind = rng.choice(["BILL", "DEPOSIT", "WITHDRAW"], rows, p=[0.7, 0.2, 0.1])
    amount = rng.integers(50, 8000, rows).astype(float)
    loss = (kind == "BILL") & (rng.random(rows) < 0.55)
    narration = np.where(
        kind == "BILL",
        ["Trade bill for " + rng.choice(symbols[style[c]]) for c in who],
        np.where(kind == "DEPOSIT", "Deposit via USDT", "Withdrawal to bank"),
    )
    ledger = pd.DataFrame(
        {
            "ClientID": [c.lower() if i % 50 == 0 else c for i, c in enumerate(who)],
            "CreatedAt": _iso(
                pd.Series(
                    pd.Timestamp("2026-09-01", tz="Asia/Kolkata")
                    + pd.to_timedelta(rng.uniform(0, 76, rows), unit="D")
                )
            ),
            "LedgerType": kind,
            "Debit": np.where(loss | (kind == "WITHDRAW"), amount, 0.0),
            "Credit": np.where(~loss & (kind != "WITHDRAW"), amount, 0.0),
            "Balance": rng.integers(0, 90_000, rows).astype(float),
            "Narration": narration,
        }
    )

    lead_clients = rng.choice(ids, 300, replace=False)
    leads = pd.DataFrame(
        {
            "lead_id": range(1, 351),
            "zynixx_client_id": list(lead_clients)
            + list(rng.choice(lead_clients, 30))
            + [None] * 20,
            "lead_source": rng.choice(
                [
                    "Meta-IMR",
                    "(META-IMR)",
                    "Meta 1yt IMR",
                    "Google",
                    "Referral",
                    "Old Portal_1YT",
                ],
                350,
            ),
            "lead_date": _iso(
                pd.Series(
                    pd.Timestamp("2026-08-01", tz="Asia/Kolkata")
                    + pd.to_timedelta(rng.uniform(0, 100, 350), unit="D")
                )
            ),
        }
    )
    converted = rng.random(350) < 0.4
    leads["converted_at"] = np.where(
        converted,
        _iso(
            pd.Series(
                pd.to_datetime(leads["lead_date"])
                + pd.to_timedelta(rng.uniform(0, 20, 350), unit="D")
            )
        ),
        None,
    )

    referrers = ids[:20]
    pool = list(ids[20:300])
    links = []
    for ref in referrers + pool[:40]:  # 40 children are also referrers: a deeper tree
        for _ in range(rng.integers(2, 12)):
            if not pool:
                break
            child = pool.pop(rng.integers(len(pool)))
            links.append((ref, child))
    referrals = pd.DataFrame(links, columns=["referrer_client_id", "client_id"])
    referrals["is_demo"] = rng.choice(
        ["False", "FALSE", "TRUE", "yes", ""],
        len(referrals),
        p=[0.5, 0.25, 0.1, 0.05, 0.1],
    )
    referrals["created_at"] = _iso(
        pd.Series(
            pd.Timestamp("2026-07-01", tz="Asia/Kolkata")
            + pd.to_timedelta(rng.uniform(0, 130, len(referrals)), unit="D")
        )
    )

    lead_ids = list(range(1, 301))
    old_leads = pd.DataFrame(
        {
            "lead_id": lead_ids,
            "zynixx_client_id": rng.choice(ids, 300),
            "followup_owner": rng.choice(["Asha", "Ravi", "Meena", None], 300),
        }
    )
    calls = []
    dispositions = [
        "Ringing/Busy",
        "Ringing / Busy",
        "Switched off",
        "No Answer",
        "Didn't connect",
        "Interested",
        "Call back later",
        None,
    ]
    weights = [0.25, 0.05, 0.15, 0.2, 0.1, 0.1, 0.1, 0.05]
    call_id = 0
    for lead in lead_ids:
        cold = rng.random() < 0.4  # 40% of leads mostly unreachable
        for k in range(rng.integers(3, 15)):
            call_id += 1
            disp = (
                rng.choice(dispositions[:5])
                if cold and k < 8
                else rng.choice(dispositions, p=weights)
            )
            status = rng.choice(
                ["completed", "placing", "call_failed"], p=[0.94, 0.03, 0.03]
            )
            when = AS_OF - pd.Timedelta(hours=float(k * 7 + rng.uniform(0, 5)))
            calls.append((call_id, lead, when, status, disp))
    call_logs = pd.DataFrame(
        calls, columns=["call_id", "lead_id", "started_at", "status", "disposition"]
    )
    doubles = call_logs.sample(frac=0.03, random_state=SEED).assign(disposition=None)
    call_logs = pd.concat([call_logs, doubles], ignore_index=True)  # blank second rows
    call_logs["started_at"] = _iso(call_logs["started_at"])

    files = {
        "trading-customers (demo).csv": customers,
        "ledger_demo.csv": ledger,
        "leads_analysis_demo.csv": leads,
        "referrals_demo.csv": referrals,
        "old_leads_demo.csv": old_leads,
        "call_logs_demo.csv": call_logs,
    }
    paths = {}
    for name, frame in files.items():
        paths[name] = folder / name
        frame.to_csv(paths[name], index=False)
    return paths
