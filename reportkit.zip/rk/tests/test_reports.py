"""Each report on a tiny hand-written input, with answers worked out on paper."""

import pandas as pd

from reportkit.core.dates import report_timestamp
from reportkit.core.registry import RunContext
from reportkit.reports import (
    broker_program,
    call_list,
    lead_sources,
    not_connected,
    usd_clients,
)
from tests.conftest import times

AS_OF = report_timestamp("2026-11-16 10:00")


def test_call_list_rules():
    customers = pd.DataFrame(
        {
            "client_id": ["C1", "C2", "C3", "C4", "C5", " c1"],
            "status": ["Active", "Active ", "Inactive", "Dormant", "Churned", "Active"],
            "manager": ["Asha", None, "Asha", "Ravi", "Ravi", "Asha"],
            "agent": ["CRE1", "CRE1", None, "CRE2", "CRE2", "CRE1"],
            "last_txn": times(
                "2026-11-14T06:00:00Z",
                "2026-11-13T06:00:00Z",
                "2026-11-01T06:00:00Z",
                "2026-11-01T06:00:00Z",
                "2026-11-01T06:00:00Z",
                "2026-11-14T06:00:00Z",
            ),
            "last_call": times(
                "2026-11-10T06:00:00Z",
                None,
                "2026-11-15T06:00:00Z",
                "2026-11-05T06:00:00Z",
                None,
                "2026-11-10T06:00:00Z",
            ),
        }
    )
    report = call_list.build({"customers": customers}, RunContext(as_of=AS_OF))
    due = report.tables["Call list"].set_index("client_id")
    # C1: P1 2nd day. C2: P1 3rd day ('Active ' trimmed), never called.
    # C3: called yesterday.
    # C4: P4, last call 11 days ago. C5: no priority. ' c1' duplicates C1.
    assert due["call_type"].to_dict() == {
        "C2": "P1 3rd day",
        "C1": "P1 2nd day",
        "C4": "P4",
    }
    assert report.checks["duplicate clients dropped"] == 1
    assert report.checks["statuses with no priority"] == {"Churned": 1}
    assert due.loc["C2", "call_rank"] == 1  # never called comes first
    assert report.tables["By TL"].iloc[-1]["Total"] == 3


def test_call_list_shares_unowned_clients():
    customers = pd.DataFrame(
        {
            "client_id": ["A", "B", "C"],
            "status": ["Dormant"] * 3,
            "manager": ["T"] * 3,
            "agent": ["CRE1", None, None],
            "last_txn": times(*["2026-11-01T06:00:00Z"] * 3),
            "last_call": times(*["2026-11-01T06:00:00Z"] * 3),
        }
    )
    due = call_list.build({"customers": customers}, RunContext(as_of=AS_OF)).tables[
        "Call list"
    ]
    assert set(due["agent"]) == {"CRE1"} and due["agent_assigned"].sum() == 2


def test_usd_groups_add_up_to_customers(october):
    ledger = pd.DataFrame(
        {
            "client_id": ["A", "A", "B", "c", "D", "E", "X"],
            "created_at": times(*["2026-10-05T06:00:00Z"] * 7),
            "ledger_type": ["BILL", "BILL", "BILL", "BILL", "BILL", "DEPOSIT", "BILL"],
            "debit": [10.0, 0, 5, 0, 1, 0, 9],
            "credit": [0.0, 7, 0, 3, 0, 500, 0],
            "narration": [
                "Trade bill for BTCUSD",
                "Trade bill for XAUUSD",
                "Trade bill for ethusd",
                "Trade bill for NIFTY26N1725250CE",
                "Trade bill for EURUSD",
                "Deposit via USDT",
                "Trade bill for BTCUSD",
            ],
        }
    )
    customers = pd.DataFrame({"client_id": ["A", "B", "C", "D", "E", "F"]})
    report = usd_clients.build({"customers": customers, "ledger": ledger}, october)
    groups = report.tables["Groups"].set_index("Group")["Clients"]
    assert groups.to_dict() == {
        "Crypto Spot only": 1,
        "Other USD only": 1,
        "Both Crypto Spot and Other USD": 1,
        "Non-USD trades only": 1,
        "No trades": 1,
        "No ledger rows": 1,
        "Total": 6,
    }


def test_lead_sources_rules(october):
    leads = pd.DataFrame(
        {
            "lead_id": [1, 2, 3, 4],
            "client_id": ["A", "A", "B", None],
            "source": ["Google", "(META-IMR)", "Old Portal_1YT", "Meta 1yt IMR"],
            "lead_date": times(
                "2026-10-01T06:00:00Z",
                "2026-10-02T06:00:00Z",
                "2026-10-03T06:00:00Z",
                "2026-10-04T06:00:00Z",
            ),
            "converted_at": times(None, "2026-10-09T06:00:00Z", None, None),
        }
    )
    ledger = pd.DataFrame(
        {
            "client_id": ["A", "A", "Z"],
            "ledger_type": ["DEPOSIT"] * 3,
            "credit": [100.0, 50, 25],
            "created_at": times(
                "2026-10-10T06:00:00Z", "2026-10-11T06:00:00Z", "2026-10-12T06:00:00Z"
            ),
        }
    )
    report = lead_sources.build({"leads": leads, "ledger": ledger}, october)
    table = report.tables["By source"].set_index("source")
    assert table.loc["Meta-IMR", "leads"] == 2  # both spellings merged
    assert (
        table.loc["Meta-IMR", "deposits"] == 150.0
    )  # A's converted lead wins over Google
    assert table.loc["No lead", "deposits"] == 25.0  # Z has no lead
    assert "Old Portal_1YT" not in table.index
    assert table.loc["Total", "deposit_share_pct"] == 100.0


def test_broker_program_targets(october):
    links = pd.DataFrame(
        {
            "referrer_id": ["R"] * 7 + ["S", "S"],
            "client_id": [f"C{i}" for i in range(7)] + ["C0", "C9"],
            "is_demo": ["False"] * 6 + ["TRUE", "no", "no"],
            # S's link to C0 is older than R's: the latest link wins,
            # so C0 counts only for R
            "created_at": times(
                *["2026-10-05T06:00:00Z"] * 7
                + ["2026-09-01T06:00:00Z", "2026-09-02T06:00:00Z"]
            ),
        }
    )
    ledger = pd.DataFrame(
        {
            "client_id": ["C0", "C1", "C6"],
            "ledger_type": ["BILL"] * 3,
            "debit": [70_000.0, 5_000, 9_999],
            "created_at": times(
                "2026-10-07T06:00:00Z", "2026-10-08T06:00:00Z", "2026-10-09T06:00:00Z"
            ),
        }
    )
    report = broker_program.build({"referrals": links, "ledger": ledger}, october)
    program = report.tables["Program"].set_index("referrer_id")
    assert program.loc["R", "children"] == 6 and program.loc["R", "demo_children"] == 1
    assert (
        program.loc["R", "trade_value"] == 75_000.0
    )  # the demo child's 9,999 doesn't count
    assert program.loc["R", "status"] == "ELIGIBLE"
    assert program.loc["S", "reason"].startswith("fewer than 6 real children")
    assert program.loc["R", "downline_all_levels"] == 6
    assert report.checks["children with more than one referrer (latest link kept)"] == 1


def test_not_connected_streaks():
    leads = pd.DataFrame(
        {"lead_id": ["1", "2"], "client_id": ["A", "B"], "owner": ["Asha", None]}
    )
    newest = pd.Timestamp("2026-11-16 06:00", tz="UTC")
    rows = []
    for lead, outcomes in {
        "1": [
            "No Answer",
            "Ringing / Busy",
            "Switched off",
            "No Answer",
            "Didn't connect",
            "Interested",
        ],
        "2": [None, "No Answer", "No Answer", "No Answer", "No Answer", "No Answer"],
    }.items():
        for k, disposition in enumerate(outcomes):
            rows.append(
                (
                    f"{lead}-{k}",
                    lead,
                    newest - pd.Timedelta(hours=k),
                    "completed",
                    disposition,
                )
            )
    calls = pd.DataFrame(
        rows, columns=["call_id", "lead_id", "started_at", "status", "disposition"]
    )
    calls = pd.concat(
        [calls, calls.iloc[[0]].assign(disposition=None)]
    )  # a blank extra row
    calls["started_at"] = calls["started_at"].dt.tz_convert("Asia/Kolkata")
    report = not_connected.build(
        {"leads": leads, "calls": calls}, RunContext(as_of=AS_OF)
    )
    result = report.tables["Not connected"].set_index("lead_id")
    # lead 1: 5 unreachable, then Interested.
    # lead 2: the newest call has no disposition, so there's no run.
    assert (
        result.index.tolist() == ["1"] and result.loc["1", "not_connected_streak"] == 5
    )
    assert report.checks["extra disposition rows dropped"] == 1
