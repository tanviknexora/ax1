import pandas as pd
import pytest

from reportkit.core.cleaning import clean_ids, text_key
from reportkit.core.dates import days_since, month_bounds, report_timestamp
from reportkit.core.dsa import assign_least_loaded, band_labels, bfs_levels
from reportkit.core.result import reconcile, unknown_values, with_total
from tests.conftest import times


def test_days_since_counts_ist_calendar_days():
    # 20:00 UTC on 10 Nov is 01:30 on 11 Nov in IST: 5 days before 16 Nov, not 6
    days = days_since(
        times("2026-11-10T20:00:00Z", None), report_timestamp("2026-11-16 10:00")
    )
    assert days.tolist()[0] == 5 and pd.isna(days.tolist()[1])


def test_month_bounds_are_ist_midnights():
    start, end = month_bounds("2026-10")
    assert (str(start), str(end)) == (
        "2026-10-01 00:00:00+05:30",
        "2026-11-01 00:00:00+05:30",
    )


def test_cleaning_makes_the_same_client_match():
    assert clean_ids(pd.Series([" s200001", "S200001 "])).nunique() == 1
    assert (
        text_key(pd.Series(["Ringing / Busy"]))[0]
        == text_key(pd.Series(["Ringing/Busy"]))[0]
    )


def test_least_loaded_shares_fairly_and_breaks_ties_by_name():
    assigned = assign_least_loaded({"CRE2": 1, "CRE1": 1, "CRE3": 3}, ["a", "b", "c"])
    assert assigned == {"a": "CRE1", "b": "CRE2", "c": "CRE1"}


def test_band_labels_use_binary_search_and_keep_blanks():
    bands = band_labels(
        pd.Series([0, 2, 3, 9, None], dtype="Int64"), [2, 4], ["0-1", "2-3", "4+"]
    )
    assert bands.astype(object).where(bands.notna(), None).tolist() == [
        "0-1",
        "2-3",
        "2-3",
        "4+",
        None,
    ]


def test_bfs_levels_handle_depth_and_loops():
    tree = {"R": ["A", "B"], "A": ["C"], "C": ["R"]}  # C points back to R: a loop
    assert bfs_levels(tree, "R") == {"A": 1, "B": 1, "C": 2}


def test_with_total_keeps_counts_whole():
    table = with_total(
        pd.DataFrame({"who": ["x", "y"], "n": [1, 2], "v": [1.5, 2.0]}), "who"
    )
    assert table.iloc[-1].tolist() == ["Total", 3, 3.5] and table["n"].dtype == "int64"


def test_reconcile_and_unknowns():
    with pytest.raises(ValueError, match="got 3"):
        reconcile("groups", 3, 4)
    unknown = unknown_values(pd.Series(["Active", "Churned", None]), {"Active"})
    assert (
        unknown["Churned"] == 1 and sum(unknown.values()) == 2
    )  # the blank is counted too
