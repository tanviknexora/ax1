from openpyxl import load_workbook

from reportkit.cli import main


def test_demo_runs_every_report(tmp_path):
    assert main(["demo", "--out", str(tmp_path)]) == 0
    files = sorted(p.name for p in (tmp_path / "reports").glob("*.xlsx"))
    assert len(files) == 5
    checks = load_workbook(tmp_path / "reports" / "usd_clients_2026-10.xlsx")["Checks"]
    assert checks["A2"].value == "month"


def test_run_reports_a_clear_error(tmp_path, caplog):
    assert main(["run", "usd_clients", "--data-dir", str(tmp_path)]) == 1  # no --month
    assert "monthly report" in caplog.text
