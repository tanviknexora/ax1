"""Shared test helpers: tables written by hand, so every answer is checkable."""

import pandas as pd
import pytest

from reportkit.core.dates import report_timestamp, to_report_time
from reportkit.core.registry import RunContext


def times(*values):
    """Text timestamps -> REPORT_TZ times, exactly as read_input would produce them."""
    return to_report_time(pd.Series(list(values), dtype="object"))


@pytest.fixture
def october():
    return RunContext(
        as_of=report_timestamp("2026-11-16 10:00"), month=pd.Period("2026-10")
    )
