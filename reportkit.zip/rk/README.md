# reportkit

Nexora's business reports, built one consistent way: the call list, USD clients, lead
sources, the broker program, and not-connected leads.

## Set up (once)

    pip install pandas numpy openpyxl pyarrow pytest ruff

## Try it with sample data

    python -m reportkit demo --out reportkit_demo

This writes realistic sample exports to `reportkit_demo/data` and runs every report into
`reportkit_demo/reports`, one Excel workbook each, with a Checks sheet.

## Run on real exports

    python -m reportkit list
    python -m reportkit run call_list --data-dir C:/Users/Administrator/Downloads
    python -m reportkit run usd_clients --month 2026-10 --input ledger=C:/data/ledger.csv

Each report finds the newest file matching its pattern in `--data-dir` (see `list`), or
uses the files you pass with `--input NAME=PATH`. Monthly reports need `--month YYYY-MM`.
Workbooks go to `--out` (default `reports_out`).

## Check the code

    pytest -q          # 16 tests
    ruff check .       # style and common mistakes
    ruff format .      # the standard layout

## Layout

    reportkit/
      settings.py        values every report shares (time zones, labels, Excel formats)
      core/              written once, used by every report
        cleaning.py      IDs and text cleaned the same way everywhere
        dates.py         IST calendar days, month windows, time zones
        result.py        the Report result, reconciliation checks, Total rows
        dsa.py           min-heap sharing, binary-search bands, breadth-first search
        registry.py      input contracts and the list of reports
        io.py            reading inputs against their contracts; styled Excel output
        runner.py        load, build, save, timed
      reports/           one file per report, all built the same way
      demo.py            realistic sample data
      cli.py             the command line
    tests/               every report on tiny hand-written data

Study it with Reportkit_Study_Guide.docx, which walks through every concept in reading order.
