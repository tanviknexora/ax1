"""Day 1 app: summarise client deposits from a CSV file.

What it does:
1. Reads deposits.csv
2. Takes a first look at the data
3. Cleans it: spaces, capitals, dates, duplicates, missing amounts
4. Summarises the deposits per source
5. Saves the summary to deposits_summary.csv
"""

import pandas as pd

# ---- Settings ---------------------------------------------------------------
INPUT_FILE = "deposits.csv"
OUTPUT_FILE = "deposits_summary.csv"


# ---- Steps ------------------------------------------------------------------
def load_data(path):
    """Read the CSV file into a table (a DataFrame)."""
    return pd.read_csv(path)


def explore(df):
    """Print a first look at the data."""
    print("Rows and columns:", df.shape)
    print("Columns:", list(df.columns))
    print("\nFirst 3 rows:")
    print(df.head(3))
    print("\nMissing values per column:")
    print(df.isna().sum())


def clean(df):
    """Fix the usual problems: spaces, capitals, dates, duplicates, missing amounts."""
    df = df.copy()
    df["client_id"] = df["client_id"].str.strip().str.upper()
    df["source"] = df["source"].str.strip()
    df["date"] = pd.to_datetime(df["date"])
    df = df.drop_duplicates()
    df = df.dropna(subset=["amount"])
    return df


def summarise(df):
    """Total, number and average of deposits per source, biggest total first."""
    summary = df.groupby("source")["amount"].agg(["sum", "count", "mean"])
    summary = summary.rename(columns={"sum": "total", "count": "deposits", "mean": "average"})
    summary["average"] = summary["average"].round(2)
    return summary.sort_values("total", ascending=False)


def save(summary, path):
    """Write the summary to a CSV file."""
    summary.to_csv(path)
    print(f"\nSaved {path}")


# ---- Run --------------------------------------------------------------------
def main():
    df = load_data(INPUT_FILE)
    explore(df)

    df = clean(df)
    print(f"\nAfter cleaning: {len(df)} rows")

    summary = summarise(df)
    print("\nDeposits per source:")
    print(summary)
    print(f"\nTotal deposits: {summary['total'].sum():,.2f}")

    save(summary, OUTPUT_FILE)


if __name__ == "__main__":
    main()
