"""Day 1 exercises: solutions (run in the same folder as the app)
Run top to bottom: later tasks use earlier ones."""
# ruff: noqa: E402  (each task imports what it needs, so imports appear mid-file)

# ---- Task 1. Load and clean the data with the app's own functions, and print how many
#      rows remain.
import pandas as pd

from day1_deposits_app import clean, load_data, summarise

df = clean(load_data("deposits.csv"))
print(len(df), "rows")

# ---- Task 2. How many different clients made a deposit?
print(df["client_id"].nunique(), "clients")

# ---- Task 3. What was the largest single deposit, and who made it?
biggest = df.sort_values("amount", ascending=False).iloc[0]
print(biggest["client_id"], biggest["amount"])

# ---- Task 4. Total deposits per client: show the top 3.
per_client = df.groupby("client_id")["amount"].sum().sort_values(ascending=False)
print(per_client.head(3))

# ---- Task 5. How many deposits were 1,000 or more, and what was their total?
big = df[df["amount"] >= 1000]
print(len(big), "deposits, total", big["amount"].sum())

# ---- Task 6. Merge 'Meta 1yt IMR' into 'Meta-IMR', then summarise again.
df["source"] = df["source"].replace({"Meta 1yt IMR": "Meta-IMR"})
print(summarise(df))

# ---- Task 7. Count the deposits per day of the week.
print(df["date"].dt.day_name().value_counts())

# ---- Task 8. Label each deposit 'Big' (1,000 or more) or 'Small', and count each
#      label per source.
df["size"] = (df["amount"] >= 1000).map({True: "Big", False: "Small"})
print(df.groupby(["source", "size"]).size())

# ---- Task 9. Show the biggest deposit per source alongside the total.
print(df.groupby("source")["amount"].agg(["sum", "max"]))

# ---- Task 10. Save the per-client totals to client_totals.csv, read the file back,
#      and check it has one row per client.
per_client.to_csv("client_totals.csv")
check = pd.read_csv("client_totals.csv")
print(len(check), "rows saved |", len(check) == df["client_id"].nunique())
