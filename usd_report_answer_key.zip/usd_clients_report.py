"""USD client report: who trades crypto spot, other USD instruments, or neither.

Reads the trading-customers export and the ledger, classifies every trade by its
instrument, and saves a workbook: a summary of non-overlapping client groups, and
a client list per group.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

OFFICE = Path(r"C:/Users/Administrator/Videos/Office")
if str(OFFICE) not in sys.path:
    sys.path.insert(0, str(OFFICE))
from ledger_loader import get_final_ledger  # noqa: E402  (found through OFFICE above)

log = logging.getLogger(__name__)

# ---- Settings ---------------------------------------------------------------------
DOWNLOADS = Path(r"C:\Users\Administrator\Downloads")
CUSTOMERS_PATTERN = "trading-customers*.csv"
OUT_PATH = DOWNLOADS / "USD_Clients_Report.xlsx"
LEDGER_COLUMNS = ["ClientID", "CreatedAt", "LedgerType", "Debit", "Credit", "Narration"]

TRADE_TYPE = "BILL"
CRYPTO_SPOT = {
    "AAVEUSD",
    "ADAUSD",
    "ALGOUSD",
    "ATOMUSD",
    "AXSUSD",
    "BNBUSD",
    "BTCUSD",
    "DOGEUSD",
    "DOTUSD",
    "ETCUSD",
    "ETHUSD",
    "FILUSD",
    "GRTUSD",
    "ICPUSD",
    "IOTAUSD",
    "LINKUSD",
    "LRCUSD",
    "LTCUSD",
    "MANAUSD",
    "NEARUSD",
    "SOLUSD",
    "TRXUSD",
    "UNIUSD",
    "XRPUSD",
    "ZECUSD",
}  # Official Trump Coin: add its symbol as it appears in the Narration
CRYPTO, OTHER_USD, NOT_USD = "Crypto Spot", "Other USD", "Not USD"

HEADER_FILL = PatternFill("solid", fgColor="FFE699")
MONEY_COLUMNS = ("Debit", "Credit", "Net (Credit - Debit)")
DATE_COLUMNS = ("First Trade", "Last Trade")


# ---- Helpers ----------------------------------------------------------------------
def clean_ids(ids: pd.Series) -> pd.Series:
    """IDs trimmed and upper-cased, so the same client always matches."""
    return ids.astype("string").str.strip().str.upper()


def latest_file(folder: Path, pattern: str) -> Path:
    """The most recently saved file matching pattern."""
    files = list(folder.glob(pattern))
    if not files:
        raise FileNotFoundError(f"no file matching {pattern!r} in {folder}")
    return max(files, key=lambda f: f.stat().st_mtime)


def classify_instruments(instruments: pd.Series) -> pd.Series:
    """Crypto Spot, Other USD or Not USD for each instrument symbol."""
    symbol = instruments.str.strip().str.upper()
    is_usd = symbol.str.contains("USD", regex=False, na=False)
    labels = np.select([symbol.isin(CRYPTO_SPOT), is_usd], [CRYPTO, OTHER_USD], NOT_USD)
    return pd.Series(labels, index=instruments.index)


# ---- Steps ------------------------------------------------------------------------
def load_customer_ids(path: Path) -> set[str]:
    """Every client ID in the trading-customers export."""
    customers = pd.read_csv(path, usecols=["Client ID"])
    return set(clean_ids(customers["Client ID"]).dropna())


def load_trades(customer_ids: set[str]) -> tuple[pd.DataFrame, set[str]]:
    """These customers' trades (BILL rows), classified; and who is in the ledger."""
    ledger = get_final_ledger(as_pandas=True, columns=LEDGER_COLUMNS)
    ledger["ClientID"] = clean_ids(ledger["ClientID"])
    ledger = ledger[ledger["ClientID"].isin(customer_ids)]
    in_ledger = set(ledger["ClientID"])

    trades = ledger[
        ledger["LedgerType"].astype(str).str.strip().str.upper().eq(TRADE_TYPE)
    ]
    instrument = trades["Narration"].str.rsplit(n=1).str[-1]
    trades = trades.assign(
        CreatedAt=pd.to_datetime(trades["CreatedAt"], format="ISO8601"),
        Instrument=instrument,
        USD_Class=classify_instruments(instrument),
    )
    return trades, in_ledger


def client_groups(trades: pd.DataFrame, in_ledger: set[str]) -> dict[str, set[str]]:
    """Every ledger client in exactly one group."""
    crypto = set(trades.loc[trades["USD_Class"].eq(CRYPTO), "ClientID"])
    other = set(trades.loc[trades["USD_Class"].eq(OTHER_USD), "ClientID"])
    traded = set(trades["ClientID"])
    return {
        "Crypto Spot only": crypto - other,
        "Other USD only": other - crypto,
        "Both Crypto Spot and Other USD": crypto & other,
        "Non-USD trades only": traded - crypto - other,
        "No trades": in_ledger - traded,
    }


def group_summary(groups: dict[str, set[str]], expected_total: int) -> pd.DataFrame:
    """Clients per group with a Total row; stops if the groups don't add up."""
    summary = pd.DataFrame(
        {"Group": list(groups), "Clients": [len(ids) for ids in groups.values()]}
    )
    total = int(summary["Clients"].sum())
    if total != expected_total:
        raise ValueError(f"groups hold {total} clients, expected {expected_total}")
    summary.loc[len(summary)] = ["Total", total]
    return summary


def client_table(client_ids: set[str], trades: pd.DataFrame) -> pd.DataFrame:
    """One row per client: trades, instruments, money, first and last trade."""
    rows = trades[trades["ClientID"].isin(client_ids)]
    table = (
        rows.groupby("ClientID")
        .agg(
            Trades=("ClientID", "size"),
            Instruments=(
                "Instrument",
                lambda s: ", ".join(sorted(s.dropna().unique())),
            ),
            Debit=("Debit", "sum"),
            Credit=("Credit", "sum"),
            First_Trade=("CreatedAt", "min"),
            Last_Trade=("CreatedAt", "max"),
        )
        .reindex(sorted(client_ids))
    )
    table[["Debit", "Credit"]] = table[["Debit", "Credit"]].fillna(0)
    table["Trades"] = table["Trades"].fillna(0).astype(int)
    table["Instruments"] = table["Instruments"].fillna("")
    table.insert(4, "Net (Credit - Debit)", table["Credit"] - table["Debit"])
    table = table.rename(
        columns={"First_Trade": "First Trade", "Last_Trade": "Last Trade"}
    )
    return (
        table.sort_values("Trades", ascending=False)
        .rename_axis("ClientID")
        .reset_index()
    )


def write_sheet(writer: pd.ExcelWriter, table: pd.DataFrame, name: str) -> None:
    """One table, with a highlighted header, sized columns and number formats."""
    table.to_excel(writer, sheet_name=name, index=False)
    ws = writer.sheets[name]
    for j, col in enumerate(table.columns, start=1):
        ws.cell(1, j).font = Font(bold=True)
        ws.cell(1, j).fill = HEADER_FILL
        longest = table[col].astype(str).str.len().max() if len(table) else 0
        ws.column_dimensions[get_column_letter(j)].width = min(
            max(len(col), longest) + 2, 60
        )
        fmt = (
            "#,##0.00;[Red]-#,##0.00"
            if col in MONEY_COLUMNS
            else "dd-mmm-yyyy hh:mm"
            if col in DATE_COLUMNS
            else None
        )
        if fmt:
            for r in range(2, len(table) + 2):
                ws.cell(r, j).number_format = fmt
    ws.freeze_panes = "A2"


# ---- Entry point ------------------------------------------------------------------
def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    customers_path = latest_file(DOWNLOADS, CUSTOMERS_PATTERN)
    customer_ids = load_customer_ids(customers_path)
    trades, in_ledger = load_trades(customer_ids)
    log.info(
        "%s: %d customers, %d with ledger rows, %d trades",
        customers_path.name,
        len(customer_ids),
        len(in_ledger),
        len(trades),
    )

    groups = client_groups(trades, in_ledger)
    summary = group_summary(groups, expected_total=len(in_ledger))
    sheets = {"Summary": summary}
    sheets.update({name: client_table(ids, trades) for name, ids in groups.items()})

    with pd.ExcelWriter(OUT_PATH, engine="openpyxl") as writer:
        for name, table in sheets.items():
            write_sheet(writer, table, name[:31])  # Excel sheet names: 31 characters
    log.info("Saved %s", OUT_PATH)
    log.info("\n%s", summary.to_string(index=False))


if __name__ == "__main__":
    main()
