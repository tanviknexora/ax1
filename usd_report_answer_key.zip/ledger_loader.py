"""Stand-in for the real ledger_loader, for testing only."""
import numpy as np
import pandas as pd


def get_final_ledger(as_pandas=True, columns=None):
    rng = np.random.default_rng(8)
    n = 4000
    inst = rng.choice(["BTCUSD", "ETHUSD", "XAUUSD", "EURUSD", "NIFTY26N1725250CE"], n)
    kind = rng.choice(["BILL", "DEPOSIT"], n, p=[0.85, 0.15])
    clients = [f"C{i}" for i in range(300)]
    df = pd.DataFrame({
        "ClientID": rng.choice(clients, n),
        "CreatedAt": (pd.Timestamp("2026-11-01")
                      + pd.to_timedelta(rng.integers(0, 15 * 1440, n), unit="min")).astype(str),
        "LedgerType": kind,
        "Debit": rng.integers(0, 3000, n).astype(float),
        "Credit": rng.integers(0, 3000, n).astype(float),
        "Narration": np.where(kind == "BILL", "Trade bill for " + inst, "Deposit ref USDT 99"),
    })
    # client C299 only ever deposits; C0 has a stray space
    df.loc[df["ClientID"].eq("C299"), "LedgerType"] = "DEPOSIT"
    df.loc[df.index[:5], "ClientID"] = " c0"
    return df[columns] if columns else df
