import pandas as pd
import pytest

from usd_clients_report import classify_instruments, client_groups, group_summary


def test_classify_handles_case_spaces_and_blanks():
    s = pd.Series(["BTCUSD", " ethusd", "XAUUSD", "NIFTY26N1725250CE", None])
    assert classify_instruments(s).tolist() == [
        "Crypto Spot",
        "Crypto Spot",
        "Other USD",
        "Not USD",
        "Not USD",
    ]


def test_every_client_is_in_exactly_one_group():
    trades = pd.DataFrame(
        {
            "ClientID": ["A", "A", "B", "C", "D"],
            "USD_Class": [
                "Crypto Spot",
                "Other USD",
                "Crypto Spot",
                "Not USD",
                "Other USD",
            ],
        }
    )
    groups = client_groups(trades, in_ledger={"A", "B", "C", "D", "E"})
    assert groups["Both Crypto Spot and Other USD"] == {"A"}
    assert groups["No trades"] == {"E"}
    members = [c for ids in groups.values() for c in ids]
    assert sorted(members) == ["A", "B", "C", "D", "E"]


def test_summary_stops_when_groups_do_not_add_up():
    with pytest.raises(ValueError, match="expected 3"):
        group_summary({"Some": {"A", "B"}}, expected_total=3)
