@echo off
REM Double-click to start: every Win+Shift+S snip is added to one Excel sheet.
REM Keep this .bat in the same folder as screenshot_to_excel.py
cd /d "%~dp0"
python screenshot_to_excel.py --watch
pause
