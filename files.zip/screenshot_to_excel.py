#!/usr/bin/env python3
"""
screenshot_to_excel.py
======================
Take a screenshot of a table (or use screenshots you already have) and turn it
into an Excel workbook: one sheet per screenshot, numbers stored as real numbers,
low-confidence OCR cells highlighted for review, and the original screenshot
embedded next to the data so you can check it side by side.

SETUP (once)
------------
1. Install the Tesseract OCR engine (the program, not just the Python package):
     Windows : install the UB Mannheim build of Tesseract (default path
               C:\\Program Files\\Tesseract-OCR\\tesseract.exe is auto-detected)
     macOS   : brew install tesseract
     Linux   : sudo apt install tesseract-ocr
2. Install the Python packages:
     pip install mss pillow pytesseract openpyxl

USAGE
-----
  python screenshot_to_excel.py                      # convert every image in INPUT_FOLDER -> OUTPUT_FOLDER
  python screenshot_to_excel.py --keep --open        # same, but leave the images in place and open Excel
  python screenshot_to_excel.py --watch              # keep running: every Win+Shift+S snip -> one sheet
  python screenshot_to_excel.py --capture            # 3-second countdown, then drag a box around a table
  python screenshot_to_excel.py --capture --multi    # capture several tables into one workbook
  python screenshot_to_excel.py --capture --full     # whole screen, no selection
  python screenshot_to_excel.py --capture --monitor 2
  python screenshot_to_excel.py --clipboard          # use an image you copied (e.g. Win+Shift+S)
  python screenshot_to_excel.py --images shot1.png shots_folder/
  python screenshot_to_excel.py -o deposits.xlsx --append --open

Tuning when columns come out wrong:
  --debug          saves an annotated image showing the detected cells and column borders
  --word-gap 0.5   lower  = split cells more readily (columns packed tightly together)
  --word-gap 1.2   higher = keep multi-word values together (e.g. "Client Name" split in two)
  --scale 3        upscale more for very small fonts
  --psm 11         try this if some cells in a sparse table are missed

Dates written like 2026-11-24, 2026.11.24 09:15, 24-Nov-2026 or 24/11/2026 become real
Excel dates (slashed dates are read day-first unless you pass --month-first).
"""

import argparse
import ctypes
import hashlib
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from statistics import median

from PIL import Image, ImageDraw, ImageEnhance, ImageGrab, ImageOps, ImageStat

try:
    import pytesseract
except ImportError:
    sys.exit("Missing package: run  pip install pytesseract")
try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.drawing.image import Image as XLImage
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
except ImportError:
    sys.exit("Missing package: run  pip install openpyxl")

# ---- YOUR FOLDERS: change these three lines if you move things --------------
INPUT_FOLDER = r"C:\Users\Administrator\Videos\Office\Image"    # put screenshots here
OUTPUT_FOLDER = r"C:\Users\Administrator\Videos\Office\Excel"   # Excel files are saved here
DONE_FOLDER = os.path.join(INPUT_FOLDER, "done")                   # converted images are moved here
# ---------------------------------------------------------------------------

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp", ".gif"}
HEADER_FILL = PatternFill("solid", fgColor="1F3864")
LOWCONF_FILL = PatternFill("solid", fgColor="FFF2CC")


# --------------------------------------------------------------------------- setup
def make_dpi_aware():
    """On Windows with display scaling (125%, 150%...), make screen coordinates real pixels."""
    if sys.platform != "win32":
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def configure_tesseract(cmd=None):
    if cmd:
        pytesseract.pytesseract.tesseract_cmd = cmd
    elif not shutil.which("tesseract"):
        candidates = [
            r"C:\Program Files\Tesseract-OCR\tesseract.exe",
            r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"),
            "/opt/homebrew/bin/tesseract",
            "/usr/local/bin/tesseract",
        ]
        found = next((c for c in candidates if os.path.isfile(c)), None)
        if not found:
            sys.exit(
                "Tesseract OCR engine not found.\n"
                "  Windows: install the UB Mannheim build of Tesseract, or pass --tesseract-cmd <path to tesseract.exe>\n"
                "  macOS:   brew install tesseract\n"
                "  Linux:   sudo apt install tesseract-ocr"
            )
        pytesseract.pytesseract.tesseract_cmd = found
    try:
        pytesseract.get_tesseract_version()
    except Exception as exc:
        sys.exit(f"Tesseract could not be started: {exc}")


# --------------------------------------------------------------------------- capture
def grab_monitor(index):
    try:
        import mss
    except ImportError:
        sys.exit("Missing package: run  pip install mss")
    with mss.mss() as sct:
        if index < 1 or index >= len(sct.monitors):
            sys.exit(f"Monitor {index} not found. Available: 1..{len(sct.monitors) - 1}")
        mon = dict(sct.monitors[index])
        shot = sct.grab(mon)
        img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
    return img, mon


def select_region(img, mon):
    """Show the screenshot full-screen (dimmed) and let the user drag a box. Returns cropped image or None."""
    import tkinter as tk
    from PIL import ImageTk

    w, h = mon["width"], mon["height"]
    root = tk.Tk()
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    root.geometry(f"{w}x{h}+{mon['left']}+{mon['top']}")

    display = img.resize((w, h), Image.LANCZOS) if img.size != (w, h) else img
    photo = ImageTk.PhotoImage(ImageEnhance.Brightness(display).enhance(0.55))
    canvas = tk.Canvas(root, width=w, height=h, highlightthickness=0, cursor="crosshair")
    canvas.pack(fill="both", expand=True)
    canvas.create_image(0, 0, image=photo, anchor="nw")
    canvas.create_text(w // 2, 32, fill="white", font=("Segoe UI", 16, "bold"),
                       text="Drag a box around the table  \u00B7  Esc or right-click to cancel")

    state = {"start": None, "rect": None, "box": None}

    def on_press(e):
        state["start"] = (e.x, e.y)
        if state["rect"]:
            canvas.delete(state["rect"])
        state["rect"] = canvas.create_rectangle(e.x, e.y, e.x, e.y, outline="#FF3B30", width=2)

    def on_drag(e):
        if state["start"]:
            canvas.coords(state["rect"], *state["start"], e.x, e.y)

    def on_release(e):
        if not state["start"]:
            return
        x0, y0 = state["start"]
        box = (min(x0, e.x), min(y0, e.y), max(x0, e.x), max(y0, e.y))
        if box[2] - box[0] > 5 and box[3] - box[1] > 5:
            state["box"] = box
            root.destroy()

    canvas.bind("<ButtonPress-1>", on_press)
    canvas.bind("<B1-Motion>", on_drag)
    canvas.bind("<ButtonRelease-1>", on_release)
    canvas.bind("<Button-3>", lambda e: root.destroy())  # right-click (Windows/Linux)
    canvas.bind("<Button-2>", lambda e: root.destroy())  # right-click on macOS
    root.bind("<Escape>", lambda e: root.destroy())
    root.focus_force()
    root.mainloop()

    if not state["box"]:
        return None
    sx, sy = img.width / w, img.height / h  # handles Retina / scaled displays
    x0, y0, x1, y1 = state["box"]
    return img.crop((int(x0 * sx), int(y0 * sy), int(x1 * sx), int(y1 * sy)))


def image_from_clipboard():
    data = ImageGrab.grabclipboard()
    if isinstance(data, Image.Image):
        return data.convert("RGB")
    if isinstance(data, list):  # files copied in Explorer/Finder
        for f in data:
            if Path(f).suffix.lower() in IMAGE_EXTS:
                return Image.open(f).convert("RGB")
    return None


def expand_image_paths(items):
    paths = []
    for item in items:
        p = Path(item)
        if p.is_dir():
            paths += sorted(x for x in p.iterdir() if x.suffix.lower() in IMAGE_EXTS)
        elif p.is_file():
            paths.append(p)
        else:
            print(f"  ! Skipping (not found): {item}")
    return paths


# --------------------------------------------------------------------------- OCR
def preprocess(img, scale):
    gray = ImageOps.grayscale(img)
    if ImageStat.Stat(gray).mean[0] < 110:  # dark theme (trading terminals etc.) -> invert
        gray = ImageOps.invert(gray)
    gray = ImageOps.autocontrast(gray)
    if scale != 1:
        gray = gray.resize((int(gray.width * scale), int(gray.height * scale)), Image.LANCZOS)
    return gray


def pixels(im):
    """Pixel values as a flat list (works on old and new Pillow versions)."""
    return list(im.get_flattened_data() if hasattr(im, "get_flattened_data") else im.getdata())


def find_rules(gray, scale):
    """Find thin table gridlines. Returns (vertical runs, horizontal runs, background value)."""
    hist = gray.histogram()
    bg = max(range(256), key=hist.__getitem__)
    ink = gray.point(lambda v: 255 if abs(v - bg) > 25 else 0)
    max_thickness = max(4, int(3 * scale))

    def runs(profile, frac=0.75):
        found, start = [], None
        for i, v in enumerate(profile + [0]):
            if v >= frac * 255 and start is None:
                start = i
            elif v < frac * 255 and start is not None:
                if i - start <= max_thickness:  # thin = a rule; thick = a filled header band, keep it
                    found.append((start, i - 1))
                start = None
        return found

    vertical = runs(pixels(ink.resize((gray.width, 1), Image.BOX)))
    horizontal = runs(pixels(ink.resize((1, gray.height), Image.BOX)))
    return vertical, horizontal, bg


def erase_rules(gray, vertical, horizontal, bg):
    out = gray.copy()
    d = ImageDraw.Draw(out)
    for a, b in vertical:
        d.rectangle([a - 1, 0, b + 1, out.height], fill=bg)
    for a, b in horizontal:
        d.rectangle([0, a - 1, out.width, b + 1], fill=bg)
    return out


def ocr_words(img, lang, psm, x_offset=0, col=None, pad=12):
    fill = max(range(256), key=img.histogram().__getitem__)
    padded = ImageOps.expand(img, border=pad, fill=fill)  # Tesseract reads edge text better with a margin
    data = pytesseract.image_to_data(
        padded, lang=lang, config=f"--oem 3 --psm {psm}", output_type=pytesseract.Output.DICT
    )
    words = []
    for i, text in enumerate(data["text"]):
        text = (text or "").strip()
        conf = float(data["conf"][i])
        if data["level"][i] != 5 or not text or conf < 0:
            continue
        if not re.search(r"[0-9A-Za-z\u00C0-\uFFFF%$\u20AC\u00A3]", text):  # drop pure noise like "|", "_"
            continue
        x0, y0 = data["left"][i] - pad + x_offset, data["top"][i] - pad
        words.append({
            "text": text, "x0": x0, "y0": y0, "x1": x0 + data["width"][i], "y1": y0 + data["height"][i],
            "conf": conf, "col": col,
        })
    return words


def group_lines(words, line_tol):
    """Cluster words into text rows by their vertical centres."""
    if not words:
        return [], 0
    med_h = median(w["y1"] - w["y0"] for w in words)
    lines = []
    for w in sorted(words, key=lambda w: (w["y0"] + w["y1"]) / 2):
        cy = (w["y0"] + w["y1"]) / 2
        if lines and abs(cy - lines[-1]["cy"]) <= line_tol * med_h:
            ln = lines[-1]
            ln["words"].append(w)
            ln["cy"] = sum((x["y0"] + x["y1"]) / 2 for x in ln["words"]) / len(ln["words"])
        else:
            lines.append({"cy": cy, "words": [w]})
    return [sorted(ln["words"], key=lambda w: w["x0"]) for ln in lines], med_h


def words_to_cells(line, med_h, word_gap):
    """Join neighbouring words into one cell when the gap between them looks like a normal space."""
    cells = []
    for w in line:
        if cells and w["col"] == cells[-1]["col"] and w["x0"] - cells[-1]["x1"] <= word_gap * med_h:
            c = cells[-1]
            c["text"] += " " + w["text"]
            c["x1"] = max(c["x1"], w["x1"])
            c["conf"] = min(c["conf"], w["conf"])
        else:
            cells.append(dict(w))
    return cells


def find_columns(rows, width, med_h, tolerance):
    """Column = horizontal band covered by cells in most rows; a gap = x positions almost no row covers."""
    if not rows:
        return []
    coverage = [0] * (width + 1)
    for cells in rows:
        for c in cells:
            for x in range(max(0, c["x0"]), min(width, c["x1"]) + 1):
                coverage[x] += 1
    limit = int(len(rows) * tolerance)  # tolerate a few spanning titles/notes
    spans, start = [], None
    for x, n in enumerate(coverage):
        if n > limit and start is None:
            start = x
        elif n <= limit and start is not None:
            spans.append([start, x - 1])
            start = None
    if start is not None:
        spans.append([start, width])
    merged = []  # ignore hairline gaps
    for s in spans:
        if merged and s[0] - merged[-1][1] < 0.3 * med_h:
            merged[-1][1] = s[1]
        else:
            merged.append(s)
    return merged or [[0, width]]


def assign_to_grid(rows, columns):
    grid, confs = [], []
    for cells in rows:
        texts, cfs = [""] * len(columns), [100.0] * len(columns)
        for c in cells:
            overlaps = [max(0, min(c["x1"], b) - max(c["x0"], a)) for a, b in columns]
            if c["col"] is not None:
                j = c["col"]
            elif max(overlaps) > 0:
                j = overlaps.index(max(overlaps))
            else:
                cx = (c["x0"] + c["x1"]) / 2
                j = min(range(len(columns)), key=lambda k: abs(cx - (columns[k][0] + columns[k][1]) / 2))
            texts[j] = (texts[j] + " " + c["text"]).strip()
            cfs[j] = min(cfs[j], c["conf"])
        if any(texts):
            grid.append(texts)
            confs.append(cfs)
    # drop columns that ended up completely empty
    keep = [j for j in range(len(columns)) if any(r[j] for r in grid)]
    return [[r[j] for j in keep] for r in grid], [[r[j] for j in keep] for r in confs]


def extract_table(img, args, debug_path=None):
    proc = preprocess(img, args.scale)
    vertical, horizontal = [], []
    if not args.no_grid:
        vertical, horizontal, bg = find_rules(proc, args.scale)
        if vertical or horizontal:
            proc = erase_rules(proc, vertical, horizontal, bg)

    if vertical:
        # Gridlines present: OCR each column strip separately so tight columns can't run together
        cuts = [0] + [(a + b) // 2 for a, b in vertical] + [proc.width]
        columns = [(a, b) for a, b in zip(cuts, cuts[1:])]
        words = []
        for j, (a, b) in enumerate(columns):
            if b - a >= 8:
                words += ocr_words(proc.crop((a, 0, b, proc.height)), args.lang, args.psm, x_offset=a, col=j)
        lines, med_h = group_lines(words, args.line_tol)
        rows = [words_to_cells(ln, med_h, args.word_gap) for ln in lines]
    else:
        words = ocr_words(proc, args.lang, args.psm)
        lines, med_h = group_lines(words, args.line_tol)
        rows = [words_to_cells(ln, med_h, args.word_gap) for ln in lines]
        columns = find_columns(rows, proc.width, med_h, args.col_tolerance)
    grid, confs = assign_to_grid(rows, columns)
    if debug_path:
        dbg = proc.convert("RGB")
        d = ImageDraw.Draw(dbg)
        for a, b in vertical:
            d.line([(a + b) // 2, 0, (a + b) // 2, dbg.height], fill=(0, 170, 0), width=2)
        for a, b in columns:
            d.rectangle([a, 0, b, dbg.height - 1], outline=(220, 0, 0), width=2)
        for cells in rows:
            for c in cells:
                colour = (0, 90, 255) if c["conf"] >= args.min_conf else (255, 150, 0)
                d.rectangle([c["x0"], c["y0"], c["x1"], c["y1"]], outline=colour, width=2)
        dbg.save(debug_path)
    return grid, confs


# --------------------------------------------------------------------------- values
NUM_RE = re.compile(r"^[+-]?(\d{1,3}(,\d{3})+|\d+)?(\.\d+)?$")


DATE_FORMATS = [  # (strptime pattern, Excel number format)
    ("%Y-%m-%d %H:%M:%S", "yyyy-mm-dd hh:mm:ss"), ("%Y-%m-%d %H:%M", "yyyy-mm-dd hh:mm"), ("%Y-%m-%d", "yyyy-mm-dd"),
    ("%Y.%m.%d %H:%M:%S", "yyyy-mm-dd hh:mm:ss"), ("%Y.%m.%d %H:%M", "yyyy-mm-dd hh:mm"), ("%Y.%m.%d", "yyyy-mm-dd"),
    ("%d-%b-%Y", "dd-mmm-yyyy"), ("%d %b %Y", "dd-mmm-yyyy"), ("%b %d, %Y", "dd-mmm-yyyy"),
]
SLASH_FORMATS = [("%d/%m/%Y %H:%M:%S", "dd/mm/yyyy hh:mm:ss"), ("%d/%m/%Y %H:%M", "dd/mm/yyyy hh:mm"), ("%d/%m/%Y", "dd/mm/yyyy")]


def to_date(s, month_first=False):
    formats = DATE_FORMATS + [
        (f.replace("%d/%m", "%m/%d"), x.replace("dd/mm", "mm/dd")) if month_first else (f, x) for f, x in SLASH_FORMATS
    ]
    for pattern, excel_fmt in formats:
        try:
            return datetime.strptime(s, pattern), excel_fmt
        except ValueError:
            continue
    return None


def to_value(text, month_first=False):
    """'1,234.50' -> 1234.5 ; '(250.00)' -> -250 ; '12.5%' -> 0.125 ; dates -> real dates ; '00123' stays text."""
    s = text.strip()
    raw = s
    as_date = to_date(s, month_first)
    if as_date:
        return as_date
    negative = s.startswith("(") and s.endswith(")")
    if negative:
        s = s[1:-1].strip()
    s = re.sub(r"^(USD|AED|EUR|GBP|INR|[$\u20AC\u00A3\u20B9\u00A5])\s*", "", s, flags=re.I)
    s = re.sub(r"\s*(USD|AED|EUR|GBP|INR)$", "", s, flags=re.I)
    percent = s.endswith("%")
    if percent:
        s = s[:-1].strip()
    s = s.replace("\u2212", "-")  # unicode minus
    if not s or not NUM_RE.match(s) or not re.search(r"\d", s):
        return raw, None
    digits = s.lstrip("+-").replace(",", "")
    if (len(digits) > 1 and digits.startswith("0") and "." not in digits) or len(digits.replace(".", "")) > 15:
        return raw, None  # account numbers, IDs with leading zeros, very long numbers
    number = float(digits) * (-1 if s.startswith("-") or negative else 1)
    decimals = len(digits.split(".")[1]) if "." in digits else 0
    if percent:
        return number / 100, "0." + "0" * decimals + "%" if decimals else "0%"
    if decimals == 0:
        number = int(number)
    base = "#,##0" if "," in s else "0"  # no separators in the source (tickets, IDs) -> none added
    return number, base + ("." + "0" * decimals if decimals else "")


# --------------------------------------------------------------------------- Excel
def unique_sheet_name(wb, name):
    name = re.sub(r"[\[\]:*?/\\]", "_", name)[:27] or "Sheet"
    candidate, n = name, 2
    while candidate in wb.sheetnames:
        candidate, n = f"{name}_{n}", n + 1
    return candidate


def write_sheet(wb, name, grid, confs, args, image_path):
    ws = wb.create_sheet(unique_sheet_name(wb, name))
    low = 0
    for r, (row, crow) in enumerate(zip(grid, confs), start=1):
        for c, (text, conf) in enumerate(zip(row, crow), start=1):
            if not text:
                continue
            is_header = (r == 1 and not args.no_header)
            value, fmt = (text, None) if is_header else to_value(text, args.month_first)
            cell = ws.cell(row=r, column=c, value=value)
            if fmt:
                cell.number_format = fmt
            if is_header:
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = HEADER_FILL
                cell.alignment = Alignment(vertical="center", wrap_text=True)
            elif conf < args.min_conf:
                cell.fill = LOWCONF_FILL
                low += 1
    ncols = max((len(r) for r in grid), default=0)
    for c in range(1, ncols + 1):
        longest = max((len(str(r[c - 1])) for r in grid if c - 1 < len(r)), default=8)
        ws.column_dimensions[get_column_letter(c)].width = min(max(10, longest + 2), 60)
    if not args.no_header and grid:
        ws.freeze_panes = "A2"
    if image_path and not args.no_embed:
        anchor = get_column_letter(ncols + 2) + "1"
        pic = XLImage(str(image_path))
        if pic.width > 1200:  # keep the embedded picture a sensible size
            ratio = 1200 / pic.width
            pic.width, pic.height = int(pic.width * ratio), int(pic.height * ratio)
        ws.add_image(pic, anchor)
    return ws, low


def write_info_sheet(wb, log):
    if "Info" in wb.sheetnames:
        ws = wb["Info"]
    else:
        ws = wb.create_sheet("Info", 0)
        ws.append(["Sheet", "Source", "Captured", "Rows", "Columns", "Low-confidence cells"])
        for cell in ws[1]:
            cell.font = Font(bold=True)
    for entry in log:
        ws.append(entry)
    for col, width in zip("ABCDEF", (24, 60, 20, 8, 9, 20)):
        ws.column_dimensions[col].width = width


# --------------------------------------------------------------------------- watch mode
def _norm(row):
    cells = [re.sub(r"\W+", "", str(v or "")).lower() for v in row]
    while cells and not cells[-1]:
        cells.pop()
    return cells


def same_header(a, b):
    """True when two header rows are the same table (tolerates small OCR differences)."""
    a, b = _norm(a or []), _norm(b or [])
    if not a or not b or len(a) != len(b):
        return False
    return sum(x == y for x, y in zip(a, b)) >= 0.8 * len(a)


def last_header(ws):
    """Return (header values, row number) of the last table block in the sheet."""
    for r in range(ws.max_row, 0, -1):
        cell = ws.cell(r, 1)
        if cell.value is not None and cell.font is not None and cell.font.bold:
            return [ws.cell(r, c).value for c in range(1, ws.max_column + 1)], r
    return None, 0


def row_key(values):
    """Comparable fingerprint of a row, so overlapping snips don't add the same row twice."""
    out = []
    for v in values:
        if isinstance(v, float) and v.is_integer():
            v = int(v)
        out.append(re.sub(r"\s+", "", str(v if v is not None else "")).lower())
    while out and not out[-1]:
        out.pop()
    return tuple(out)


def append_snip(ws, grid, confs, args, state):
    """Add one snip's rows under the existing data. A repeated header is skipped;
    a different header starts a new block after a blank row."""
    rows, crows = grid, confs
    if not args.no_header:
        header, rows, crows = grid[0], grid[1:], confs[1:]
        if not same_header(header, state["header"]):
            if state["next_row"] > 1:
                state["next_row"] += 1  # blank row between different tables
            for c, text in enumerate(header, start=1):
                cell = ws.cell(state["next_row"], c, text or None)
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = HEADER_FILL
            state["header"] = header
            state["seen"] = set()  # new table block -> new duplicate check
            state["next_row"] += 1
    low = skipped = added = 0
    for row, crow in zip(rows, crows):
        converted = [to_value(text, args.month_first) if text else (None, None) for text in row]
        key = row_key([v for v, _ in converted])
        if not args.keep_duplicates and key in state["seen"]:
            skipped += 1
            continue
        state["seen"].add(key)
        added += 1
        for c, ((value, fmt), conf) in enumerate(zip(converted, crow), start=1):
            if value is None:
                continue
            cell = ws.cell(state["next_row"], c, value)
            if fmt:
                cell.number_format = fmt
            if conf < args.min_conf:
                cell.fill = LOWCONF_FILL
                low += 1
        state["next_row"] += 1
    for c in range(1, ws.max_column + 1):  # widen columns to fit
        letter = get_column_letter(c)
        longest = max((len(str(ws.cell(r, c).value or "")) for r in range(1, ws.max_row + 1)), default=8)
        ws.column_dimensions[letter].width = min(max(10, longest + 2), 60)
    return added, skipped, low


def watch_clipboard(args, out):
    """Keep running: every Win+Shift+S snip is OCR'd and appended to one sheet."""
    if out.exists():
        wb = load_workbook(out)
        ws = wb["Data"] if "Data" in wb.sheetnames else wb.create_sheet("Data")
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = "Data"
    has_data = ws.max_row > 1 or ws.cell(1, 1).value is not None
    header, header_row = last_header(ws) if has_data else (None, 0)
    seen = {row_key([ws.cell(r, c).value for c in range(1, ws.max_column + 1)])
            for r in range(header_row + 1, ws.max_row + 1)} if has_data else set()
    state = {"header": header, "seen": seen, "dirty": False,
             "next_row": ws.max_row + 1 if has_data else 1}
    shots_dir = out.parent / f"{out.stem}_screenshots"
    shots_dir.mkdir(parents=True, exist_ok=True)

    def try_save():
        try:
            wb.save(out)
            state["dirty"] = False
            return True
        except PermissionError:
            print("  ! Can't save: the workbook is open in Excel. Close it and the data will be saved automatically.")
            return False

    def current_clipboard_image():
        try:
            data = ImageGrab.grabclipboard()
        except Exception:  # clipboard busy for a moment
            return None
        return data if isinstance(data, Image.Image) else None

    def fingerprint(img):
        return hashlib.md5(img.tobytes()).hexdigest()

    first = current_clipboard_image()
    last_seen = fingerprint(first) if first is not None else None  # ignore whatever was already copied
    total_snips = total_rows = 0
    print(f"Watching the clipboard. Press Win+Shift+S and snip a table.\n"
          f"Rows go to: {out}  (sheet 'Data')\nPress Ctrl+C here to stop.\n")
    try:
        while True:
            time.sleep(args.poll)
            if state["dirty"]:
                try_save()
            img = current_clipboard_image()
            if img is None:
                continue
            fp = fingerprint(img)
            if fp == last_seen:
                continue
            last_seen = fp
            img = img.convert("RGB")
            name = "Snip_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
            img.save(shots_dir / f"{name}.png")
            grid, confs = extract_table(img, args)
            if not grid:
                print(f"- {name}: no text found, skipped")
                continue
            added, skipped, low = append_snip(ws, grid, confs, args, state)
            total_snips += 1
            total_rows += added
            state["dirty"] = True
            saved = try_save()
            print(f"- {name}: +{added} rows"
                  + (f", {skipped} duplicate rows skipped" if skipped else "")
                  + (f", {low} cells to check (yellow)" if low else "")
                  + ("" if saved else "  [not saved yet]"))
            if sys.platform == "win32":
                try:
                    import winsound
                    winsound.MessageBeep()
                except Exception:
                    pass
    except KeyboardInterrupt:
        print("\nStopping...")
    while state["dirty"] and not try_save():
        input("  Close the workbook in Excel, then press Enter to save... ")
    print(f"Done: {total_snips} snips, {total_rows} rows -> {out}")
    if args.open:
        open_file(out)


def open_file(path):
    try:
        if sys.platform == "win32":
            os.startfile(path)  # noqa: S606
        elif sys.platform == "darwin":
            subprocess.run(["open", str(path)], check=False)
        else:
            subprocess.run(["xdg-open", str(path)], check=False)
    except Exception as exc:
        print(f"  (could not open automatically: {exc})")


# --------------------------------------------------------------------------- main
def parse_args():
    ap = argparse.ArgumentParser(description="Screenshot a table and convert it to an Excel workbook.")
    src = ap.add_mutually_exclusive_group()
    src.add_argument("--images", nargs="+", metavar="PATH", help="existing image files and/or folders")
    src.add_argument("--clipboard", action="store_true", help="use the image currently on the clipboard")
    src.add_argument("--capture", action="store_true", help="take a new screenshot instead of reading INPUT_FOLDER")
    src.add_argument("--watch", action="store_true",
                     help="keep running; every Win+Shift+S snip is appended to ONE sheet")
    ap.add_argument("--full", action="store_true", help="capture the whole monitor (no drag selection)")
    ap.add_argument("--monitor", type=int, default=1, help="monitor number (default 1 = primary)")
    ap.add_argument("--delay", type=float, default=3, help="seconds to wait before capturing (default 3)")
    ap.add_argument("--multi", action="store_true", help="keep capturing tables into the same workbook")
    ap.add_argument("-o", "--out", help="output .xlsx (default: screenshots_YYYYMMDD_HHMMSS.xlsx)")
    ap.add_argument("--append", action="store_true", help="add sheets to --out if it already exists")
    ap.add_argument("--csv", action="store_true", help="also write one CSV per table")
    ap.add_argument("--open", action="store_true", help="open the workbook when done")
    ap.add_argument("--poll", type=float, default=1.0, help="watch mode: seconds between clipboard checks")
    ap.add_argument("--keep-duplicates", action="store_true",
                    help="watch mode: keep rows that are identical to a row already in the same table")
    ap.add_argument("--keep", action="store_true", help="leave converted images in INPUT_FOLDER (don't move to done)")
    ap.add_argument("--no-header", action="store_true", help="do not treat the first row as a header")
    ap.add_argument("--month-first", action="store_true", help="read 03/04/2026 as 4 March (default: 3 April)")
    ap.add_argument("--no-embed", action="store_true", help="do not embed the screenshot in the sheet")
    ap.add_argument("--debug", action="store_true", help="save an annotated image of detected cells/columns")
    ap.add_argument("--no-grid", action="store_true", help="ignore table gridlines when finding columns")
    ap.add_argument("--lang", default="eng", help="Tesseract language(s), e.g. eng or eng+ara")
    ap.add_argument("--psm", type=int, default=6, help="Tesseract page segmentation mode (default 6; try 11 for sparse tables)")
    ap.add_argument("--scale", type=float, default=2.0, help="upscale factor before OCR (default 2)")
    ap.add_argument("--word-gap", type=float, default=0.75, help="max gap (x text height) to join words into one cell")
    ap.add_argument("--line-tol", type=float, default=0.5, help="row grouping tolerance (x text height)")
    ap.add_argument("--col-tolerance", type=float, default=0.1, help="share of rows allowed to cross a column gap")
    ap.add_argument("--min-conf", type=float, default=60, help="highlight cells below this OCR confidence")
    ap.add_argument("--tesseract-cmd", help="full path to the tesseract executable")
    return ap.parse_args()


def capture_screen(args):
    if args.delay > 0:
        for s in range(int(args.delay), 0, -1):
            print(f"  Switch to the window with the table... capturing in {s}", end="\r", flush=True)
            time.sleep(1)
        time.sleep(args.delay - int(args.delay))
        print(" " * 70, end="\r")
    img, mon = grab_monitor(args.monitor)
    if args.full:
        return img
    return select_region(img, mon)


def main():
    make_dpi_aware()
    args = parse_args()
    configure_tesseract(args.tesseract_cmd)

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    if args.watch:
        os.makedirs(OUTPUT_FOLDER, exist_ok=True)
        name = args.out or f"snips_{datetime.now():%Y%m%d}.xlsx"  # one file per day, appended to
        out = Path(name) if Path(name).is_absolute() else Path(OUTPUT_FOLDER) / name
        watch_clipboard(args, out.with_suffix(".xlsx"))
        return
    from_folder = not (args.images or args.clipboard or args.capture or args.watch)
    if from_folder:  # default: convert everything waiting in INPUT_FOLDER
        if not os.path.isdir(INPUT_FOLDER):
            sys.exit(f"Input folder not found: {INPUT_FOLDER}\nCreate it, or fix INPUT_FOLDER at the top of the script.")
        args.images = [INPUT_FOLDER]
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)
    out = Path(args.out) if args.out else Path(OUTPUT_FOLDER) / f"tables_{stamp}.xlsx"
    if not out.is_absolute() and not args.out:
        out = Path(OUTPUT_FOLDER) / out
    out = out.expanduser().resolve()
    if out.suffix.lower() != ".xlsx":
        out = out.with_suffix(".xlsx")
    shots_dir = out.parent / f"{out.stem}_screenshots"

    if args.append and out.exists():
        wb, created = load_workbook(out), False
    else:
        if out.exists():
            sys.exit(f"{out.name} already exists. Use --append to add to it, or choose another --out name.")
        wb, created = Workbook(), True

    def next_source():
        """Yield (sheet name, PIL image, path to an image file on disk, source description)."""
        if args.images:
            for p in expand_image_paths(args.images):
                yield p.stem, Image.open(p).convert("RGB"), p, str(p)
            return
        while True:
            img = image_from_clipboard() if args.clipboard else capture_screen(args)
            if img is None:
                print("  No image captured." if args.clipboard else "  Selection cancelled.")
                return
            name = "Shot_" + datetime.now().strftime("%Y%m%d_%H%M%S")
            shots_dir.mkdir(parents=True, exist_ok=True)
            path = shots_dir / f"{name}.png"
            img.save(path)
            yield name, img, path, "clipboard" if args.clipboard else f"screen (monitor {args.monitor})"
            if not args.multi or args.clipboard:
                return
            if input("  Capture another table? [Enter = yes, q = quit] ").strip().lower().startswith("q"):
                return

    log, converted = [], []
    for name, img, img_path, desc in next_source():
        print(f"- {name}: running OCR ...")
        debug_path = None
        if args.debug:
            shots_dir.mkdir(parents=True, exist_ok=True)
            debug_path = shots_dir / f"{name}_debug.png"
        grid, confs = extract_table(img, args, debug_path)
        if not grid:
            print("  ! No text found. Try a larger --scale, another --psm, or a tighter selection.")
            continue
        ws, low = write_sheet(wb, name, grid, confs, args, img_path)
        ncols = max(len(r) for r in grid)
        print(f"  -> sheet '{ws.title}': {len(grid)} rows x {ncols} columns"
              + (f", {low} low-confidence cells highlighted" if low else ""))
        if debug_path:
            print(f"  debug image: {debug_path}")
        if args.csv:
            import csv
            csv_path = out.parent / f"{out.stem}_{ws.title}.csv"
            with open(csv_path, "w", newline="", encoding="utf-8-sig") as fh:
                csv.writer(fh).writerows(grid)
        log.append([ws.title, desc, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), len(grid), ncols, low])
        if from_folder:
            converted.append(Path(img_path))

    if not log:
        sys.exit(f"No images found in {INPUT_FOLDER}" if from_folder else "Nothing to save.")
    if created and "Sheet" in wb.sheetnames and len(wb.sheetnames) > 1:
        del wb["Sheet"]
    write_info_sheet(wb, log)
    wb.active = 1 if len(wb.sheetnames) > 1 else 0
    wb.save(out)
    print(f"\nSaved {out}")
    if converted and not args.keep:
        os.makedirs(DONE_FOLDER, exist_ok=True)
        for src_path in converted:
            target = Path(DONE_FOLDER) / src_path.name
            n = 2
            while target.exists():  # never overwrite an older image with the same name
                target = Path(DONE_FOLDER) / f"{src_path.stem}_{n}{src_path.suffix}"
                n += 1
            shutil.move(str(src_path), str(target))
        print(f"Moved {len(converted)} image(s) to {DONE_FOLDER}")
    if args.open:
        open_file(out)


if __name__ == "__main__":
    main()
